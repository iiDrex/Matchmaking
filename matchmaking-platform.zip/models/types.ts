// ===== TIPOS PRINCIPALES =====

export type UserRole = "player" | "organizer" | "admin"
export type Position = "arquero" | "defensor" | "mediocampista" | "delantero" | "cualquiera"
export type MatchType = "futbol5" | "futbol8" | "futbol11"
export type SkillLevel = "casual" | "intermedio" | "competitivo"
export type Gender = "masculino" | "femenino" | "mixto"
export type MatchStatus = "open" | "full" | "in_progress" | "completed" | "cancelled"
export type TournamentStatus = "registration" | "in_progress" | "completed" | "cancelled"
export type PaymentStatus = "pending" | "completed" | "failed" | "refunded"
export type NotificationType = "match_join" | "match_leave" | "match_reminder" | "tournament_update" | "payment_update"

// ===== INTERFACES PRINCIPALES =====

export interface Location {
  address: string
  city: string
  state?: string
  country: string
  coordinates: {
    lat: number
    lng: number
  }
  placeId?: string
}

export interface User {
  id: string
  email: string
  name: string
  lastName: string
  phone?: string
  avatar?: string
  dateOfBirth: string
  gender: Gender
  location: Location
  position: Position
  skillLevel: SkillLevel
  role: UserRole
  isVerified: boolean
  rating: number
  totalMatches: number
  totalTournaments: number
  createdAt: string
  updatedAt: string
  preferences: UserPreferences
  stats: UserStats
}

export interface UserPreferences {
  notifications: {
    email: boolean
    push: boolean
    sms: boolean
  }
  privacy: {
    showPhone: boolean
    showEmail: boolean
    showLocation: boolean
  }
  matchmaking: {
    maxDistance: number
    preferredTimes: string[]
    preferredDays: string[]
  }
}

export interface UserStats {
  matchesWon: number
  matchesLost: number
  matchesDrawn: number
  goalsScored: number
  assists: number
  cleanSheets: number
  averageRating: number
  reliability: number
}

export interface Match {
  id: string
  title: string
  description: string
  type: MatchType
  date: string
  startTime: string
  endTime: string
  location: Location
  organizer: User
  maxPlayers: number
  currentPlayers: User[]
  waitingList: User[]
  skillLevel: SkillLevel
  gender: Gender
  ageRange: {
    min: number
    max: number
  }
  price: number
  currency: string
  needsPositions: Position[]
  rules: string[]
  status: MatchStatus
  isPrivate: boolean
  inviteCode?: string
  createdAt: string
  updatedAt: string
  field?: Field
  payment?: PaymentInfo
}

export interface Tournament {
  id: string
  name: string
  description: string
  type: MatchType
  startDate: string
  endDate: string
  location: Location
  organizer: User
  maxTeams: number
  currentTeams: Team[]
  registrationDeadline: string
  skillLevel: SkillLevel
  gender: Gender
  ageRange: {
    min: number
    max: number
  }
  entryFee: number
  currency: string
  prizes: Prize[]
  rules: string[]
  status: TournamentStatus
  format: TournamentFormat
  createdAt: string
  updatedAt: string
  field?: Field
}

export interface Team {
  id: string
  name: string
  captain: User
  players: User[]
  logo?: string
  stats: TeamStats
  createdAt: string
}

export interface TeamStats {
  matchesPlayed: number
  wins: number
  losses: number
  draws: number
  goalsFor: number
  goalsAgainst: number
  points: number
}

export interface Field {
  id: string
  name: string
  address: string
  location: Location
  type: MatchType[]
  amenities: string[]
  pricePerHour: number
  currency: string
  images: string[]
  rating: number
  reviews: Review[]
  availability: FieldAvailability[]
  contact: {
    phone: string
    email: string
    website?: string
  }
}

export interface FieldAvailability {
  dayOfWeek: number
  startTime: string
  endTime: string
  isAvailable: boolean
  price?: number
}

export interface Review {
  id: string
  user: User
  rating: number
  comment: string
  createdAt: string
  helpful: number
}

export interface Prize {
  position: number
  description: string
  value?: number
  currency?: string
}

export interface TournamentFormat {
  type: "league" | "knockout" | "group_stage"
  groupSize?: number
  playoffsTeams?: number
}

export interface PaymentInfo {
  id: string
  amount: number
  currency: string
  status: PaymentStatus
  method: "mercadopago" | "stripe" | "uala"
  transactionId?: string
  createdAt: string
  updatedAt: string
}

export interface Notification {
  id: string
  userId: string
  type: NotificationType
  title: string
  message: string
  data?: any
  isRead: boolean
  createdAt: string
}

// ===== FILTROS =====

export interface MatchFilters {
  type?: MatchType
  skillLevel?: SkillLevel
  gender?: Gender
  position?: Position
  ageRange?: {
    min: number
    max: number
  }
  location?: string
  date?: string
  maxDistance?: number
  priceRange?: {
    min: number
    max: number
  }
  availableSpots?: boolean
}

export interface TournamentFilters {
  type?: MatchType
  skillLevel?: SkillLevel
  gender?: Gender
  status?: TournamentStatus
  location?: string
  dateRange?: {
    start: string
    end: string
  }
  maxDistance?: number
  entryFeeRange?: {
    min: number
    max: number
  }
}

// ===== API RESPONSES =====

export interface ApiResponse<T> {
  success: boolean
  data?: T
  message?: string
  error?: string
  pagination?: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

export interface AuthResponse {
  user: User
  token: string
  refreshToken: string
}

// ===== FORM TYPES =====

export interface LoginForm {
  email: string
  password: string
}

export interface RegisterForm {
  email: string
  password: string
  confirmPassword: string
  name: string
  lastName: string
  phone: string
  dateOfBirth: string
  gender: Gender
  position: Position
  skillLevel: SkillLevel
  location: Location
}

export interface CreateMatchForm {
  title: string
  description: string
  type: MatchType
  date: string
  startTime: string
  endTime: string
  location: Location
  maxPlayers: number
  skillLevel: SkillLevel
  gender: Gender
  ageRange: {
    min: number
    max: number
  }
  price: number
  needsPositions: Position[]
  rules: string[]
  isPrivate: boolean
}

export interface CreateTournamentForm {
  name: string
  description: string
  type: MatchType
  startDate: string
  endDate: string
  location: Location
  maxTeams: number
  registrationDeadline: string
  skillLevel: SkillLevel
  gender: Gender
  ageRange: {
    min: number
    max: number
  }
  entryFee: number
  prizes: Prize[]
  rules: string[]
  format: TournamentFormat
}
