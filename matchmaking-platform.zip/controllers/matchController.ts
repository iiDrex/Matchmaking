import { Match, MatchFilters, User } from "../models/types"
import { mockMatches } from "../services/mockData"

export class MatchController {
  static getAllMatches(): Match[] {
    return mockMatches
  }

  static getFilteredMatches(filters: MatchFilters): Match[] {
    return mockMatches.filter(match => {
      if (filters.type && match.type !== filters.type) return false
      if (filters.skillLevel && match.skillLevel !== filters.skillLevel) return false
      if (filters.gender && match.gender !== filters.gender && match.gender !== "mixto") return false
      if (filters.position && !match.needsPosition.includes(filters.position)) return false
      if (filters.ageRange) {
        const userAge = filters.ageRange.min // Simplificado para el ejemplo
        if (userAge < match.ageRange.min || userAge > match.ageRange.max) return false
      }
      return true
    })
  }

  static joinMatch(matchId: string, userId: string): boolean {
    const matchIndex = mockMatches.findIndex(m => m.id === matchId)
    if (matchIndex !== -1) {
      const match = mockMatches[matchIndex]
      if (match.players.length < match.maxPlayers) {
        match.players.push(userId)
        return true
      }
    }
    return false
  }

  static getMatchById(id: string): Match | undefined {
    return mockMatches.find(match => match.id === id)
  }
}
