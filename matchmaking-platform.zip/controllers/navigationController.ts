// Controlador para manejar la navegación y estado de autenticación
export class NavigationController {
  static isAuthenticated(): boolean {
    // Por ahora retorna false, aquí irá la lógica de autenticación
    if (typeof window !== "undefined") {
      return localStorage.getItem("user") !== null
    }
    return false
  }

  static handleEnterClick(): string {
    // Determina a dónde redirigir cuando se hace click en "Entrar"
    return this.isAuthenticated() ? "/partidos" : "/login"
  }

  static logout(): void {
    if (typeof window !== "undefined") {
      localStorage.removeItem("user")
    }
  }
}
