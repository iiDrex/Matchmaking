"use client"

import { useRouter as useNextRouter } from 'next/navigation'

export const useRouter = () => {
  return useNextRouter()
}
