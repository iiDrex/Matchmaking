import ProtectedRoute from "../../components/ProtectedRoute"
import HighlightsPage from "../../views/HighlightsPage"

export default function Highlights() {
  return (
    <ProtectedRoute>
      <HighlightsPage />
    </ProtectedRoute>
  )
}
