import ProtectedRoute from "../../components/ProtectedRoute"
import MatchesPage from "../../views/MatchesPage"

export default function Partidos() {
  return (
    <ProtectedRoute>
      <MatchesPage />
    </ProtectedRoute>
  )
}
