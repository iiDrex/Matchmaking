import TeamsPage from "../../views/TeamsPage"

export default function Page() {
  return <TeamsPage />
}
