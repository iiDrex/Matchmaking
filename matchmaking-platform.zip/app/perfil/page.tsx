import ProtectedRoute from "../../components/ProtectedRoute"
import ProfilePage from "../../views/ProfilePage"

export default function Perfil() {
  return (
    <ProtectedRoute>
      <ProfilePage />
    </ProtectedRoute>
  )
}
