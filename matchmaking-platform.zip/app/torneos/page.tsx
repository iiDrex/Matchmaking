import ProtectedRoute from "../../components/ProtectedRoute"
import TournamentsPage from "../../views/TournamentsPage"

export default function Torneos() {
  return (
    <ProtectedRoute>
      <TournamentsPage />
    </ProtectedRoute>
  )
}
