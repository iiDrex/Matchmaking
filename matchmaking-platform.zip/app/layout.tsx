import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { AuthProvider } from '../contexts/AuthContext'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Matchmaking - Jugá donde quieras, con quien quieras',
  description: 'Plataforma para organizar partidos y torneos de fútbol. Conecta con jugadores de tu ciudad.',
  keywords: 'fútbol, partidos, torneos, matchmaking, deporte, Argentina',
  authors: [{ name: 'Matchmaking Team' }],
  openGraph: {
    title: 'Matchmaking - Plataforma de Fútbol',
    description: 'Conecta con jugadores de tu ciudad y organiza partidos de fútbol',
    type: 'website',
    locale: 'es_AR',
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <body className={inter.className}>
        <AuthProvider>
          {children}
        </AuthProvider>
      </body>
    </html>
  )
}
