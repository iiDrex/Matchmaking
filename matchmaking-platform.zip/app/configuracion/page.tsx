import ProtectedRoute from "../../components/ProtectedRoute"
import ConfigurationPage from "../../views/ConfigurationPage"

export default function Configuracion() {
  return (
    <ProtectedRoute>
      <ConfigurationPage />
    </ProtectedRoute>
  )
}
