import HomePage from "../views/HomePage"

export default function Home() {
  return <HomePage />
}
