import HelpPage from "../../views/HelpPage"

export default function Page() {
  return <HelpPage />
}
