import ProtectedRoute from "../../components/ProtectedRoute"
import AdminPage from "../../views/AdminPage"

export default function Admin() {
  return (
    <ProtectedRoute>
      <AdminPage />
    </ProtectedRoute>
  )
}
