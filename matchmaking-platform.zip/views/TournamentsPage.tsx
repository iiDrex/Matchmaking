"use client"

import { useState, useEffect } from "react"
import { Plus, Search, Trophy, Calendar, MapPin, Users, DollarSign, Crown, Medal, Award } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Sidebar from "../components/Sidebar"
import CreateTournamentModal from "../components/CreateTournamentModal"
import { Tournament, TournamentFilters, CreateTournamentForm } from "../models/types"
import { mockTournaments } from "../services/mockData"
import { useAuth } from "../contexts/AuthContext"

export default function TournamentsPage() {
  const { user } = useAuth()
  const [tournaments, setTournaments] = useState<Tournament[]>([])
  const [filteredTournaments, setFilteredTournaments] = useState<Tournament[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [showCreateModal, setShowCreateModal] = useState(false)

  useEffect(() => {
    setTournaments(mockTournaments)
    setFilteredTournaments(mockTournaments)
  }, [])

  useEffect(() => {
    let result = tournaments
    
    if (searchTerm) {
      result = result.filter(tournament => 
        tournament.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tournament.location.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tournament.organizer.name.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }
    
    setFilteredTournaments(result)
  }, [searchTerm, tournaments])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "registration": return "bg-green-500"
      case "in_progress": return "bg-blue-500"
      case "completed": return "bg-gray-500"
      case "cancelled": return "bg-red-500"
      default: return "bg-gray-500"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "registration": return "Inscripciones Abiertas"
      case "in_progress": return "En Progreso"
      case "completed": return "Finalizado"
      case "cancelled": return "Cancelado"
      default: return status
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "futbol5": return "bg-blue-600"
      case "futbol8": return "bg-purple-600"
      case "futbol11": return "bg-green-600"
      default: return "bg-gray-600"
    }
  }

  const getPrizeIcon = (position: number) => {
    switch (position) {
      case 1: return <Crown className="w-4 h-4 text-yellow-400" />
      case 2: return <Medal className="w-4 h-4 text-gray-400" />
      case 3: return <Award className="w-4 h-4 text-orange-400" />
      default: return <Trophy className="w-4 h-4 text-gray-400" />
    }
  }

  const handleJoinTournament = (tournamentId: string) => {
    // TODO: Implementar lógica de inscripción
    alert(`Inscribirse al torneo ${tournamentId}`)
  }

  const handleCreateTournament = async (tournamentData: CreateTournamentForm) => {
    // Simular creación de torneo
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    const newTournament: Tournament = {
      id: 'tournament-' + Date.now(),
      ...tournamentData,
      organizer: user!,
      currentTeams: [],
      status: "registration",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      currency: "ARS"
    }
    
    setTournaments(prevTournaments => [newTournament, ...prevTournaments])
    alert("¡Torneo creado exitosamente!")
  }

  const canCreateTournament = user?.role === 'admin' || user?.role === 'organizer'

  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar currentPage="torneos" />
      
      <main className="flex-1 md:ml-0">
        <div className="container mx-auto px-4 py-8 md:px-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 mt-16 md:mt-0">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Torneos</h1>
              <p className="text-gray-400">Participa en competencias organizadas</p>
            </div>
            {canCreateTournament && (
              <Button 
                className="bg-green-500 hover:bg-green-600 text-white mt-4 md:mt-0"
                onClick={() => setShowCreateModal(true)}
              >
                <Plus className="w-4 h-4 mr-2" />
                Crear Torneo
              </Button>
            )}
          </div>

          {/* Search bar */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Buscar torneos por nombre, ubicación o organizador..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-green-500"
            />
          </div>

          {/* Tabs */}
          <Tabs defaultValue="todos" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800 mb-6">
              <TabsTrigger value="todos" className="text-gray-300 data-[state=active]:text-white">
                Todos
              </TabsTrigger>
              <TabsTrigger value="abiertos" className="text-gray-300 data-[state=active]:text-white">
                Inscripciones Abiertas
              </TabsTrigger>
              <TabsTrigger value="en-curso" className="text-gray-300 data-[state=active]:text-white">
                En Curso
              </TabsTrigger>
              <TabsTrigger value="finalizados" className="text-gray-300 data-[state=active]:text-white">
                Finalizados
              </TabsTrigger>
            </TabsList>

            <TabsContent value="todos">
              {/* Results count */}
              <div className="flex justify-between items-center mb-6">
                <p className="text-gray-400">
                  {filteredTournaments.length} {filteredTournaments.length === 1 ? 'torneo encontrado' : 'torneos encontrados'}
                </p>
              </div>

              {/* Tournaments grid */}
              {filteredTournaments.length > 0 ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {filteredTournaments.map((tournament) => (
                    <Card key={tournament.id} className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-all duration-300 hover:border-green-500/50">
                      <CardHeader>
                        <div className="flex justify-between items-start mb-4">
                          <div className="flex-1">
                            <CardTitle className="text-xl text-white mb-2">{tournament.name}</CardTitle>
                            <CardDescription className="text-gray-400">
                              {tournament.description}
                            </CardDescription>
                          </div>
                          <Trophy className="w-8 h-8 text-yellow-400 ml-4" />
                        </div>

                        <div className="flex gap-2 mb-4">
                          <Badge className={`${getTypeColor(tournament.type)} text-white`}>
                            {tournament.type.toUpperCase()}
                          </Badge>
                          <Badge className={`${getStatusColor(tournament.status)} text-white`}>
                            {getStatusLabel(tournament.status)}
                          </Badge>
                          <Badge variant="outline" className="text-gray-300 border-gray-600">
                            {tournament.gender}
                          </Badge>
                          <Badge variant="outline" className="text-gray-300 border-gray-600">
                            {tournament.skillLevel}
                          </Badge>
                        </div>
                      </CardHeader>

                      <CardContent>
                        {/* Organizador */}
                        <div className="flex items-center mb-4">
                          <img
                            src={tournament.organizer.avatar || "/placeholder.svg"}
                            alt={tournament.organizer.name}
                            className="w-8 h-8 rounded-full mr-3"
                          />
                          <div>
                            <p className="text-white text-sm font-medium">
                              {tournament.organizer.name} {tournament.organizer.lastName}
                            </p>
                            <p className="text-gray-400 text-xs">Organizador</p>
                          </div>
                        </div>

                        {/* Detalles del torneo */}
                        <div className="space-y-2 mb-4">
                          <div className="flex items-center text-gray-300">
                            <Calendar className="w-4 h-4 mr-2" />
                            <span className="text-sm">
                              {new Date(tournament.startDate).toLocaleDateString('es-AR')} - {new Date(tournament.endDate).toLocaleDateString('es-AR')}
                            </span>
                          </div>
                          <div className="flex items-center text-gray-300">
                            <MapPin className="w-4 h-4 mr-2" />
                            <span className="text-sm">{tournament.location.address}</span>
                          </div>
                          <div className="flex items-center text-gray-300">
                            <Users className="w-4 h-4 mr-2" />
                            <span className="text-sm">
                              {tournament.currentTeams.length}/{tournament.maxTeams} equipos
                            </span>
                          </div>
                          <div className="flex items-center text-gray-300">
                            <DollarSign className="w-4 h-4 mr-2" />
                            <span className="text-sm">${tournament.entryFee.toLocaleString()} por equipo</span>
                          </div>
                        </div>

                        {/* Premios */}
                        {tournament.prizes.length > 0 && (
                          <div className="mb-4">
                            <p className="text-gray-400 text-xs mb-2">Premios:</p>
                            <div className="space-y-1">
                              {tournament.prizes.slice(0, 3).map((prize, index) => (
                                <div key={index} className="flex items-center justify-between text-sm">
                                  <div className="flex items-center">
                                    {getPrizeIcon(prize.position)}
                                    <span className="text-gray-300 ml-2">{prize.position}° Lugar:</span>
                                  </div>
                                  <span className="text-yellow-400">{prize.description}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Información adicional */}
                        <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                          <div>
                            <span className="text-gray-400">Formato:</span>
                            <span className="text-white ml-2">
                              {tournament.format.type === 'league' ? 'Liga' : 
                               tournament.format.type === 'knockout' ? 'Eliminación' : 'Grupos'}
                            </span>
                          </div>
                          <div>
                            <span className="text-gray-400">Edad:</span>
                            <span className="text-white ml-2">
                              {tournament.ageRange.min}-{tournament.ageRange.max} años
                            </span>
                          </div>
                          <div className="col-span-2">
                            <span className="text-gray-400">Inscripción hasta:</span>
                            <span className="text-white ml-2">
                              {new Date(tournament.registrationDeadline).toLocaleDateString('es-AR')}
                            </span>
                          </div>
                        </div>

                        {/* Progreso de inscripción */}
                        <div className="mb-4">
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-400">Equipos inscritos</span>
                            <span className="text-white">{tournament.currentTeams.length}/{tournament.maxTeams}</span>
                          </div>
                          <div className="w-full bg-gray-700 rounded-full h-2">
                            <div 
                              className="bg-green-500 h-2 rounded-full transition-all duration-300"
                              style={{ width: `${(tournament.currentTeams.length / tournament.maxTeams) * 100}%` }}
                            ></div>
                          </div>
                        </div>

                        {/* Botones de acción */}
                        <div className="flex gap-2 pt-4 border-t border-gray-700">
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
                          >
                            Ver Detalles
                          </Button>
                          <Button
                            onClick={() => handleJoinTournament(tournament.id)}
                            disabled={tournament.status !== 'registration' || tournament.currentTeams.length >= tournament.maxTeams}
                            size="sm"
                            className={`flex-1 ${
                              tournament.status === 'registration' && tournament.currentTeams.length < tournament.maxTeams
                                ? 'bg-green-500 hover:bg-green-600'
                                : 'bg-gray-600 cursor-not-allowed'
                            } text-white`}
                          >
                            {tournament.status === 'registration' 
                              ? tournament.currentTeams.length >= tournament.maxTeams 
                                ? 'Completo' 
                                : 'Inscribirse'
                              : 'Cerrado'
                            }
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="text-gray-400 mb-4">
                    <Trophy className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p className="text-xl mb-2">No se encontraron torneos</p>
                    <p>Intenta ajustar la búsqueda o crear un nuevo torneo</p>
                  </div>
                  {canCreateTournament && (
                    <Button 
                      className="bg-green-500 hover:bg-green-600 text-white mt-4"
                      onClick={() => setShowCreateModal(true)}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Crear Primer Torneo
                    </Button>
                  )}
                </div>
              )}
            </TabsContent>

            <TabsContent value="abiertos">
              <div className="text-center py-12">
                <Trophy className="w-16 h-16 mx-auto mb-4 text-green-400" />
                <p className="text-xl text-white mb-2">Torneos con Inscripciones Abiertas</p>
                <p className="text-gray-400">Torneos que están aceptando nuevos equipos</p>
              </div>
            </TabsContent>

            <TabsContent value="en-curso">
              <div className="text-center py-12">
                <Trophy className="w-16 h-16 mx-auto mb-4 text-blue-400" />
                <p className="text-xl text-white mb-2">Torneos en Curso</p>
                <p className="text-gray-400">Competencias que ya comenzaron</p>
              </div>
            </TabsContent>

            <TabsContent value="finalizados">
              <div className="text-center py-12">
                <Trophy className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                <p className="text-xl text-white mb-2">Torneos Finalizados</p>
                <p className="text-gray-400">Competencias completadas con sus resultados</p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Create Tournament Modal */}
      <CreateTournamentModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSubmit={handleCreateTournament}
      />
    </div>
  )
}
