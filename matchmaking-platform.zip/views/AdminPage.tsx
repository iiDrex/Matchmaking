"use client"

import { useState, useEffect } from "react"
import { Users, Calendar, Trophy, MapPin, Plus, Edit, Trash2, Eye, CheckCircle, XCircle, TrendingUp, AlertTriangle, Star } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import Sidebar from "../components/Sidebar"
import { useAuth } from "../contexts/AuthContext"

interface AdminStats {
  totalUsers: number
  newUsersThisWeek: number
  totalMatches: number
  matchesThisWeek: number
  totalTournaments: number
  activeTournaments: number
  totalFields: number
  pendingReports: number
}

interface Field {
  id: string
  name: string
  address: string
  contact: {
    name: string
    phone: string
    email: string
  }
  pricePerHour: number
  type: string[]
  amenities: string[]
  status: 'active' | 'inactive' | 'pending'
  rating: number
  availability: string
}

interface PendingHighlight {
  id: string
  title: string
  author: string
  thumbnail: string
  uploadDate: string
  status: 'pending' | 'approved' | 'rejected'
  views: number
  likes: number
}

export default function AdminPage() {
  const { user } = useAuth()
  const [stats, setStats] = useState<AdminStats>({
    totalUsers: 1247,
    newUsersThisWeek: 23,
    totalMatches: 856,
    matchesThisWeek: 47,
    totalTournaments: 34,
    activeTournaments: 8,
    totalFields: 15,
    pendingReports: 3
  })

  const [fields, setFields] = useState<Field[]>([
    {
      id: "field-001",
      name: "Cancha Los Amigos",
      address: "Av. Santa Fe 3500, Buenos Aires",
      contact: {
        name: "Roberto García",
        phone: "+54 11 4567-8901",
        email: "roberto@canchalosAmigos.com"
      },
      pricePerHour: 8000,
      type: ["futbol5", "futbol8"],
      amenities: ["Vestuarios", "Estacionamiento", "Buffet"],
      status: "active",
      rating: 4.5,
      availability: "Lun-Dom 8:00-23:00"
    },
    {
      id: "field-002",
      name: "Complejo Norte",
      address: "Av. Corrientes 4500, Buenos Aires",
      contact: {
        name: "Ana Martínez",
        phone: "+54 11 5678-9012",
        email: "ana@complejonorte.com"
      },
      pricePerHour: 12000,
      type: ["futbol8", "futbol11"],
      amenities: ["Vestuarios", "Estacionamiento", "Buffet", "Duchas"],
      status: "active",
      rating: 4.8,
      availability: "Lun-Dom 7:00-24:00"
    }
  ])

  const [pendingHighlights, setPendingHighlights] = useState<PendingHighlight[]>([
    {
      id: "highlight-pending-001",
      title: "Golazo increíble desde el medio",
      author: "Juan Pérez",
      thumbnail: "/placeholder.svg?height=100&width=150&text=Golazo",
      uploadDate: "2024-01-25",
      status: "pending",
      views: 45,
      likes: 12
    },
    {
      id: "highlight-pending-002",
      title: "Atajada espectacular",
      author: "María González",
      thumbnail: "/placeholder.svg?height=100&width=150&text=Atajada",
      uploadDate: "2024-01-24",
      status: "pending",
      views: 67,
      likes: 23
    }
  ])

  const [showAddFieldModal, setShowAddFieldModal] = useState(false)
  const [newField, setNewField] = useState({
    name: '',
    address: '',
    contactName: '',
    contactPhone: '',
    contactEmail: '',
    pricePerHour: 0,
    type: [] as string[],
    amenities: [] as string[]
  })

  const handleApproveHighlight = (highlightId: string) => {
    setPendingHighlights(prev =>
      prev.map(highlight =>
        highlight.id === highlightId
          ? { ...highlight, status: 'approved' as const }
          : highlight
      )
    )
  }

  const handleRejectHighlight = (highlightId: string) => {
    setPendingHighlights(prev =>
      prev.map(highlight =>
        highlight.id === highlightId
          ? { ...highlight, status: 'rejected' as const }
          : highlight
      )
    )
  }

  const handleAddField = () => {
    const field: Field = {
      id: `field-${Date.now()}`,
      name: newField.name,
      address: newField.address,
      contact: {
        name: newField.contactName,
        phone: newField.contactPhone,
        email: newField.contactEmail
      },
      pricePerHour: newField.pricePerHour,
      type: newField.type,
      amenities: newField.amenities,
      status: 'active',
      rating: 0,
      availability: 'Por definir'
    }
    
    setFields(prev => [...prev, field])
    setShowAddFieldModal(false)
    setNewField({
      name: '',
      address: '',
      contactName: '',
      contactPhone: '',
      contactEmail: '',
      pricePerHour: 0,
      type: [],
      amenities: []
    })
  }

  // Verificar que el usuario sea admin
  if (user?.role !== 'admin') {
    return (
      <div className="flex min-h-screen bg-gray-900">
        <Sidebar currentPage="admin" />
        <main className="flex-1 flex items-center justify-center">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-8 text-center">
              <AlertTriangle className="w-16 h-16 mx-auto mb-4 text-red-400" />
              <h2 className="text-xl font-bold text-white mb-2">Acceso Denegado</h2>
              <p className="text-gray-400">No tienes permisos para acceder al panel de administración</p>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar currentPage="admin" />
      
      <main className="flex-1 md:ml-0">
        <div className="container mx-auto px-4 py-8 md:px-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 mt-16 md:mt-0">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Panel de Administración</h1>
              <p className="text-gray-400">Gestiona la plataforma y supervisa las actividades</p>
            </div>
            <Badge className="bg-red-500 text-white mt-4 md:mt-0">
              Administrador
            </Badge>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Usuarios Totales</p>
                    <p className="text-2xl font-bold text-white">{stats.totalUsers}</p>
                    <p className="text-green-400 text-xs">+{stats.newUsersThisWeek} esta semana</p>
                  </div>
                  <Users className="w-8 h-8 text-blue-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Partidos Totales</p>
                    <p className="text-2xl font-bold text-white">{stats.totalMatches}</p>
                    <p className="text-green-400 text-xs">+{stats.matchesThisWeek} esta semana</p>
                  </div>
                  <Calendar className="w-8 h-8 text-green-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Torneos</p>
                    <p className="text-2xl font-bold text-white">{stats.activeTournaments}</p>
                    <p className="text-gray-400 text-xs">de {stats.totalTournaments} totales</p>
                  </div>
                  <Trophy className="w-8 h-8 text-yellow-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Reportes Pendientes</p>
                    <p className="text-2xl font-bold text-white">{stats.pendingReports}</p>
                    <p className="text-red-400 text-xs">Requieren atención</p>
                  </div>
                  <AlertTriangle className="w-8 h-8 text-red-400" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="fields" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800 mb-6">
              <TabsTrigger value="fields" className="text-gray-300 data-[state=active]:text-white">
                <MapPin className="w-4 h-4 mr-2" />
                Canchas
              </TabsTrigger>
              <TabsTrigger value="highlights" className="text-gray-300 data-[state=active]:text-white">
                <Star className="w-4 h-4 mr-2" />
                Highlights
              </TabsTrigger>
              <TabsTrigger value="reports" className="text-gray-300 data-[state=active]:text-white">
                <AlertTriangle className="w-4 h-4 mr-2" />
                Reportes
              </TabsTrigger>
              <TabsTrigger value="analytics" className="text-gray-300 data-[state=active]:text-white">
                <TrendingUp className="w-4 h-4 mr-2" />
                Analíticas
              </TabsTrigger>
            </TabsList>

            {/* Gestión de Canchas */}
            <TabsContent value="fields">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle className="text-white">Gestión de Canchas</CardTitle>
                      <CardDescription className="text-gray-400">
                        Administra las canchas disponibles en la plataforma
                      </CardDescription>
                    </div>
                    <Button 
                      className="bg-green-500 hover:bg-green-600"
                      onClick={() => setShowAddFieldModal(true)}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Agregar Cancha
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow className="border-gray-700">
                        <TableHead className="text-gray-300">Nombre</TableHead>
                        <TableHead className="text-gray-300">Contacto</TableHead>
                        <TableHead className="text-gray-300">Precio/Hora</TableHead>
                        <TableHead className="text-gray-300">Tipo</TableHead>
                        <TableHead className="text-gray-300">Rating</TableHead>
                        <TableHead className="text-gray-300">Estado</TableHead>
                        <TableHead className="text-gray-300">Acciones</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {fields.map((field) => (
                        <TableRow key={field.id} className="border-gray-700">
                          <TableCell>
                            <div>
                              <p className="text-white font-medium">{field.name}</p>
                              <p className="text-gray-400 text-sm">{field.address}</p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="text-white text-sm">{field.contact.name}</p>
                              <p className="text-gray-400 text-xs">{field.contact.phone}</p>
                            </div>
                          </TableCell>
                          <TableCell className="text-white">
                            ${field.pricePerHour.toLocaleString()}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              {field.type.map((type, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {type}
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <Star className="w-4 h-4 text-yellow-400 mr-1" />
                              <span className="text-white">{field.rating}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={
                              field.status === 'active' ? 'bg-green-500' :
                              field.status === 'inactive' ? 'bg-red-500' : 'bg-yellow-500'
                            }>
                              {field.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button variant="ghost" size="sm">
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm" className="text-red-400">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Moderación de Highlights */}
            <TabsContent value="highlights">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Moderación de Highlights</CardTitle>
                  <CardDescription className="text-gray-400">
                    Revisa y aprueba los clips subidos por los usuarios
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {pendingHighlights.map((highlight) => (
                      <Card key={highlight.id} className="bg-gray-700 border-gray-600">
                        <CardContent className="p-4">
                          <img
                            src={highlight.thumbnail || "/placeholder.svg"}
                            alt={highlight.title}
                            className="w-full h-32 object-cover rounded mb-3"
                          />
                          <h3 className="text-white font-medium mb-2">{highlight.title}</h3>
                          <p className="text-gray-400 text-sm mb-2">Por: {highlight.author}</p>
                          <p className="text-gray-400 text-xs mb-3">
                            Subido: {new Date(highlight.uploadDate).toLocaleDateString('es-AR')}
                          </p>
                          
                          <div className="flex justify-between items-center mb-3">
                            <div className="flex gap-4 text-xs text-gray-400">
                              <span>{highlight.views} vistas</span>
                              <span>{highlight.likes} likes</span>
                            </div>
                            <Badge className={
                              highlight.status === 'pending' ? 'bg-yellow-500' :
                              highlight.status === 'approved' ? 'bg-green-500' : 'bg-red-500'
                            }>
                              {highlight.status}
                            </Badge>
                          </div>

                          {highlight.status === 'pending' && (
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                className="flex-1 bg-green-500 hover:bg-green-600"
                                onClick={() => handleApproveHighlight(highlight.id)}
                              >
                                <CheckCircle className="w-4 h-4 mr-1" />
                                Aprobar
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                className="flex-1 border-red-500 text-red-400 hover:bg-red-900/20"
                                onClick={() => handleRejectHighlight(highlight.id)}
                              >
                                <XCircle className="w-4 h-4 mr-1" />
                                Rechazar
                              </Button>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Reportes */}
            <TabsContent value="reports">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Reportes y Denuncias</CardTitle>
                  <CardDescription className="text-gray-400">
                    Gestiona los reportes de usuarios y contenido
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12">
                    <AlertTriangle className="w-16 h-16 mx-auto mb-4 text-yellow-400" />
                    <p className="text-xl text-white mb-2">Sistema de Reportes</p>
                    <p className="text-gray-400 mb-4">Funcionalidad en desarrollo</p>
                    <p className="text-sm text-gray-500">
                      Próximamente: gestión de reportes, moderación de usuarios, sistema de sanciones
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Analíticas */}
            <TabsContent value="analytics">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Analíticas y Estadísticas</CardTitle>
                  <CardDescription className="text-gray-400">
                    Métricas detalladas de la plataforma
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12">
                    <TrendingUp className="w-16 h-16 mx-auto mb-4 text-blue-400" />
                    <p className="text-xl text-white mb-2">Dashboard de Analíticas</p>
                    <p className="text-gray-400 mb-4">Funcionalidad en desarrollo</p>
                    <p className="text-sm text-gray-500">
                      Próximamente: gráficos de crecimiento, métricas de engagement, reportes detallados
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Modal Agregar Cancha */}
      {showAddFieldModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Agregar Nueva Cancha</CardTitle>
              <CardDescription className="text-gray-400">
                Registra una nueva cancha en la plataforma
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-gray-300">Nombre de la Cancha</Label>
                <Input
                  value={newField.name}
                  onChange={(e) => setNewField({ ...newField, name: e.target.value })}
                  className="bg-gray-800 border-gray-700 text-white"
                  placeholder="Ej: Cancha Los Amigos"
                />
              </div>
              
              <div>
                <Label className="text-gray-300">Dirección</Label>
                <Input
                  value={newField.address}
                  onChange={(e) => setNewField({ ...newField, address: e.target.value })}
                  className="bg-gray-800 border-gray-700 text-white"
                  placeholder="Ej: Av. Santa Fe 3500, Buenos Aires"
                />
              </div>

              <div>
                <Label className="text-gray-300">Nombre del Contacto</Label>
                <Input
                  value={newField.contactName}
                  onChange={(e) => setNewField({ ...newField, contactName: e.target.value })}
                  className="bg-gray-800 border-gray-700 text-white"
                  placeholder="Ej: Roberto García"
                />
              </div>

              <div>
                <Label className="text-gray-300">Teléfono</Label>
                <Input
                  value={newField.contactPhone}
                  onChange={(e) => setNewField({ ...newField, contactPhone: e.target.value })}
                  className="bg-gray-800 border-gray-700 text-white"
                  placeholder="Ej: +54 11 1234-5678"
                />
              </div>

              <div>
                <Label className="text-gray-300">Precio por Hora (ARS)</Label>
                <Input
                  type="number"
                  value={newField.pricePerHour}
                  onChange={(e) => setNewField({ ...newField, pricePerHour: parseInt(e.target.value) })}
                  className="bg-gray-800 border-gray-700 text-white"
                  placeholder="8000"
                />
              </div>

              <div className="flex gap-4 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowAddFieldModal(false)}
                  className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800"
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleAddField}
                  className="flex-1 bg-green-500 hover:bg-green-600"
                >
                  Agregar Cancha
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
