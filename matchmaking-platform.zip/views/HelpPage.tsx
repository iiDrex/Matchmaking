"use client"

import { useState } from "react"
import { Search, ChevronDown, ChevronUp, MessageCircle, Mail, Phone, HelpCircle, Users, Calendar, Trophy, CreditCard } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import Sidebar from "../components/Sidebar"

interface FAQItem {
  id: string
  category: string
  question: string
  answer: string
}

export default function HelpPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [expandedFAQ, setExpandedFAQ] = useState<string | null>(null)
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  })

  const faqData: FAQItem[] = [
    {
      id: "faq-1",
      category: "partidos",
      question: "¿Cómo puedo crear un partido?",
      answer: "Para crear un partido, ve a la sección 'Partidos' y haz clic en 'Crear Partido'. Completa la información requerida como fecha, hora, ubicación y tipo de fútbol. Una vez creado, otros usuarios podrán unirse."
    },
    {
      id: "faq-2", 
      category: "partidos",
      question: "¿Puedo cancelar mi participación en un partido?",
      answer: "Sí, puedes cancelar tu participación hasta 2 horas antes del partido. Ve a 'Mis Partidos' y selecciona 'Cancelar participación'. Ten en cuenta que cancelaciones frecuentes pueden afectar tu rating de confiabilidad."
    },
    {
      id: "faq-3",
      category: "torneos", 
      question: "¿Cómo me inscribo en un torneo?",
      answer: "En la sección 'Torneos', busca el torneo que te interese y haz clic en 'Inscribirse'. Algunos torneos requieren inscripción por equipo, mientras que otros permiten inscripción individual."
    },
    {
      id: "faq-4",
      category: "torneos",
      question: "¿Qué pasa si mi equipo no puede jugar un partido del torneo?",
      answer: "Debes notificar al organizador del torneo lo antes posible. Dependiendo de las reglas del torneo, podrías perder por forfeit o reprogramar el partido. Revisa las reglas específicas de cada torneo."
    },
    {
      id: "faq-5",
      category: "equipos",
      question: "¿Cómo creo un equipo?",
      answer: "Ve a la sección 'Equipos' y haz clic en 'Crear Equipo'. Completa la información básica, elige colores y logo, y configura si será público o privado. Como creador, serás automáticamente el líder del equipo."
    },
    {
      id: "faq-6",
      category: "equipos", 
      question: "¿Puedo estar en varios equipos a la vez?",
      answer: "Sí, puedes ser miembro de múltiples equipos. Sin embargo, no puedes participar en el mismo torneo con diferentes equipos simultáneamente."
    },
    {
      id: "faq-7",
      category: "pagos",
      question: "¿Cómo funcionan los pagos?",
      answer: "Los pagos se procesan de forma segura a través de MercadoPago. Puedes pagar con tarjeta de crédito, débito o transferencia bancaria. El dinero se transfiere directamente al organizador o dueño de la cancha."
    },
    {
      id: "faq-8",
      category: "pagos",
      question: "¿Puedo obtener un reembolso?",
      answer: "Los reembolsos dependen de la política del organizador y el tiempo de cancelación. Generalmente, cancelaciones con más de 24 horas de anticipación son elegibles para reembolso completo."
    },
    {
      id: "faq-9",
      category: "tecnico",
      question: "No puedo iniciar sesión en mi cuenta",
      answer: "Verifica que estés usando el email y contraseña correctos. Si olvidaste tu contraseña, usa la opción 'Recuperar contraseña'. Si el problema persiste, contacta a soporte técnico."
    },
    {
      id: "faq-10",
      category: "tecnico",
      question: "La aplicación se cierra inesperadamente",
      answer: "Intenta cerrar y abrir la aplicación nuevamente. Si el problema persiste, verifica que tengas la última versión instalada. También puedes limpiar la caché de la aplicación en la configuración de tu dispositivo."
    }
  ]

  const categories = [
    { id: "partidos", label: "Partidos", icon: Calendar },
    { id: "torneos", label: "Torneos", icon: Trophy },
    { id: "equipos", label: "Equipos", icon: Users },
    { id: "pagos", label: "Pagos", icon: CreditCard },
    { id: "tecnico", label: "Problemas Técnicos", icon: HelpCircle }
  ]

  const filteredFAQs = faqData.filter(faq =>
    faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const handleSubmitContact = (e: React.FormEvent) => {
    e.preventDefault()
    // Simular envío de formulario
    alert("Mensaje enviado correctamente. Te responderemos en las próximas 24 horas.")
    setContactForm({ name: '', email: '', subject: '', message: '' })
  }

  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar currentPage="ayuda" />
      
      <main className="flex-1 md:ml-0">
        <div className="container mx-auto px-4 py-8 md:px-8">
          {/* Header */}
          <div className="mb-8 mt-16 md:mt-0">
            <h1 className="text-3xl font-bold text-white mb-2">Centro de Ayuda</h1>
            <p className="text-gray-400">Encuentra respuestas a tus preguntas o contacta con soporte</p>
          </div>

          {/* Search */}
          <div className="relative mb-8">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Buscar en preguntas frecuentes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-green-500"
            />
          </div>

          <Tabs defaultValue="faq" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-gray-800 mb-6">
              <TabsTrigger value="faq" className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-green-500">
                Preguntas Frecuentes
              </TabsTrigger>
              <TabsTrigger value="contact" className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-green-500">
                Contactar Soporte
              </TabsTrigger>
              <TabsTrigger value="tutorials" className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-green-500">
                Tutoriales
              </TabsTrigger>
            </TabsList>

            {/* FAQ */}
            <TabsContent value="faq">
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                {/* Categorías */}
                <div className="lg:col-span-1">
                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white text-lg">Categorías</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {categories.map((category) => {
                        const Icon = category.icon
                        const count = faqData.filter(faq => faq.category === category.id).length
                        return (
                          <Button
                            key={category.id}
                            variant="ghost"
                            className="w-full justify-start text-gray-300 hover:text-white hover:bg-gray-700"
                          >
                            <Icon className="w-4 h-4 mr-2" />
                            {category.label}
                            <span className="ml-auto text-xs bg-gray-700 px-2 py-1 rounded">
                              {count}
                            </span>
                          </Button>
                        )
                      })}
                    </CardContent>
                  </Card>
                </div>

                {/* FAQ List */}
                <div className="lg:col-span-3 space-y-4">
                  {filteredFAQs.map((faq) => (
                    <Card key={faq.id} className="bg-gray-800 border-gray-700">
                      <CardContent className="p-0">
                        <button
                          onClick={() => setExpandedFAQ(expandedFAQ === faq.id ? null : faq.id)}
                          className="w-full p-4 text-left flex items-center justify-between hover:bg-gray-750 transition-colors"
                        >
                          <h3 className="text-white font-medium">{faq.question}</h3>
                          {expandedFAQ === faq.id ? (
                            <ChevronUp className="w-5 h-5 text-gray-400" />
                          ) : (
                            <ChevronDown className="w-5 h-5 text-gray-400" />
                          )}
                        </button>
                        {expandedFAQ === faq.id && (
                          <div className="px-4 pb-4 border-t border-gray-700">
                            <p className="text-gray-300 mt-3">{faq.answer}</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}

                  {filteredFAQs.length === 0 && (
                    <div className="text-center py-12">
                      <HelpCircle className="w-16 h-16 mx-auto mb-4 text-gray-500" />
                      <p className="text-xl text-white mb-2">No se encontraron resultados</p>
                      <p className="text-gray-400">Intenta con otros términos de búsqueda</p>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>

            {/* Contact */}
            <TabsContent value="contact">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Formulario de contacto */}
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Enviar Mensaje</CardTitle>
                    <CardDescription className="text-gray-400">
                      Describe tu problema y te ayudaremos lo antes posible
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSubmitContact} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="name" className="text-gray-300">Nombre</Label>
                          <Input
                            id="name"
                            value={contactForm.name}
                            onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                            className="bg-gray-700 border-gray-600 text-white"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email" className="text-gray-300">Email</Label>
                          <Input
                            id="email"
                            type="email"
                            value={contactForm.email}
                            onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                            className="bg-gray-700 border-gray-600 text-white"
                            required
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="subject" className="text-gray-300">Asunto</Label>
                        <Input
                          id="subject"
                          value={contactForm.subject}
                          onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                          className="bg-gray-700 border-gray-600 text-white"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="message" className="text-gray-300">Mensaje</Label>
                        <Textarea
                          id="message"
                          value={contactForm.message}
                          onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                          className="bg-gray-700 border-gray-600 text-white"
                          rows={5}
                          required
                        />
                      </div>

                      <Button type="submit" className="w-full bg-green-500 hover:bg-green-600">
                        <Mail className="w-4 h-4 mr-2" />
                        Enviar Mensaje
                      </Button>
                    </form>
                  </CardContent>
                </Card>

                {/* Información de contacto */}
                <div className="space-y-6">
                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white">Otros Medios de Contacto</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center space-x-3">
                        <Mail className="w-5 h-5 text-blue-400" />
                        <div>
                          <p className="text-white font-medium">Email</p>
                          <p className="text-gray-400 text-sm">soporte@matchmaking.com</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Phone className="w-5 h-5 text-green-400" />
                        <div>
                          <p className="text-white font-medium">WhatsApp</p>
                          <p className="text-gray-400 text-sm">+54 11 1234-5678</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <MessageCircle className="w-5 h-5 text-purple-400" />
                        <div>
                          <p className="text-white font-medium">Chat en Vivo</p>
                          <p className="text-gray-400 text-sm">Lun-Vie 9:00-18:00</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white">Tiempo de Respuesta</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Email:</span>
                          <span className="text-white">24-48 horas</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">WhatsApp:</span>
                          <span className="text-white">2-4 horas</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Chat en vivo:</span>
                          <span className="text-white">Inmediato</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            {/* Tutorials */}
            <TabsContent value="tutorials">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <Calendar className="w-12 h-12 mx-auto mb-4 text-blue-400" />
                    <h3 className="text-white font-semibold mb-2">Crear tu Primer Partido</h3>
                    <p className="text-gray-400 text-sm mb-4">
                      Aprende paso a paso cómo organizar un partido
                    </p>
                    <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                      Ver Tutorial
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <Users className="w-12 h-12 mx-auto mb-4 text-green-400" />
                    <h3 className="text-white font-semibold mb-2">Gestionar tu Equipo</h3>
                    <p className="text-gray-400 text-sm mb-4">
                      Cómo crear y administrar equipos efectivamente
                    </p>
                    <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                      Ver Tutorial
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <Trophy className="w-12 h-12 mx-auto mb-4 text-yellow-400" />
                    <h3 className="text-white font-semibold mb-2">Participar en Torneos</h3>
                    <p className="text-gray-400 text-sm mb-4">
                      Guía completa para inscribirse y competir
                    </p>
                    <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                      Ver Tutorial
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <CreditCard className="w-12 h-12 mx-auto mb-4 text-purple-400" />
                    <h3 className="text-white font-semibold mb-2">Sistema de Pagos</h3>
                    <p className="text-gray-400 text-sm mb-4">
                      Cómo funcionan los pagos y reembolsos
                    </p>
                    <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                      Ver Tutorial
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <HelpCircle className="w-12 h-12 mx-auto mb-4 text-red-400" />
                    <h3 className="text-white font-semibold mb-2">Solución de Problemas</h3>
                    <p className="text-gray-400 text-sm mb-4">
                      Resuelve los problemas más comunes
                    </p>
                    <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                      Ver Tutorial
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <MessageCircle className="w-12 h-12 mx-auto mb-4 text-blue-400" />
                    <h3 className="text-white font-semibold mb-2">Chat y Comunicación</h3>
                    <p className="text-gray-400 text-sm mb-4">
                      Usa las herramientas de comunicación
                    </p>
                    <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                      Ver Tutorial
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
