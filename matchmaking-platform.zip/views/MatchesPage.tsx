"use client"

import { useState, useEffect } from "react"
import { Plus, Search, Calendar } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Sidebar from "../components/Sidebar"
import MatchCard from "../components/MatchCard"
import MatchFilters from "../components/MatchFilters"
import CreateMatchModal from "../components/CreateMatchModal"
import { Match, MatchFilters as IMatchFilters, CreateMatchForm, User } from "../models/types"
import { mockMatches } from "../services/mockData"

export default function MatchesPage() {
  const [matches, setMatches] = useState<Match[]>([])
  const [filteredMatches, setFilteredMatches] = useState<Match[]>([])
  const [filters, setFilters] = useState<IMatchFilters>({})
  const [searchTerm, setSearchTerm] = useState("")
  const [showCreateModal, setShowCreateModal] = useState(false)

  useEffect(() => {
    setMatches(mockMatches)
    setFilteredMatches(mockMatches)
  }, [])

  useEffect(() => {
    let result = matches.filter(match => {
      // Aplicar filtros
      if (filters.type && match.type !== filters.type) return false
      if (filters.skillLevel && match.skillLevel !== filters.skillLevel) return false
      if (filters.gender && match.gender !== filters.gender && match.gender !== "mixto") return false
      if (filters.position && !match.needsPositions.includes(filters.position)) return false
      
      return true
    })
    
    if (searchTerm) {
      result = result.filter(match => 
        match.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        match.location.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
        match.organizer.name.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }
    
    setFilteredMatches(result)
  }, [filters, searchTerm, matches])

  const handleFiltersChange = (newFilters: IMatchFilters) => {
    setFilters(newFilters)
  }

  const handleJoinMatch = (matchId: string) => {
    // Simular unirse al partido
    setMatches(prevMatches => 
      prevMatches.map(match => {
        if (match.id === matchId && match.currentPlayers.length < match.maxPlayers) {
          // En producción, aquí agregarías el usuario actual a la lista
          // Por ahora solo simulamos el incremento
          return {
            ...match,
            currentPlayers: [
              ...match.currentPlayers,
              // Mock user joining
              {
                id: "current-user",
                name: "Usuario",
                lastName: "Actual",
                email: "usuario@mail.com",
                avatar: "/placeholder.svg?height=40&width=40"
              } as User
            ]
          }
        }
        return match
      })
    )
    alert("¡Te uniste al partido exitosamente!")
  }

  const handleCreateMatch = async (matchData: CreateMatchForm) => {
    // Simular creación de partido
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    const newMatch: Match = {
      id: 'match-' + Date.now(),
      ...matchData,
      organizer: {
        id: "current-user",
        name: "Usuario",
        lastName: "Actual",
        email: "usuario@mail.com",
        avatar: "/placeholder.svg?height=40&width=40",
        rating: 4.0,
        totalMatches: 10
      } as any,
      currentPlayers: [],
      waitingList: [],
      status: "open",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      currency: "ARS"
    }
    
    setMatches(prevMatches => [newMatch, ...prevMatches])
    alert("¡Partido creado exitosamente!")
  }

  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar currentPage="partidos" />
      
      <main className="flex-1 md:ml-0">
        <div className="container mx-auto px-4 py-8 md:px-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 mt-16 md:mt-0">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Partidos Disponibles</h1>
              <p className="text-gray-400">Encuentra el partido perfecto para ti</p>
            </div>
            <Button 
              className="bg-green-500 hover:bg-green-600 text-white mt-4 md:mt-0"
              onClick={() => setShowCreateModal(true)}
            >
              <Plus className="w-4 h-4 mr-2" />
              Crear Partido
            </Button>
          </div>

          {/* Search bar */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Buscar partidos por título, ubicación o organizador..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-green-500"
            />
          </div>

          {/* Filters */}
          <MatchFilters
            onFiltersChange={handleFiltersChange}
            activeFilters={filters}
          />

          {/* Results count */}
          <div className="flex justify-between items-center mb-6">
            <p className="text-gray-400">
              {filteredMatches.length} {filteredMatches.length === 1 ? 'partido encontrado' : 'partidos encontrados'}
            </p>
          </div>

          {/* Matches grid */}
          {filteredMatches.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredMatches.map((match) => (
                <MatchCard
                  key={match.id}
                  match={match}
                  onJoin={handleJoinMatch}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-4">
                <Calendar className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p className="text-xl mb-2">No se encontraron partidos</p>
                <p>Intenta ajustar los filtros o crear un nuevo partido</p>
              </div>
              <Button 
                className="bg-green-500 hover:bg-green-600 text-white mt-4"
                onClick={() => setShowCreateModal(true)}
              >
                <Plus className="w-4 h-4 mr-2" />
                Crear Primer Partido
              </Button>
            </div>
          )}
        </div>
      </main>

      {/* Create Match Modal */}
      <CreateMatchModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSubmit={handleCreateMatch}
      />
    </div>
  )
}
