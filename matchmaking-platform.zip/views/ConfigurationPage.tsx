"use client"

import { useState } from "react"
import { Save, Bell, Shield, User, Palette, Globe } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import Sidebar from "../components/Sidebar"
import { useAuth } from "../contexts/AuthContext"

export default function ConfigurationPage() {
  const { user, updateUser } = useAuth()
  const [settings, setSettings] = useState({
    notifications: {
      email: user?.preferences.notifications.email || true,
      push: user?.preferences.notifications.push || true,
      sms: user?.preferences.notifications.sms || false,
      matchReminders: true,
      tournamentUpdates: true,
      newMessages: true
    },
    privacy: {
      showPhone: user?.preferences.privacy.showPhone || false,
      showEmail: user?.preferences.privacy.showEmail || false,
      showLocation: user?.preferences.privacy.showLocation || true,
      profileVisibility: "public"
    },
    appearance: {
      theme: "dark",
      language: "es"
    }
  })

  const handleSave = () => {
    if (user) {
      updateUser({
        ...user,
        preferences: {
          ...user.preferences,
          notifications: {
            email: settings.notifications.email,
            push: settings.notifications.push,
            sms: settings.notifications.sms
          },
          privacy: {
            showPhone: settings.privacy.showPhone,
            showEmail: settings.privacy.showEmail,
            showLocation: settings.privacy.showLocation
          }
        }
      })
    }
    alert("Configuración guardada exitosamente!")
  }

  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar currentPage="configuracion" />
      
      <main className="flex-1 md:ml-0">
        <div className="container mx-auto px-4 py-8 md:px-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 mt-16 md:mt-0">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Configuración</h1>
              <p className="text-gray-400">Personaliza tu experiencia en la plataforma</p>
            </div>
            <Button onClick={handleSave} className="bg-green-500 hover:bg-green-600 text-white mt-4 md:mt-0">
              <Save className="w-4 h-4 mr-2" />
              Guardar Cambios
            </Button>
          </div>

          <Tabs defaultValue="notifications" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800 mb-6">
              <TabsTrigger value="notifications" className="text-gray-300 data-[state=active]:text-white">
                <Bell className="w-4 h-4 mr-2" />
                Notificaciones
              </TabsTrigger>
              <TabsTrigger value="privacy" className="text-gray-300 data-[state=active]:text-white">
                <Shield className="w-4 h-4 mr-2" />
                Privacidad
              </TabsTrigger>
              <TabsTrigger value="account" className="text-gray-300 data-[state=active]:text-white">
                <User className="w-4 h-4 mr-2" />
                Cuenta
              </TabsTrigger>
              <TabsTrigger value="appearance" className="text-gray-300 data-[state=active]:text-white">
                <Palette className="w-4 h-4 mr-2" />
                Apariencia
              </TabsTrigger>
            </TabsList>

            {/* Notificaciones */}
            <TabsContent value="notifications">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Configuración de Notificaciones</CardTitle>
                  <CardDescription className="text-gray-400">
                    Elige cómo y cuándo quieres recibir notificaciones
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white">Canales de Notificación</h3>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-white">Notificaciones por Email</Label>
                        <p className="text-sm text-gray-400">Recibir actualizaciones por correo electrónico</p>
                      </div>
                      <Switch
                        checked={settings.notifications.email}
                        onCheckedChange={(checked) => 
                          setSettings(prev => ({
                            ...prev,
                            notifications: { ...prev.notifications, email: checked }
                          }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-white">Notificaciones Push</Label>
                        <p className="text-sm text-gray-400">Notificaciones en tiempo real en tu dispositivo</p>
                      </div>
                      <Switch
                        checked={settings.notifications.push}
                        onCheckedChange={(checked) => 
                          setSettings(prev => ({
                            ...prev,
                            notifications: { ...prev.notifications, push: checked }
                          }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-white">SMS</Label>
                        <p className="text-sm text-gray-400">Mensajes de texto para eventos importantes</p>
                      </div>
                      <Switch
                        checked={settings.notifications.sms}
                        onCheckedChange={(checked) => 
                          setSettings(prev => ({
                            ...prev,
                            notifications: { ...prev.notifications, sms: checked }
                          }))
                        }
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white">Tipos de Notificación</h3>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-white">Recordatorios de Partidos</Label>
                        <p className="text-sm text-gray-400">Te avisamos antes de tus partidos</p>
                      </div>
                      <Switch
                        checked={settings.notifications.matchReminders}
                        onCheckedChange={(checked) => 
                          setSettings(prev => ({
                            ...prev,
                            notifications: { ...prev.notifications, matchReminders: checked }
                          }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-white">Actualizaciones de Torneos</Label>
                        <p className="text-sm text-gray-400">Novedades sobre tus torneos</p>
                      </div>
                      <Switch
                        checked={settings.notifications.tournamentUpdates}
                        onCheckedChange={(checked) => 
                          setSettings(prev => ({
                            ...prev,
                            notifications: { ...prev.notifications, tournamentUpdates: checked }
                          }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-white">Nuevos Mensajes</Label>
                        <p className="text-sm text-gray-400">Cuando recibas mensajes de otros jugadores</p>
                      </div>
                      <Switch
                        checked={settings.notifications.newMessages}
                        onCheckedChange={(checked) => 
                          setSettings(prev => ({
                            ...prev,
                            notifications: { ...prev.notifications, newMessages: checked }
                          }))
                        }
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Privacidad */}
            <TabsContent value="privacy">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Configuración de Privacidad</CardTitle>
                  <CardDescription className="text-gray-400">
                    Controla qué información es visible para otros usuarios
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white">Información Visible</h3>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-white">Mostrar Teléfono</Label>
                        <p className="text-sm text-gray-400">Otros jugadores pueden ver tu número</p>
                      </div>
                      <Switch
                        checked={settings.privacy.showPhone}
                        onCheckedChange={(checked) => 
                          setSettings(prev => ({
                            ...prev,
                            privacy: { ...prev.privacy, showPhone: checked }
                          }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-white">Mostrar Email</Label>
                        <p className="text-sm text-gray-400">Visible para organizadores de partidos</p>
                      </div>
                      <Switch
                        checked={settings.privacy.showEmail}
                        onCheckedChange={(checked) => 
                          setSettings(prev => ({
                            ...prev,
                            privacy: { ...prev.privacy, showEmail: checked }
                          }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-white">Mostrar Ubicación</Label>
                        <p className="text-sm text-gray-400">Para encontrar partidos cercanos</p>
                      </div>
                      <Switch
                        checked={settings.privacy.showLocation}
                        onCheckedChange={(checked) => 
                          setSettings(prev => ({
                            ...prev,
                            privacy: { ...prev.privacy, showLocation: checked }
                          }))
                        }
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white">Visibilidad del Perfil</h3>
                    <Select
                      value={settings.privacy.profileVisibility}
                      onValueChange={(value) => 
                        setSettings(prev => ({
                          ...prev,
                          privacy: { ...prev.privacy, profileVisibility: value }
                        }))
                      }
                    >
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-700">
                        <SelectItem value="public">Público</SelectItem>
                        <SelectItem value="friends">Solo Amigos</SelectItem>
                        <SelectItem value="private">Privado</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Cuenta */}
            <TabsContent value="account">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Configuración de Cuenta</CardTitle>
                  <CardDescription className="text-gray-400">
                    Gestiona tu cuenta y datos personales
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="text-center py-8">
                    <User className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                    <p className="text-gray-400 mb-4">Configuración de cuenta en desarrollo</p>
                    <p className="text-sm text-gray-500">
                      Próximamente: cambio de contraseña, eliminación de cuenta, exportar datos
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Apariencia */}
            <TabsContent value="appearance">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Configuración de Apariencia</CardTitle>
                  <CardDescription className="text-gray-400">
                    Personaliza la apariencia de la aplicación
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div>
                      <Label className="text-white mb-2 block">Tema</Label>
                      <Select
                        value={settings.appearance.theme}
                        onValueChange={(value) => 
                          setSettings(prev => ({
                            ...prev,
                            appearance: { ...prev.appearance, theme: value }
                          }))
                        }
                      >
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-800 border-gray-700">
                          <SelectItem value="dark">Oscuro</SelectItem>
                          <SelectItem value="light">Claro</SelectItem>
                          <SelectItem value="auto">Automático</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-white mb-2 block">Idioma</Label>
                      <Select
                        value={settings.appearance.language}
                        onValueChange={(value) => 
                          setSettings(prev => ({
                            ...prev,
                            appearance: { ...prev.appearance, language: value }
                          }))
                        }
                      >
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-800 border-gray-700">
                          <SelectItem value="es">Español</SelectItem>
                          <SelectItem value="en">English</SelectItem>
                          <SelectItem value="pt">Português</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
