"use client"

import { useState, useEffect } from "react"
import { Edit, Camera, Trophy, Target, Users, Star, Calendar, MapPin, Phone, Mail } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Sidebar from "../components/Sidebar"
import { useAuth } from "../contexts/AuthContext"
import { User, SkillLevel, Position, Gender } from "../models/types"

export default function ProfilePage() {
  const { user, updateUser } = useAuth()
  const [isEditing, setIsEditing] = useState(false)
  const [editedUser, setEditedUser] = useState<User | null>(null)

  useEffect(() => {
    if (user) {
      setEditedUser({ ...user })
    }
  }, [user])

  const handleSave = () => {
    if (editedUser) {
      updateUser(editedUser)
      setIsEditing(false)
    }
  }

  const handleCancel = () => {
    if (user) {
      setEditedUser({ ...user })
      setIsEditing(false)
    }
  }

  if (!user || !editedUser) {
    return (
      <div className="flex min-h-screen bg-gray-900">
        <Sidebar currentPage="perfil" />
        <main className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-green-500"></div>
        </main>
      </div>
    )
  }

  const skillLevels: { value: SkillLevel; label: string }[] = [
    { value: "casual", label: "Casual" },
    { value: "intermedio", label: "Intermedio" },
    { value: "competitivo", label: "Competitivo" }
  ]

  const positions: { value: Position; label: string }[] = [
    { value: "arquero", label: "Arquero" },
    { value: "defensor", label: "Defensor" },
    { value: "mediocampista", label: "Mediocampista" },
    { value: "delantero", label: "Delantero" },
    { value: "cualquiera", label: "Cualquiera" }
  ]

  const genders: { value: Gender; label: string }[] = [
    { value: "masculino", label: "Masculino" },
    { value: "femenino", label: "Femenino" }
  ]

  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar currentPage="perfil" />
      
      <main className="flex-1 md:ml-0">
        <div className="container mx-auto px-4 py-8 md:px-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 mt-16 md:mt-0">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Mi Perfil</h1>
              <p className="text-gray-400">Gestiona tu información personal y estadísticas</p>
            </div>
            <Button
              onClick={isEditing ? handleSave : () => setIsEditing(true)}
              className="bg-green-500 hover:bg-green-600 text-white mt-4 md:mt-0"
            >
              <Edit className="w-4 h-4 mr-2" />
              {isEditing ? 'Guardar Cambios' : 'Editar Perfil'}
            </Button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Profile Card */}
            <div className="lg:col-span-1">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="text-center">
                  <div className="relative mx-auto mb-4">
                    <img
                      src={user.avatar || "/placeholder.svg"}
                      alt={user.name}
                      className="w-24 h-24 rounded-full mx-auto"
                    />
                    {isEditing && (
                      <Button
                        size="sm"
                        className="absolute bottom-0 right-0 rounded-full w-8 h-8 p-0 bg-green-500 hover:bg-green-600"
                      >
                        <Camera className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                  <CardTitle className="text-white">
                    {user.name} {user.lastName}
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    {user.role === 'admin' ? 'Administrador' : 
                     user.role === 'organizer' ? 'Organizador' : 'Jugador'}
                  </CardDescription>
                  
                  <div className="flex justify-center items-center mt-2">
                    <Star className="w-4 h-4 text-yellow-400 mr-1 fill-current" />
                    <span className="text-white font-semibold">{user.rating.toFixed(1)}</span>
                    <span className="text-gray-400 text-sm ml-2">
                      ({user.totalMatches} partidos)
                    </span>
                  </div>
                </CardHeader>

                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center text-gray-300">
                      <MapPin className="w-4 h-4 mr-2" />
                      <span className="text-sm">{user.location.city}, {user.location.country}</span>
                    </div>
                    <div className="flex items-center text-gray-300">
                      <Target className="w-4 h-4 mr-2" />
                      <span className="text-sm capitalize">{user.position}</span>
                    </div>
                    <div className="flex items-center text-gray-300">
                      <Trophy className="w-4 h-4 mr-2" />
                      <span className="text-sm capitalize">{user.skillLevel}</span>
                    </div>
                    
                    {/* Reliability */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Confiabilidad</span>
                        <span className="text-white">{user.stats.reliability}%</span>
                      </div>
                      <Progress value={user.stats.reliability} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <Card className="bg-gray-800 border-gray-700 mt-6">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Estadísticas Rápidas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400">{user.stats.matchesWon}</div>
                      <div className="text-xs text-gray-400">Ganados</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-400">{user.stats.matchesLost}</div>
                      <div className="text-xs text-gray-400">Perdidos</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-yellow-400">{user.stats.goalsScored}</div>
                      <div className="text-xs text-gray-400">Goles</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-400">{user.stats.assists}</div>
                      <div className="text-xs text-gray-400">Asistencias</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-2">
              <Tabs defaultValue="info" className="w-full">
                <TabsList className="grid w-full grid-cols-4 bg-gray-800 border border-gray-700 rounded-lg p-1">
                  <TabsTrigger 
                    value="info" 
                    className="text-gray-400 data-[state=active]:text-white data-[state=active]:bg-green-500 data-[state=active]:shadow-lg transition-all duration-200 rounded-md font-medium"
                  >
                    Información
                  </TabsTrigger>
                  <TabsTrigger 
                    value="stats" 
                    className="text-gray-400 data-[state=active]:text-white data-[state=active]:bg-green-500 data-[state=active]:shadow-lg transition-all duration-200 rounded-md font-medium"
                  >
                    Estadísticas
                  </TabsTrigger>
                  <TabsTrigger 
                    value="analytics" 
                    className="text-gray-400 data-[state=active]:text-white data-[state=active]:bg-green-500 data-[state=active]:shadow-lg transition-all duration-200 rounded-md font-medium"
                  >
                    Analíticas
                  </TabsTrigger>
                  <TabsTrigger 
                    value="settings" 
                    className="text-gray-400 data-[state=active]:text-white data-[state=active]:bg-green-500 data-[state=active]:shadow-lg transition-all duration-200 rounded-md font-medium"
                  >
                    Configuración
                  </TabsTrigger>
                </TabsList>

                {/* Información Personal */}
                <TabsContent value="info">
                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white">Información Personal</CardTitle>
                      <CardDescription className="text-gray-400">
                        Datos básicos de tu perfil
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="name" className="text-gray-300">Nombre</Label>
                          <Input
                            id="name"
                            value={editedUser.name}
                            onChange={(e) => setEditedUser({ ...editedUser, name: e.target.value })}
                            disabled={!isEditing}
                            className="bg-gray-700 border-gray-600 text-white disabled:opacity-50"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="lastName" className="text-gray-300">Apellido</Label>
                          <Input
                            id="lastName"
                            value={editedUser.lastName}
                            onChange={(e) => setEditedUser({ ...editedUser, lastName: e.target.value })}
                            disabled={!isEditing}
                            className="bg-gray-700 border-gray-600 text-white disabled:opacity-50"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-gray-300">Email</Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <Input
                            id="email"
                            type="email"
                            value={editedUser.email}
                            disabled={true}
                            className="pl-10 bg-gray-700 border-gray-600 text-white opacity-50"
                          />
                        </div>
                        <p className="text-xs text-gray-500">El email no se puede modificar</p>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="phone" className="text-gray-300">Teléfono</Label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <Input
                            id="phone"
                            value={editedUser.phone || ''}
                            onChange={(e) => setEditedUser({ ...editedUser, phone: e.target.value })}
                            disabled={!isEditing}
                            className="pl-10 bg-gray-700 border-gray-600 text-white disabled:opacity-50"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="dateOfBirth" className="text-gray-300">Fecha de Nacimiento</Label>
                        <div className="relative">
                          <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <Input
                            id="dateOfBirth"
                            type="date"
                            value={editedUser.dateOfBirth}
                            onChange={(e) => setEditedUser({ ...editedUser, dateOfBirth: e.target.value })}
                            disabled={!isEditing}
                            className="pl-10 bg-gray-700 border-gray-600 text-white disabled:opacity-50"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="gender" className="text-gray-300">Género</Label>
                          <Select
                            value={editedUser.gender}
                            onValueChange={(value: Gender) => setEditedUser({ ...editedUser, gender: value })}
                            disabled={!isEditing}
                          >
                            <SelectTrigger className="bg-gray-700 border-gray-600 text-white disabled:opacity-50">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-800 border-gray-700">
                              {genders.map(gender => (
                                <SelectItem key={gender.value} value={gender.value}>
                                  {gender.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="position" className="text-gray-300">Posición</Label>
                          <Select
                            value={editedUser.position}
                            onValueChange={(value: Position) => setEditedUser({ ...editedUser, position: value })}
                            disabled={!isEditing}
                          >
                            <SelectTrigger className="bg-gray-700 border-gray-600 text-white disabled:opacity-50">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-800 border-gray-700">
                              {positions.map(position => (
                                <SelectItem key={position.value} value={position.value}>
                                  {position.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="skillLevel" className="text-gray-300">Nivel</Label>
                          <Select
                            value={editedUser.skillLevel}
                            onValueChange={(value: SkillLevel) => setEditedUser({ ...editedUser, skillLevel: value })}
                            disabled={!isEditing}
                          >
                            <SelectTrigger className="bg-gray-700 border-gray-600 text-white disabled:opacity-50">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-800 border-gray-700">
                              {skillLevels.map(level => (
                                <SelectItem key={level.value} value={level.value}>
                                  {level.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="city" className="text-gray-300">Ciudad</Label>
                        <div className="relative">
                          <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <Input
                            id="city"
                            value={editedUser.location.city}
                            onChange={(e) => setEditedUser({
                              ...editedUser,
                              location: { ...editedUser.location, city: e.target.value }
                            })}
                            disabled={!isEditing}
                            className="pl-10 bg-gray-700 border-gray-600 text-white disabled:opacity-50"
                          />
                        </div>
                      </div>

                      {isEditing && (
                        <div className="flex gap-4 pt-4">
                          <Button
                            onClick={handleCancel}
                            variant="outline"
                            className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
                          >
                            Cancelar
                          </Button>
                          <Button
                            onClick={handleSave}
                            className="flex-1 bg-green-500 hover:bg-green-600"
                          >
                            Guardar Cambios
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Estadísticas Detalladas */}
                <TabsContent value="stats">
                  <div className="space-y-6">
                    {/* Estadísticas de Partidos */}
                    <Card className="bg-gray-800 border-gray-700">
                      <CardHeader>
                        <CardTitle className="text-white">Estadísticas de Partidos</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div className="text-center p-4 bg-gray-700 rounded-lg">
                            <div className="text-2xl font-bold text-white">{user.totalMatches}</div>
                            <div className="text-sm text-gray-400">Total Jugados</div>
                          </div>
                          <div className="text-center p-4 bg-gray-700 rounded-lg">
                            <div className="text-2xl font-bold text-green-400">{user.stats.matchesWon}</div>
                            <div className="text-sm text-gray-400">Ganados</div>
                          </div>
                          <div className="text-center p-4 bg-gray-700 rounded-lg">
                            <div className="text-2xl font-bold text-yellow-400">{user.stats.matchesDrawn}</div>
                            <div className="text-sm text-gray-400">Empatados</div>
                          </div>
                          <div className="text-center p-4 bg-gray-700 rounded-lg">
                            <div className="text-2xl font-bold text-red-400">{user.stats.matchesLost}</div>
                            <div className="text-sm text-gray-400">Perdidos</div>
                          </div>
                        </div>

                        <div className="mt-6">
                          <div className="flex justify-between text-sm mb-2">
                            <span className="text-gray-400">Porcentaje de Victorias</span>
                            <span className="text-white">
                              {user.totalMatches > 0 ? Math.round((user.stats.matchesWon / user.totalMatches) * 100) : 0}%
                            </span>
                          </div>
                          <Progress 
                            value={user.totalMatches > 0 ? (user.stats.matchesWon / user.totalMatches) * 100 : 0} 
                            className="h-2"
                          />
                        </div>
                      </CardContent>
                    </Card>

                    {/* Estadísticas de Rendimiento */}
                    <Card className="bg-gray-800 border-gray-700">
                      <CardHeader>
                        <CardTitle className="text-white">Rendimiento</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div className="text-center p-4 bg-gray-700 rounded-lg">
                            <div className="text-2xl font-bold text-yellow-400">{user.stats.goalsScored}</div>
                            <div className="text-sm text-gray-400">Goles</div>
                          </div>
                          <div className="text-center p-4 bg-gray-700 rounded-lg">
                            <div className="text-2xl font-bold text-blue-400">{user.stats.assists}</div>
                            <div className="text-sm text-gray-400">Asistencias</div>
                          </div>
                          <div className="text-center p-4 bg-gray-700 rounded-lg">
                            <div className="text-2xl font-bold text-green-400">{user.stats.cleanSheets}</div>
                            <div className="text-sm text-gray-400">Vallas Invictas</div>
                          </div>
                          <div className="text-center p-4 bg-gray-700 rounded-lg">
                            <div className="text-2xl font-bold text-purple-400">{user.stats.averageRating.toFixed(1)}</div>
                            <div className="text-sm text-gray-400">Rating Promedio</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Badges y Logros */}
                    <Card className="bg-gray-800 border-gray-700">
                      <CardHeader>
                        <CardTitle className="text-white">Logros y Badges</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex flex-wrap gap-2">
                          {user.stats.reliability >= 95 && (
                            <Badge className="bg-green-500 text-white">
                              <Trophy className="w-3 h-3 mr-1" />
                              Jugador Confiable
                            </Badge>
                          )}
                          {user.totalMatches >= 50 && (
                            <Badge className="bg-blue-500 text-white">
                              <Users className="w-3 h-3 mr-1" />
                              Veterano
                            </Badge>
                          )}
                          {user.stats.goalsScored >= 20 && (
                            <Badge className="bg-yellow-500 text-white">
                              <Target className="w-3 h-3 mr-1" />
                              Goleador
                            </Badge>
                          )}
                          {user.rating >= 4.5 && (
                            <Badge className="bg-purple-500 text-white">
                              <Star className="w-3 h-3 mr-1" />
                              Estrella
                            </Badge>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                {/* Nueva pestaña de Analíticas */}
                <TabsContent value="analytics">
                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white">Analíticas Personales</CardTitle>
                      <CardDescription className="text-gray-400">
                        Análisis detallado de tu rendimiento
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Tiempo jugado */}
                      <div>
                        <h3 className="text-lg font-semibold text-white mb-4">Tiempo de Juego</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="bg-gray-700 p-4 rounded-lg text-center">
                            <div className="text-2xl font-bold text-blue-400">
                              {Math.floor((user.totalMatches * 90) / 60)}h
                            </div>
                            <div className="text-sm text-gray-400">Tiempo Total</div>
                          </div>
                          <div className="bg-gray-700 p-4 rounded-lg text-center">
                            <div className="text-2xl font-bold text-green-400">
                              {Math.round((user.totalMatches * 90) / 60 / 4.33)}h
                            </div>
                            <div className="text-sm text-gray-400">Promedio Mensual</div>
                          </div>
                          <div className="bg-gray-700 p-4 rounded-lg text-center">
                            <div className="text-2xl font-bold text-yellow-400">
                              {user.stats.reliability}%
                            </div>
                            <div className="text-sm text-gray-400">Asistencia</div>
                          </div>
                        </div>
                      </div>

                      {/* Comparación con otros usuarios */}
                      <div>
                        <h3 className="text-lg font-semibold text-white mb-4">Comparación Local</h3>
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">Goles por partido</span>
                            <div className="flex items-center">
                              <div className="w-32 bg-gray-700 rounded-full h-2 mr-3">
                                <div 
                                  className="bg-yellow-400 h-2 rounded-full" 
                                  style={{ width: `${Math.min((user.stats.goalsScored / user.totalMatches) * 100, 100)}%` }}
                                ></div>
                              </div>
                              <span className="text-white text-sm">
                                {user.totalMatches > 0 ? (user.stats.goalsScored / user.totalMatches).toFixed(1) : '0.0'}
                              </span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">Rating promedio</span>
                            <div className="flex items-center">
                              <div className="w-32 bg-gray-700 rounded-full h-2 mr-3">
                                <div 
                                  className="bg-purple-400 h-2 rounded-full" 
                                  style={{ width: `${(user.rating / 5) * 100}%` }}
                                ></div>
                              </div>
                              <span className="text-white text-sm">{user.rating.toFixed(1)}/5.0</span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">Confiabilidad</span>
                            <div className="flex items-center">
                              <div className="w-32 bg-gray-700 rounded-full h-2 mr-3">
                                <div 
                                  className="bg-green-400 h-2 rounded-full" 
                                  style={{ width: `${user.stats.reliability}%` }}
                                ></div>
                              </div>
                              <span className="text-white text-sm">{user.stats.reliability}%</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Posición en ranking */}
                      <div>
                        <h3 className="text-lg font-semibold text-white mb-4">Ranking Local</h3>
                        <div className="bg-gradient-to-r from-yellow-900/20 to-gray-700 p-4 rounded-lg border border-yellow-500/30">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-yellow-400 font-semibold">Top 15%</p>
                              <p className="text-gray-400 text-sm">En tu zona y categoría</p>
                            </div>
                            <Trophy className="w-8 h-8 text-yellow-400" />
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Configuración */}
                <TabsContent value="settings">
                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white">Configuración de Cuenta</CardTitle>
                      <CardDescription className="text-gray-400">
                        Gestiona tus preferencias y configuración de privacidad
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Notificaciones */}
                      <div>
                        <h3 className="text-lg font-semibold text-white mb-4">Notificaciones</h3>
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-white">Notificaciones por Email</p>
                              <p className="text-sm text-gray-400">Recibir actualizaciones por correo</p>
                            </div>
                            <input
                              type="checkbox"
                              checked={editedUser.preferences.notifications.email}
                              onChange={(e) => setEditedUser({
                                ...editedUser,
                                preferences: {
                                  ...editedUser.preferences,
                                  notifications: {
                                    ...editedUser.preferences.notifications,
                                    email: e.target.checked
                                  }
                                }
                              })}
                              className="w-4 h-4 text-green-500"
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-white">Notificaciones Push</p>
                              <p className="text-sm text-gray-400">Notificaciones en tiempo real</p>
                            </div>
                            <input
                              type="checkbox"
                              checked={editedUser.preferences.notifications.push}
                              onChange={(e) => setEditedUser({
                                ...editedUser,
                                preferences: {
                                  ...editedUser.preferences,
                                  notifications: {
                                    ...editedUser.preferences.notifications,
                                    push: e.target.checked
                                  }
                                }
                              })}
                              className="w-4 h-4 text-green-500"
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-white">SMS</p>
                              <p className="text-sm text-gray-400">Mensajes de texto importantes</p>
                            </div>
                            <input
                              type="checkbox"
                              checked={editedUser.preferences.notifications.sms}
                              onChange={(e) => setEditedUser({
                                ...editedUser,
                                preferences: {
                                  ...editedUser.preferences,
                                  notifications: {
                                    ...editedUser.preferences.notifications,
                                    sms: e.target.checked
                                  }
                                }
                              })}
                              className="w-4 h-4 text-green-500"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Privacidad */}
                      <div>
                        <h3 className="text-lg font-semibold text-white mb-4">Privacidad</h3>
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-white">Mostrar Teléfono</p>
                              <p className="text-sm text-gray-400">Visible para otros jugadores</p>
                            </div>
                            <input
                              type="checkbox"
                              checked={editedUser.preferences.privacy.showPhone}
                              onChange={(e) => setEditedUser({
                                ...editedUser,
                                preferences: {
                                  ...editedUser.preferences,
                                  privacy: {
                                    ...editedUser.preferences.privacy,
                                    showPhone: e.target.checked
                                  }
                                }
                              })}
                              className="w-4 h-4 text-green-500"
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-white">Mostrar Email</p>
                              <p className="text-sm text-gray-400">Visible para organizadores</p>
                            </div>
                            <input
                              type="checkbox"
                              checked={editedUser.preferences.privacy.showEmail}
                              onChange={(e) => setEditedUser({
                                ...editedUser,
                                preferences: {
                                  ...editedUser.preferences,
                                  privacy: {
                                    ...editedUser.preferences.privacy,
                                    showEmail: e.target.checked
                                  }
                                }
                              })}
                              className="w-4 h-4 text-green-500"
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-white">Mostrar Ubicación</p>
                              <p className="text-sm text-gray-400">Para encontrar partidos cercanos</p>
                            </div>
                            <input
                              type="checkbox"
                              checked={editedUser.preferences.privacy.showLocation}
                              onChange={(e) => setEditedUser({
                                ...editedUser,
                                preferences: {
                                  ...editedUser.preferences,
                                  privacy: {
                                    ...editedUser.preferences.privacy,
                                    showLocation: e.target.checked
                                  }
                                }
                              })}
                              className="w-4 h-4 text-green-500"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="pt-4 border-t border-gray-700">
                        <Button
                          onClick={handleSave}
                          className="w-full bg-green-500 hover:bg-green-600"
                        >
                          Guardar Configuración
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
