"use client"

import { useState, useEffect } from "react"
import { Plus, Search, Play, Heart, MessageCircle, Share2, Filter, Calendar, MapPin, Users, Trophy, Upload, Bookmark, MoreHorizontal } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Sidebar from "../components/Sidebar"
import { useAuth } from "../contexts/AuthContext"

interface Highlight {
  id: string
  title: string
  description: string
  videoUrl: string
  thumbnail: string
  author: {
    id: string
    name: string
    avatar: string
    role: string
    isVerified: boolean
  }
  match: {
    id: string
    title: string
    date: string
    location: string
    type: string
    score?: string
    participants: string[]
  }
  stats: {
    likes: number
    comments: number
    shares: number
    views: number
    saves: number
  }
  tags: string[]
  createdAt: string
  isLiked: boolean
  isSaved: boolean
  duration: string
  isTopWeek?: boolean
}

export default function HighlightsPage() {
  const { user } = useAuth()
  const [highlights, setHighlights] = useState<Highlight[]>([])
  const [filteredHighlights, setFilteredHighlights] = useState<Highlight[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState<string>("all")
  const [showUploadModal, setShowUploadModal] = useState(false)
  const [viewMode, setViewMode] = useState<'grid' | 'feed'>('feed')
  const [showComments, setShowComments] = useState<string | null>(null)
  const [comments, setComments] = useState<{[key: string]: any[]}>({})

  // Mock data mejorado
  const mockHighlights: Highlight[] = [
    {
      id: "highlight-001",
      title: "Golazo de media cancha! 🚀",
      description: "No podía creer que entró! Desde el medio de la cancha directo al ángulo. El arquero ni se movió. #golazo #futbol5 #increible",
      videoUrl: "/placeholder-video.mp4",
      thumbnail: "/placeholder.svg?height=400&width=300&text=Golazo+Media+Cancha",
      author: {
        id: "user-001",
        name: "Juan Pérez",
        avatar: "/placeholder.svg?height=40&width=40&text=JP",
        role: "player",
        isVerified: true
      },
      match: {
        id: "match-001",
        title: "Fútbol 5 - Palermo",
        date: "2024-01-20",
        location: "Cancha Los Amigos",
        type: "futbol5",
        score: "3-2",
        participants: ["Juan Pérez", "Carlos López", "Ana García", "Miguel Torres", "Laura Ruiz"]
      },
      stats: {
        likes: 245,
        comments: 32,
        shares: 18,
        views: 1234,
        saves: 45
      },
      tags: ["golazo", "media-cancha", "futbol5", "increible"],
      createdAt: "2024-01-21T10:30:00Z",
      isLiked: false,
      isSaved: false,
      duration: "0:15",
      isTopWeek: true
    },
    {
      id: "highlight-002",
      title: "Atajada increíble del arquero 🥅",
      description: "Salvó el partido con esta atajada. Parecía gol cantado pero apareció como un felino. Increíble reflejo! #atajada #arquero #salvada",
      videoUrl: "/placeholder-video.mp4",
      thumbnail: "/placeholder.svg?height=400&width=300&text=Atajada+Increible",
      author: {
        id: "user-002",
        name: "María González",
        avatar: "/placeholder.svg?height=40&width=40&text=MG",
        role: "organizer",
        isVerified: true
      },
      match: {
        id: "match-002",
        title: "Fútbol 11 - Belgrano",
        date: "2024-01-19",
        location: "Complejo Norte",
        type: "futbol11",
        score: "1-0",
        participants: ["María González", "Roberto Silva", "Carmen Díaz", "Fernando Vega"]
      },
      stats: {
        likes: 367,
        comments: 48,
        shares: 25,
        views: 2156,
        saves: 67
      },
      tags: ["atajada", "arquero", "futbol11", "salvada"],
      createdAt: "2024-01-20T15:45:00Z",
      isLiked: true,
      isSaved: true,
      duration: "0:12",
      isTopWeek: true
    },
    {
      id: "highlight-003",
      title: "Jugada colectiva perfecta ⚽",
      description: "10 pases consecutivos que terminaron en gol. Así se juega al fútbol! Trabajo en equipo puro. #jugadacolectiva #teamwork #gol",
      videoUrl: "/placeholder-video.mp4",
      thumbnail: "/placeholder.svg?height=400&width=300&text=Jugada+Colectiva",
      author: {
        id: "admin-001",
        name: "Admin Sistema",
        avatar: "/placeholder.svg?height=40&width=40&text=Admin",
        role: "admin",
        isVerified: true
      },
      match: {
        id: "match-003",
        title: "Fútbol 8 - Villa Crespo",
        date: "2024-01-18",
        location: "Cancha Central",
        type: "futbol8",
        score: "4-1",
        participants: ["Admin Sistema", "Pedro Martín", "Sofía Castro", "Diego Morales"]
      },
      stats: {
        likes: 189,
        comments: 25,
        shares: 22,
        views: 978,
        saves: 34
      },
      tags: ["jugada-colectiva", "gol", "futbol8", "teamwork"],
      createdAt: "2024-01-19T09:20:00Z",
      isLiked: false,
      isSaved: false,
      duration: "0:25"
    }
  ]

  useEffect(() => {
    setHighlights(mockHighlights)
    setFilteredHighlights(mockHighlights)
  }, [])

  useEffect(() => {
    let result = highlights

    // Filtrar por tipo
    if (filterType !== "all") {
      result = result.filter(highlight => highlight.match.type === filterType)
    }

    // Filtrar por búsqueda
    if (searchTerm) {
      result = result.filter(highlight => 
        highlight.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        highlight.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        highlight.author.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        highlight.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      )
    }

    setFilteredHighlights(result)
  }, [searchTerm, filterType, highlights])

  const handleLike = (highlightId: string) => {
    setHighlights(prev => 
      prev.map(highlight => 
        highlight.id === highlightId 
          ? {
              ...highlight,
              isLiked: !highlight.isLiked,
              stats: {
                ...highlight.stats,
                likes: highlight.isLiked ? highlight.stats.likes - 1 : highlight.stats.likes + 1
              }
            }
          : highlight
      )
    )
  }

  const handleSave = (highlightId: string) => {
    setHighlights(prev => 
      prev.map(highlight => 
        highlight.id === highlightId 
          ? {
              ...highlight,
              isSaved: !highlight.isSaved,
              stats: {
                ...highlight.stats,
                saves: highlight.isSaved ? highlight.stats.saves - 1 : highlight.stats.saves + 1
              }
            }
          : highlight
      )
    )
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "futbol5": return "bg-blue-600"
      case "futbol8": return "bg-purple-600"
      case "futbol11": return "bg-green-600"
      default: return "bg-gray-600"
    }
  }

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`
    if (num >= 1000) return `${(num / 1000).toFixed(1)}k`
    return num.toString()
  }

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))
    
    if (diffInHours < 1) return 'Hace unos minutos'
    if (diffInHours < 24) return `Hace ${diffInHours}h`
    if (diffInHours < 48) return 'Ayer'
    return date.toLocaleDateString('es-AR')
  }

  const handleShowComments = (highlightId: string) => {
    setShowComments(highlightId)
    // Simular carga de comentarios
    if (!comments[highlightId]) {
      setComments(prev => ({
        ...prev,
        [highlightId]: [
          {
            id: "comment-1",
            user: { name: "Carlos López", avatar: "/placeholder.svg?height=32&width=32&text=CL" },
            text: "¡Qué golazo! Increíble técnica",
            timestamp: "2024-01-25T11:00:00Z",
            likes: 5
          },
          {
            id: "comment-2", 
            user: { name: "Ana García", avatar: "/placeholder.svg?height=32&width=32&text=AG" },
            text: "Ese arquero no tuvo oportunidad 😂",
            timestamp: "2024-01-25T11:15:00Z",
            likes: 2
          }
        ]
      }))
    }
  }

  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar currentPage="highlights" />
      
      <main className="flex-1 md:ml-0">
        <div className="container mx-auto px-4 py-8 md:px-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 mt-16 md:mt-0">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Highlights</h1>
              <p className="text-gray-400">Los mejores momentos de nuestros partidos</p>
            </div>
            <div className="flex gap-2 mt-4 md:mt-0">
              <Button
                variant={viewMode === 'feed' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('feed')}
                className="border-gray-600"
              >
                Feed
              </Button>
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="border-gray-600"
              >
                Grid
              </Button>
              <Button 
                className="bg-green-500 hover:bg-green-600 text-white"
                onClick={() => setShowUploadModal(true)}
              >
                <Upload className="w-4 h-4 mr-2" />
                Subir Clip
              </Button>
            </div>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                type="text"
                placeholder="Buscar highlights por título, descripción o jugador..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-green-500"
              />
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-full md:w-48 bg-gray-800 border-gray-700 text-white">
                <SelectValue placeholder="Filtrar por tipo" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700">
                <SelectItem value="all">Todos los tipos</SelectItem>
                <SelectItem value="futbol5">Fútbol 5</SelectItem>
                <SelectItem value="futbol8">Fútbol 8</SelectItem>
                <SelectItem value="futbol11">Fútbol 11</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="recientes" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800 mb-6">
              <TabsTrigger value="recientes" className="text-gray-300 data-[state=active]:text-white">
                Recientes
              </TabsTrigger>
              <TabsTrigger value="populares" className="text-gray-300 data-[state=active]:text-white">
                Populares
              </TabsTrigger>
              <TabsTrigger value="top-semana" className="text-gray-300 data-[state=active]:text-white">
                Top Semana
              </TabsTrigger>
              <TabsTrigger value="mis-clips" className="text-gray-300 data-[state=active]:text-white">
                Mis Clips
              </TabsTrigger>
            </TabsList>

            <TabsContent value="recientes">
              {viewMode === 'feed' ? (
                // Vista Feed estilo TikTok
                <div className="max-w-md mx-auto space-y-6">
                  {filteredHighlights.map((highlight) => (
                    <Card key={highlight.id} className="bg-gray-800 border-gray-700 overflow-hidden">
                      {/* Header del post */}
                      <div className="p-4 pb-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <Avatar className="w-10 h-10">
                              <AvatarImage src={highlight.author.avatar || "/placeholder.svg"} />
                              <AvatarFallback>{highlight.author.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="flex items-center">
                                <p className="text-white font-semibold text-sm">{highlight.author.name}</p>
                                {highlight.author.isVerified && (
                                  <div className="w-4 h-4 bg-blue-500 rounded-full ml-1 flex items-center justify-center">
                                    <div className="w-2 h-2 bg-white rounded-full"></div>
                                  </div>
                                )}
                              </div>
                              <p className="text-gray-400 text-xs">{formatTimestamp(highlight.createdAt)}</p>
                            </div>
                          </div>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="w-4 h-4 text-gray-400" />
                          </Button>
                        </div>
                      </div>

                      {/* Video/Imagen */}
                      <div className="relative">
                        <img
                          src={highlight.thumbnail || "/placeholder.svg"}
                          alt={highlight.title}
                          className="w-full h-96 object-cover"
                        />
                        <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity cursor-pointer">
                          <Play className="w-16 h-16 text-white" />
                        </div>
                        <div className="absolute bottom-3 right-3 bg-black/70 text-white px-2 py-1 rounded text-xs">
                          {highlight.duration}
                        </div>
                        <div className="absolute top-3 left-3">
                          <Badge className={`${getTypeColor(highlight.match.type)} text-white text-xs`}>
                            {highlight.match.type.toUpperCase()}
                          </Badge>
                        </div>
                        {highlight.isTopWeek && (
                          <div className="absolute top-3 right-3">
                            <Badge className="bg-yellow-500 text-black text-xs">
                              <Trophy className="w-3 h-3 mr-1" />
                              TOP
                            </Badge>
                          </div>
                        )}
                      </div>

                      {/* Acciones */}
                      <div className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-4">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleLike(highlight.id)}
                              className={`p-0 ${highlight.isLiked ? 'text-red-500' : 'text-gray-400'} hover:text-red-400`}
                            >
                              <Heart className={`w-6 h-6 ${highlight.isLiked ? 'fill-current' : ''}`} />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="p-0 text-gray-400 hover:text-blue-400"
                              onClick={() => handleShowComments(highlight.id)}
                            >
                              <MessageCircle className="w-6 h-6" />
                            </Button>
                            <Button variant="ghost" size="sm" className="p-0 text-gray-400 hover:text-green-400">
                              <Share2 className="w-6 h-6" />
                            </Button>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleSave(highlight.id)}
                            className={`p-0 ${highlight.isSaved ? 'text-yellow-500' : 'text-gray-400'} hover:text-yellow-400`}
                          >
                            <Bookmark className={`w-6 h-6 ${highlight.isSaved ? 'fill-current' : ''}`} />
                          </Button>
                        </div>

                        {/* Stats */}
                        <div className="flex items-center space-x-4 text-sm text-gray-400 mb-3">
                          <span>{formatNumber(highlight.stats.likes)} likes</span>
                          <span>{formatNumber(highlight.stats.views)} vistas</span>
                          <span>{highlight.stats.comments} comentarios</span>
                        </div>

                        {/* Título y descripción */}
                        <div className="mb-3">
                          <h3 className="text-white font-semibold mb-1">{highlight.title}</h3>
                          <p className="text-gray-300 text-sm">{highlight.description}</p>
                        </div>

                        {/* Info del partido */}
                        <div className="bg-gray-700 rounded-lg p-3 mb-3">
                          <div className="flex items-center justify-between mb-2">
                            <p className="text-white text-sm font-medium">{highlight.match.title}</p>
                            {highlight.match.score && (
                              <Badge variant="outline" className="text-green-400 border-green-400 text-xs">
                                {highlight.match.score}
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center text-gray-400 text-xs mb-2">
                            <Calendar className="w-3 h-3 mr-1" />
                            <span className="mr-3">{new Date(highlight.match.date).toLocaleDateString('es-AR')}</span>
                            <MapPin className="w-3 h-3 mr-1" />
                            <span>{highlight.match.location}</span>
                          </div>
                          <div className="flex items-center text-gray-400 text-xs">
                            <Users className="w-3 h-3 mr-1" />
                            <span>Con: {highlight.match.participants.slice(0, 3).join(', ')}</span>
                            {highlight.match.participants.length > 3 && (
                              <span> y {highlight.match.participants.length - 3} más</span>
                            )}
                          </div>
                        </div>

                        {/* Tags */}
                        <div className="flex flex-wrap gap-1">
                          {highlight.tags.slice(0, 4).map((tag, index) => (
                            <Badge key={index} variant="outline" className="text-xs text-blue-400 border-blue-400">
                              #{tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                // Vista Grid tradicional
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredHighlights.map((highlight) => (
                    <Card key={highlight.id} className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-all duration-300 hover:border-green-500/50 overflow-hidden">
                      {/* Video Thumbnail */}
                      <div className="relative">
                        <img
                          src={highlight.thumbnail || "/placeholder.svg"}
                          alt={highlight.title}
                          className="w-full h-48 object-cover"
                        />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity cursor-pointer">
                          <Play className="w-12 h-12 text-white" />
                        </div>
                        <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
                          {highlight.duration}
                        </div>
                        <div className="absolute top-2 left-2">
                          <Badge className={`${getTypeColor(highlight.match.type)} text-white text-xs`}>
                            {highlight.match.type.toUpperCase()}
                          </Badge>
                        </div>
                        {highlight.isTopWeek && (
                          <div className="absolute top-2 right-2">
                            <Badge className="bg-yellow-500 text-black text-xs">
                              <Trophy className="w-3 h-3 mr-1" />
                              TOP
                            </Badge>
                          </div>
                        )}
                      </div>

                      <CardHeader className="pb-3">
                        <CardTitle className="text-white text-lg line-clamp-2">
                          {highlight.title}
                        </CardTitle>
                        <CardDescription className="text-gray-400 text-sm line-clamp-2">
                          {highlight.description}
                        </CardDescription>
                      </CardHeader>

                      <CardContent className="pt-0">
                        {/* Author */}
                        <div className="flex items-center mb-3">
                          <Avatar className="w-8 h-8 mr-2">
                            <AvatarImage src={highlight.author.avatar || "/placeholder.svg"} />
                            <AvatarFallback>{highlight.author.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="flex items-center">
                              <p className="text-white text-sm font-medium">{highlight.author.name}</p>
                              {highlight.author.isVerified && (
                                <div className="w-3 h-3 bg-blue-500 rounded-full ml-1 flex items-center justify-center">
                                  <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
                                </div>
                              )}
                            </div>
                            <p className="text-gray-400 text-xs">
                              {formatTimestamp(highlight.createdAt)}
                            </p>
                          </div>
                        </div>

                        {/* Match Info */}
                        <div className="bg-gray-700 rounded-lg p-3 mb-3">
                          <div className="flex items-center justify-between mb-1">
                            <p className="text-white text-sm font-medium">{highlight.match.title}</p>
                            {highlight.match.score && (
                              <Badge variant="outline" className="text-green-400 border-green-400 text-xs">
                                {highlight.match.score}
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center text-gray-400 text-xs">
                            <Calendar className="w-3 h-3 mr-1" />
                            <span className="mr-3">{new Date(highlight.match.date).toLocaleDateString('es-AR')}</span>
                            <MapPin className="w-3 h-3 mr-1" />
                            <span>{highlight.match.location}</span>
                          </div>
                        </div>

                        {/* Tags */}
                        <div className="flex flex-wrap gap-1 mb-3">
                          {highlight.tags.slice(0, 3).map((tag, index) => (
                            <Badge key={index} variant="outline" className="text-xs text-gray-300 border-gray-600">
                              #{tag}
                            </Badge>
                          ))}
                        </div>

                        {/* Stats and Actions */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4 text-gray-400 text-sm">
                            <span className="flex items-center">
                              <Play className="w-4 h-4 mr-1" />
                              {formatNumber(highlight.stats.views)}
                            </span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleLike(highlight.id)}
                              className={`p-2 ${highlight.isLiked ? 'text-red-500' : 'text-gray-400'} hover:text-red-400`}
                            >
                              <Heart className={`w-4 h-4 ${highlight.isLiked ? 'fill-current' : ''}`} />
                              <span className="ml-1 text-xs">{formatNumber(highlight.stats.likes)}</span>
                            </Button>
                            <Button variant="ghost" size="sm" className="p-2 text-gray-400 hover:text-blue-400">
                              <MessageCircle className="w-4 h-4" />
                              <span className="ml-1 text-xs">{highlight.stats.comments}</span>
                            </Button>
                            <Button variant="ghost" size="sm" className="p-2 text-gray-400 hover:text-green-400">
                              <Share2 className="w-4 h-4" />
                              <span className="ml-1 text-xs">{highlight.stats.shares}</span>
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="populares">
              <div className="text-center py-12">
                <Trophy className="w-16 h-16 mx-auto mb-4 text-yellow-400" />
                <p className="text-xl text-white mb-2">Highlights Más Populares</p>
                <p className="text-gray-400">Los clips con más likes y visualizaciones de todos los tiempos</p>
              </div>
            </TabsContent>

            <TabsContent value="top-semana">
              <div className="mb-6">
                <div className="flex items-center mb-4">
                  <Trophy className="w-6 h-6 text-yellow-400 mr-2" />
                  <h2 className="text-xl font-bold text-white">Top de la Semana</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredHighlights.filter(h => h.isTopWeek).map((highlight, index) => (
                    <Card key={highlight.id} className="bg-gradient-to-br from-yellow-900/20 to-gray-800 border-yellow-500/30 relative overflow-hidden">
                      <div className="absolute top-2 left-2 z-10">
                        <Badge className="bg-yellow-500 text-black font-bold">
                          #{index + 1}
                        </Badge>
                      </div>
                      <div className="relative">
                        <img
                          src={highlight.thumbnail || "/placeholder.svg"}
                          alt={highlight.title}
                          className="w-full h-48 object-cover"
                        />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity cursor-pointer">
                          <Play className="w-12 h-12 text-white" />
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <h3 className="text-white font-bold mb-2">{highlight.title}</h3>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-yellow-400 font-semibold">
                            {formatNumber(highlight.stats.likes)} likes
                          </span>
                          <span className="text-gray-400">
                            {formatNumber(highlight.stats.views)} vistas
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="mis-clips">
              <div className="text-center py-12">
                <Upload className="w-16 h-16 mx-auto mb-4 text-green-400" />
                <p className="text-xl text-white mb-2">Tus Highlights</p>
                <p className="text-gray-400 mb-4">Aquí aparecerán los clips que hayas subido</p>
                <Button 
                  className="bg-green-500 hover:bg-green-600"
                  onClick={() => setShowUploadModal(true)}
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Subir tu primer clip
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Subir Highlight</CardTitle>
              <CardDescription className="text-gray-400">
                Comparte los mejores momentos de tus partidos
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Upload className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-400 mb-4">Funcionalidad en desarrollo</p>
                <p className="text-sm text-gray-500 mb-4">
                  Próximamente: subida de videos, edición básica, filtros
                </p>
                <Button 
                  onClick={() => setShowUploadModal(false)}
                  className="bg-green-500 hover:bg-green-600"
                >
                  Cerrar
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
