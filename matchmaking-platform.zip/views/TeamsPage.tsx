"use client"

import { useState, useEffect } from "react"
import { Plus, Search, Users, Crown, Star, Calendar, Trophy, Shield, Edit, Trash2, UserPlus, UserMinus } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Sidebar from "../components/Sidebar"
import CreateTeamModal from "../components/CreateTeamModal"
import { useAuth } from "../contexts/AuthContext"

interface Team {
  id: string
  name: string
  description: string
  logo: string
  colors: {
    primary: string
    secondary: string
  }
  leader: {
    id: string
    name: string
    avatar: string
  }
  members: TeamMember[]
  stats: {
    matchesPlayed: number
    matchesWon: number
    matchesLost: number
    matchesDrawn: number
    goalsFor: number
    goalsAgainst: number
  }
  achievements: string[]
  isVerified: boolean
  createdAt: string
  maxMembers: number
  isPublic: boolean
}

interface TeamMember {
  id: string
  name: string
  lastName: string
  avatar: string
  position: string
  joinedAt: string
  matchesPlayed: number
  goals: number
  assists: number
  isActive: boolean
}

interface JoinRequest {
  id: string
  teamId: string
  user: {
    id: string
    name: string
    lastName: string
    avatar: string
    position: string
    rating: number
    totalMatches: number
  }
  message: string
  requestedAt: string
  status: 'pending' | 'approved' | 'rejected'
}

export default function TeamsPage() {
  const { user } = useAuth()
  const [teams, setTeams] = useState<Team[]>([])
  const [myTeams, setMyTeams] = useState<Team[]>([])
  const [joinRequests, setJoinRequests] = useState<JoinRequest[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null)

  // Mock data
  const mockTeams: Team[] = [
    {
      id: "team-001",
      name: "Los Tigres FC",
      description: "Equipo competitivo de Palermo. Buscamos jugadores comprometidos para torneos.",
      logo: "/placeholder.svg?height=80&width=80&text=LT",
      colors: {
        primary: "#FF6B35",
        secondary: "#1A1A1A"
      },
      leader: {
        id: "user-001",
        name: "Carlos Mendoza",
        avatar: "/placeholder.svg?height=40&width=40&text=CM"
      },
      members: [
        {
          id: "user-001",
          name: "Carlos",
          lastName: "Mendoza",
          avatar: "/placeholder.svg?height=40&width=40&text=CM",
          position: "Mediocampista",
          joinedAt: "2024-01-01",
          matchesPlayed: 15,
          goals: 8,
          assists: 12,
          isActive: true
        },
        {
          id: "user-002",
          name: "Diego",
          lastName: "Silva",
          avatar: "/placeholder.svg?height=40&width=40&text=DS",
          position: "Delantero",
          joinedAt: "2024-01-05",
          matchesPlayed: 12,
          goals: 18,
          assists: 5,
          isActive: true
        }
      ],
      stats: {
        matchesPlayed: 15,
        matchesWon: 9,
        matchesLost: 4,
        matchesDrawn: 2,
        goalsFor: 45,
        goalsAgainst: 28
      },
      achievements: ["Campeón Copa Primavera 2024", "Mejor Ataque Liga Local"],
      isVerified: true,
      createdAt: "2024-01-01",
      maxMembers: 16,
      isPublic: true
    },
    {
      id: "team-002",
      name: "Águilas Doradas",
      description: "Equipo amateur que juega por diversión. Todos los niveles bienvenidos.",
      logo: "/placeholder.svg?height=80&width=80&text=AD",
      colors: {
        primary: "#FFD700",
        secondary: "#8B4513"
      },
      leader: {
        id: "user-003",
        name: "Ana García",
        avatar: "/placeholder.svg?height=40&width=40&text=AG"
      },
      members: [
        {
          id: "user-003",
          name: "Ana",
          lastName: "García",
          avatar: "/placeholder.svg?height=40&width=40&text=AG",
          position: "Arquera",
          joinedAt: "2024-01-10",
          matchesPlayed: 8,
          goals: 0,
          assists: 0,
          isActive: true
        }
      ],
      stats: {
        matchesPlayed: 8,
        matchesWon: 3,
        matchesLost: 3,
        matchesDrawn: 2,
        goalsFor: 18,
        goalsAgainst: 20
      },
      achievements: [],
      isVerified: false,
      createdAt: "2024-01-10",
      maxMembers: 12,
      isPublic: true
    }
  ]

  const mockJoinRequests: JoinRequest[] = [
    {
      id: "req-001",
      teamId: "team-001",
      user: {
        id: "user-004",
        name: "Miguel",
        lastName: "Torres",
        avatar: "/placeholder.svg?height=40&width=40&text=MT",
        position: "Defensor",
        rating: 4.2,
        totalMatches: 25
      },
      message: "Hola! Soy defensor central con experiencia. Me gustaría unirme al equipo.",
      requestedAt: "2024-01-25T10:30:00Z",
      status: "pending"
    }
  ]

  useEffect(() => {
    setTeams(mockTeams)
    // Filtrar equipos donde el usuario es miembro o líder
    const userTeams = mockTeams.filter(team => 
      team.leader.id === user?.id || 
      team.members.some(member => member.id === user?.id)
    )
    setMyTeams(userTeams)
    setJoinRequests(mockJoinRequests)
  }, [user])

  const handleCreateTeam = async (teamData: any) => {
    // Simular creación de equipo
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    const newTeam: Team = {
      id: 'team-' + Date.now(),
      ...teamData,
      leader: {
        id: user!.id,
        name: user!.name,
        avatar: user!.avatar || "/placeholder.svg"
      },
      members: [{
        id: user!.id,
        name: user!.name,
        lastName: user!.lastName,
        avatar: user!.avatar || "/placeholder.svg",
        position: user!.position,
        joinedAt: new Date().toISOString(),
        matchesPlayed: 0,
        goals: 0,
        assists: 0,
        isActive: true
      }],
      stats: {
        matchesPlayed: 0,
        matchesWon: 0,
        matchesLost: 0,
        matchesDrawn: 0,
        goalsFor: 0,
        goalsAgainst: 0
      },
      achievements: [],
      isVerified: false,
      createdAt: new Date().toISOString()
    }
    
    setTeams(prev => [newTeam, ...prev])
    setMyTeams(prev => [newTeam, ...prev])
    alert("¡Equipo creado exitosamente!")
  }

  const handleJoinRequest = (teamId: string) => {
    // Simular solicitud de unión
    alert(`Solicitud enviada al equipo ${teamId}`)
  }

  const handleApproveRequest = (requestId: string) => {
    setJoinRequests(prev =>
      prev.map(req =>
        req.id === requestId ? { ...req, status: 'approved' as const } : req
      )
    )
  }

  const handleRejectRequest = (requestId: string) => {
    setJoinRequests(prev =>
      prev.map(req =>
        req.id === requestId ? { ...req, status: 'rejected' as const } : req
      )
    )
  }

  const filteredTeams = teams.filter(team =>
    team.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    team.description.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const pendingRequests = joinRequests.filter(req => req.status === 'pending')

  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar currentPage="equipos" />
      
      <main className="flex-1 md:ml-0">
        <div className="container mx-auto px-4 py-8 md:px-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 mt-16 md:mt-0">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Equipos</h1>
              <p className="text-gray-400">Crea tu equipo o únete a uno existente</p>
            </div>
            <Button 
              className="bg-green-500 hover:bg-green-600 text-white mt-4 md:mt-0"
              onClick={() => setShowCreateModal(true)}
            >
              <Plus className="w-4 h-4 mr-2" />
              Crear Equipo
            </Button>
          </div>

          {/* Search bar */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Buscar equipos por nombre o descripción..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-green-500"
            />
          </div>

          {/* Tabs */}
          <Tabs defaultValue="todos" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800 mb-6">
              <TabsTrigger value="todos" className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-green-500">
                Todos los Equipos
              </TabsTrigger>
              <TabsTrigger value="mis-equipos" className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-green-500">
                Mis Equipos ({myTeams.length})
              </TabsTrigger>
              <TabsTrigger value="solicitudes" className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-green-500">
                Solicitudes ({pendingRequests.length})
              </TabsTrigger>
              <TabsTrigger value="crear" className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-green-500">
                Crear Equipo
              </TabsTrigger>
            </TabsList>

            {/* Todos los equipos */}
            <TabsContent value="todos">
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredTeams.map((team) => (
                  <Card key={team.id} className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-all duration-300 hover:border-green-500/50">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          <div 
                            className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold"
                            style={{ backgroundColor: team.colors.primary }}
                          >
                            <img 
                              src={team.logo || "/placeholder.svg"} 
                              alt={team.name}
                              className="w-full h-full rounded-full object-cover"
                            />
                          </div>
                          <div>
                            <div className="flex items-center">
                              <CardTitle className="text-white text-lg">{team.name}</CardTitle>
                              {team.isVerified && (
                                <Shield className="w-4 h-4 ml-2 text-blue-400" />
                              )}
                            </div>
                            <p className="text-gray-400 text-sm">{team.members.length}/{team.maxMembers} miembros</p>
                          </div>
                        </div>
                        <Badge 
                          className="text-white"
                          style={{ backgroundColor: team.colors.primary }}
                        >
                          {team.isPublic ? 'Público' : 'Privado'}
                        </Badge>
                      </div>
                      <CardDescription className="text-gray-400 mt-3">
                        {team.description}
                      </CardDescription>
                    </CardHeader>

                    <CardContent>
                      {/* Líder del equipo */}
                      <div className="flex items-center mb-4">
                        <Crown className="w-4 h-4 text-yellow-400 mr-2" />
                        <Avatar className="w-6 h-6 mr-2">
                          <AvatarImage src={team.leader.avatar || "/placeholder.svg"} />
                          <AvatarFallback>{team.leader.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <span className="text-white text-sm">{team.leader.name}</span>
                        <span className="text-gray-400 text-xs ml-2">Líder</span>
                      </div>

                      {/* Estadísticas */}
                      <div className="grid grid-cols-3 gap-2 mb-4">
                        <div className="bg-gray-700 p-2 rounded text-center">
                          <div className="text-lg font-bold text-green-400">{team.stats.matchesWon}</div>
                          <div className="text-xs text-gray-400">Ganados</div>
                        </div>
                        <div className="bg-gray-700 p-2 rounded text-center">
                          <div className="text-lg font-bold text-yellow-400">{team.stats.matchesDrawn}</div>
                          <div className="text-xs text-gray-400">Empates</div>
                        </div>
                        <div className="bg-gray-700 p-2 rounded text-center">
                          <div className="text-lg font-bold text-red-400">{team.stats.matchesLost}</div>
                          <div className="text-xs text-gray-400">Perdidos</div>
                        </div>
                      </div>

                      {/* Logros */}
                      {team.achievements.length > 0 && (
                        <div className="mb-4">
                          <div className="flex items-center mb-2">
                            <Trophy className="w-4 h-4 text-yellow-400 mr-2" />
                            <span className="text-white text-sm font-medium">Logros</span>
                          </div>
                          <div className="space-y-1">
                            {team.achievements.slice(0, 2).map((achievement, index) => (
                              <Badge key={index} variant="outline" className="text-xs text-yellow-400 border-yellow-400">
                                {achievement}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Miembros destacados */}
                      <div className="mb-4">
                        <p className="text-white text-sm font-medium mb-2">Miembros</p>
                        <div className="flex -space-x-2">
                          {team.members.slice(0, 5).map((member) => (
                            <Avatar key={member.id} className="w-8 h-8 border-2 border-gray-800">
                              <AvatarImage src={member.avatar || "/placeholder.svg"} />
                              <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                          ))}
                          {team.members.length > 5 && (
                            <div className="w-8 h-8 rounded-full bg-gray-700 border-2 border-gray-800 flex items-center justify-center">
                              <span className="text-xs text-gray-300">+{team.members.length - 5}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Botones de acción */}
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
                          onClick={() => setSelectedTeam(team)}
                        >
                          Ver Detalles
                        </Button>
                        {!team.members.some(member => member.id === user?.id) && (
                          <Button
                            size="sm"
                            className="flex-1 bg-green-500 hover:bg-green-600"
                            onClick={() => handleJoinRequest(team.id)}
                          >
                            <UserPlus className="w-4 h-4 mr-1" />
                            Solicitar Unión
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Mis equipos */}
            <TabsContent value="mis-equipos">
              {myTeams.length > 0 ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {myTeams.map((team) => (
                    <Card key={team.id} className="bg-gray-800 border-gray-700">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-3">
                            <div 
                              className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold"
                              style={{ backgroundColor: team.colors.primary }}
                            >
                              <img 
                                src={team.logo || "/placeholder.svg"} 
                                alt={team.name}
                                className="w-full h-full rounded-full object-cover"
                              />
                            </div>
                            <div>
                              <div className="flex items-center">
                                <CardTitle className="text-white text-lg">{team.name}</CardTitle>
                                {team.leader.id === user?.id && (
                                  <Crown className="w-4 h-4 ml-2 text-yellow-400" />
                                )}
                              </div>
                              <p className="text-gray-400 text-sm">
                                {team.leader.id === user?.id ? 'Líder' : 'Miembro'}
                              </p>
                            </div>
                          </div>
                          {team.leader.id === user?.id && (
                            <div className="flex gap-1">
                              <Button variant="ghost" size="sm">
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm" className="text-red-400">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </CardHeader>

                      <CardContent>
                        {/* Estadísticas del equipo */}
                        <div className="grid grid-cols-4 gap-2 mb-4">
                          <div className="bg-gray-700 p-2 rounded text-center">
                            <div className="text-sm font-bold text-white">{team.stats.matchesPlayed}</div>
                            <div className="text-xs text-gray-400">Jugados</div>
                          </div>
                          <div className="bg-gray-700 p-2 rounded text-center">
                            <div className="text-sm font-bold text-green-400">{team.stats.matchesWon}</div>
                            <div className="text-xs text-gray-400">Ganados</div>
                          </div>
                          <div className="bg-gray-700 p-2 rounded text-center">
                            <div className="text-sm font-bold text-yellow-400">{team.stats.goalsFor}</div>
                            <div className="text-xs text-gray-400">Goles F</div>
                          </div>
                          <div className="bg-gray-700 p-2 rounded text-center">
                            <div className="text-sm font-bold text-red-400">{team.stats.goalsAgainst}</div>
                            <div className="text-xs text-gray-400">Goles C</div>
                          </div>
                        </div>

                        {/* Próximo partido */}
                        <div className="bg-gray-700 p-3 rounded-lg mb-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-white text-sm font-medium">Próximo Partido</p>
                              <p className="text-gray-400 text-xs">Sábado 27/01 - 15:00</p>
                            </div>
                            <Calendar className="w-5 h-5 text-blue-400" />
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
                          >
                            Ver Calendario
                          </Button>
                          <Button
                            size="sm"
                            className="flex-1 bg-blue-500 hover:bg-blue-600"
                          >
                            Chat del Equipo
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Users className="w-16 h-16 mx-auto mb-4 text-gray-500" />
                  <p className="text-xl text-white mb-2">No tienes equipos</p>
                  <p className="text-gray-400 mb-4">Crea tu propio equipo o únete a uno existente</p>
                  <Button 
                    className="bg-green-500 hover:bg-green-600"
                    onClick={() => setShowCreateModal(true)}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Crear Mi Primer Equipo
                  </Button>
                </div>
              )}
            </TabsContent>

            {/* Solicitudes */}
            <TabsContent value="solicitudes">
              {pendingRequests.length > 0 ? (
                <div className="space-y-4">
                  {pendingRequests.map((request) => (
                    <Card key={request.id} className="bg-gray-800 border-gray-700">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start space-x-4">
                            <Avatar className="w-12 h-12">
                              <AvatarImage src={request.user.avatar || "/placeholder.svg"} />
                              <AvatarFallback>{request.user.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <h3 className="text-white font-medium">
                                {request.user.name} {request.user.lastName}
                              </h3>
                              <div className="flex items-center text-sm text-gray-400 mb-2">
                                <Star className="w-3 h-3 mr-1 text-yellow-400" />
                                <span>{request.user.rating}</span>
                                <span className="mx-2">•</span>
                                <span>{request.user.totalMatches} partidos</span>
                                <span className="mx-2">•</span>
                                <span className="capitalize">{request.user.position}</span>
                              </div>
                              <p className="text-gray-300 text-sm">{request.message}</p>
                              <p className="text-gray-500 text-xs mt-2">
                                Solicitado el {new Date(request.requestedAt).toLocaleDateString('es-AR')}
                              </p>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              className="bg-green-500 hover:bg-green-600"
                              onClick={() => handleApproveRequest(request.id)}
                            >
                              Aceptar
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-red-500 text-red-400 hover:bg-red-900/20"
                              onClick={() => handleRejectRequest(request.id)}
                            >
                              Rechazar
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <UserPlus className="w-16 h-16 mx-auto mb-4 text-gray-500" />
                  <p className="text-xl text-white mb-2">No hay solicitudes pendientes</p>
                  <p className="text-gray-400">Las solicitudes para unirse a tus equipos aparecerán aquí</p>
                </div>
              )}
            </TabsContent>

            {/* Crear equipo */}
            <TabsContent value="crear">
              <div className="text-center py-12">
                <Users className="w-16 h-16 mx-auto mb-4 text-green-400" />
                <p className="text-xl text-white mb-2">Crear Nuevo Equipo</p>
                <p className="text-gray-400 mb-6">Forma tu propio equipo y compite en torneos</p>
                <Button 
                  className="bg-green-500 hover:bg-green-600"
                  onClick={() => setShowCreateModal(true)}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Comenzar Creación
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Create Team Modal */}
      <CreateTeamModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSubmit={handleCreateTeam}
      />
    </div>
  )
}
