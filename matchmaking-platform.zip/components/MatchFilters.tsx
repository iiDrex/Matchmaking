"use client"

import { useState } from "react"
import { Filter, X } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MatchFilters as IMatchFilters, MatchType, SkillLevel, Gender, Position } from "../models/types"

interface MatchFiltersProps {
  onFiltersChange: (filters: IMatchFilters) => void
  activeFilters: IMatchFilters
}

export default function MatchFilters({ onFiltersChange, activeFilters }: MatchFiltersProps) {
  const [isOpen, setIsOpen] = useState(false)

  const matchTypes: { value: MatchType; label: string }[] = [
    { value: "futbol5", label: "Fútbol 5" },
    { value: "futbol8", label: "Fútbol 8" },
    { value: "futbol11", label: "Fútbol 11" }
  ]

  const skillLevels: { value: SkillLevel; label: string }[] = [
    { value: "casual", label: "Casual" },
    { value: "intermedio", label: "Intermedio" },
    { value: "competitivo", label: "Competitivo" }
  ]

  const genders: { value: Gender; label: string }[] = [
    { value: "masculino", label: "Masculino" },
    { value: "femenino", label: "Femenino" },
    { value: "mixto", label: "Mixto" }
  ]

  const positions: { value: Position; label: string }[] = [
    { value: "arquero", label: "Arquero" },
    { value: "defensor", label: "Defensor" },
    { value: "mediocampista", label: "Mediocampista" },
    { value: "delantero", label: "Delantero" },
    { value: "cualquiera", label: "Cualquiera" }
  ]

  const updateFilter = (key: keyof IMatchFilters, value: any) => {
    const newFilters = { ...activeFilters, [key]: value }
    onFiltersChange(newFilters)
  }

  const clearFilter = (key: keyof IMatchFilters) => {
    const newFilters = { ...activeFilters }
    delete newFilters[key]
    onFiltersChange(newFilters)
  }

  const clearAllFilters = () => {
    onFiltersChange({})
  }

  const activeFilterCount = Object.keys(activeFilters).length

  return (
    <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <Filter className="w-5 h-5 text-gray-400 mr-2" />
          <h3 className="text-white font-semibold">Filtros</h3>
          {activeFilterCount > 0 && (
            <Badge className="ml-2 bg-green-500 text-white">
              {activeFilterCount}
            </Badge>
          )}
        </div>
        <div className="flex gap-2">
          {activeFilterCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearAllFilters}
              className="text-gray-400 hover:text-white"
            >
              Limpiar todo
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsOpen(!isOpen)}
            className="text-gray-400 hover:text-white"
          >
            {isOpen ? 'Ocultar' : 'Mostrar'}
          </Button>
        </div>
      </div>

      {/* Filtros activos */}
      {activeFilterCount > 0 && (
        <div className="flex flex-wrap gap-2 mb-4">
          {activeFilters.type && (
            <Badge variant="secondary" className="bg-blue-600 text-white">
              {matchTypes.find(t => t.value === activeFilters.type)?.label}
              <X
                className="w-3 h-3 ml-1 cursor-pointer"
                onClick={() => clearFilter('type')}
              />
            </Badge>
          )}
          {activeFilters.skillLevel && (
            <Badge variant="secondary" className="bg-purple-600 text-white">
              {skillLevels.find(s => s.value === activeFilters.skillLevel)?.label}
              <X
                className="w-3 h-3 ml-1 cursor-pointer"
                onClick={() => clearFilter('skillLevel')}
              />
            </Badge>
          )}
          {activeFilters.gender && (
            <Badge variant="secondary" className="bg-pink-600 text-white">
              {genders.find(g => g.value === activeFilters.gender)?.label}
              <X
                className="w-3 h-3 ml-1 cursor-pointer"
                onClick={() => clearFilter('gender')}
              />
            </Badge>
          )}
          {activeFilters.position && (
            <Badge variant="secondary" className="bg-green-600 text-white">
              {positions.find(p => p.value === activeFilters.position)?.label}
              <X
                className="w-3 h-3 ml-1 cursor-pointer"
                onClick={() => clearFilter('position')}
              />
            </Badge>
          )}
        </div>
      )}

      {/* Panel de filtros */}
      {isOpen && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Tipo de partido */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Tipo de Partido</label>
            <div className="space-y-2">
              {matchTypes.map(type => (
                <label key={type.value} className="flex items-center">
                  <input
                    type="radio"
                    name="type"
                    value={type.value}
                    checked={activeFilters.type === type.value}
                    onChange={(e) => updateFilter('type', e.target.value as MatchType)}
                    className="mr-2 text-green-500"
                  />
                  <span className="text-gray-300 text-sm">{type.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Nivel de habilidad */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Nivel</label>
            <div className="space-y-2">
              {skillLevels.map(level => (
                <label key={level.value} className="flex items-center">
                  <input
                    type="radio"
                    name="skillLevel"
                    value={level.value}
                    checked={activeFilters.skillLevel === level.value}
                    onChange={(e) => updateFilter('skillLevel', e.target.value as SkillLevel)}
                    className="mr-2 text-green-500"
                  />
                  <span className="text-gray-300 text-sm">{level.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Género */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Género</label>
            <div className="space-y-2">
              {genders.map(gender => (
                <label key={gender.value} className="flex items-center">
                  <input
                    type="radio"
                    name="gender"
                    value={gender.value}
                    checked={activeFilters.gender === gender.value}
                    onChange={(e) => updateFilter('gender', e.target.value as Gender)}
                    className="mr-2 text-green-500"
                  />
                  <span className="text-gray-300 text-sm">{gender.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Posición */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Posición</label>
            <div className="space-y-2">
              {positions.map(position => (
                <label key={position.value} className="flex items-center">
                  <input
                    type="radio"
                    name="position"
                    value={position.value}
                    checked={activeFilters.position === position.value}
                    onChange={(e) => updateFilter('position', e.target.value as Position)}
                    className="mr-2 text-green-500"
                  />
                  <span className="text-gray-300 text-sm">{position.label}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
