"use client"

import { useState } from 'react'
import { X, Upload, Palette } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

interface CreateTeamModalProps {
  isOpen: boolean
  onClose: () => void
  onSubmit: (teamData: any) => Promise<void>
}

export default function CreateTeamModal({ isOpen, onClose, onSubmit }: CreateTeamModalProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    logo: '',
    colors: {
      primary: '#FF6B35',
      secondary: '#1A1A1A'
    },
    maxMembers: 16,
    isPublic: true
  })

  const colorPresets = [
    { name: 'Fuego', primary: '#FF6B35', secondary: '#1A1A1A' },
    { name: 'Océano', primary: '#0077BE', secondary: '#FFFFFF' },
    { name: 'Bosque', primary: '#228B22', secondary: '#FFFFFF' },
    { name: 'Real', primary: '#FFFFFF', secondary: '#000080' },
    { name: 'Barcelona', primary: '#A50044', secondary: '#004D98' },
    { name: 'Juventus', primary: '#000000', secondary: '#FFFFFF' },
    { name: 'Arsenal', primary: '#EF0107', secondary: '#FFFFFF' },
    { name: 'Chelsea', primary: '#034694', secondary: '#FFFFFF' }
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)

    try {
      // Validaciones
      if (!formData.name.trim()) throw new Error('El nombre del equipo es requerido')
      if (!formData.description.trim()) throw new Error('La descripción es requerida')
      if (formData.maxMembers < 8 || formData.maxMembers > 22) {
        throw new Error('El número de miembros debe estar entre 8 y 22')
      }

      await onSubmit(formData)
      onClose()
      
      // Reset form
      setFormData({
        name: '',
        description: '',
        logo: '',
        colors: {
          primary: '#FF6B35',
          secondary: '#1A1A1A'
        },
        maxMembers: 16,
        isPublic: true
      })
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Error al crear el equipo')
    } finally {
      setIsLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <Card className="w-full max-w-2xl bg-gray-900 border-gray-700 my-8">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl text-white">Crear Nuevo Equipo</CardTitle>
              <CardDescription className="text-gray-400">
                Forma tu equipo y compite en torneos
              </CardDescription>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-5 h-5 text-gray-400" />
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Información básica */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white">Información Básica</h3>
              
              <div className="space-y-2">
                <Label htmlFor="name" className="text-gray-300">Nombre del Equipo</Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="Ej: Los Tigres FC"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-gray-800 border-gray-700 text-white"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description" className="text-gray-300">Descripción</Label>
                <Textarea
                  id="description"
                  placeholder="Describe tu equipo, nivel de juego, objetivos..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="bg-gray-800 border-gray-700 text-white"
                  rows={3}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="maxMembers" className="text-gray-300">Máximo de Miembros</Label>
                <Input
                  id="maxMembers"
                  type="number"
                  min="8"
                  max="22"
                  value={formData.maxMembers}
                  onChange={(e) => setFormData({ ...formData, maxMembers: parseInt(e.target.value) })}
                  className="bg-gray-800 border-gray-700 text-white"
                />
                <p className="text-xs text-gray-500">Entre 8 y 22 miembros</p>
              </div>
            </div>

            {/* Logo del equipo */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white">Logo del Equipo</h3>
              
              <div className="border-2 border-dashed border-gray-600 rounded-lg p-6 text-center">
                <Upload className="w-12 h-12 mx-auto mb-3 text-gray-500" />
                <p className="text-gray-400 mb-2">Sube el logo de tu equipo</p>
                <p className="text-gray-500 text-sm">PNG, JPG hasta 2MB</p>
                <Button 
                  type="button" 
                  variant="outline" 
                  size="sm" 
                  className="mt-3 border-gray-600 text-gray-300"
                >
                  Seleccionar Archivo
                </Button>
              </div>
            </div>

            {/* Colores del equipo */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white">Colores del Equipo</h3>
              
              {/* Vista previa */}
              <div className="flex items-center space-x-4 mb-4">
                <div className="text-center">
                  <div 
                    className="w-16 h-16 rounded-full flex items-center justify-center text-white font-bold text-lg mb-2"
                    style={{ backgroundColor: formData.colors.primary }}
                  >
                    {formData.name.charAt(0) || 'E'}
                  </div>
                  <p className="text-xs text-gray-400">Vista previa</p>
                </div>
                <div className="flex-1">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-300 text-sm">Color Primario</Label>
                      <div className="flex items-center space-x-2 mt-1">
                        <input
                          type="color"
                          value={formData.colors.primary}
                          onChange={(e) => setFormData({
                            ...formData,
                            colors: { ...formData.colors, primary: e.target.value }
                          })}
                          className="w-8 h-8 rounded border border-gray-600"
                        />
                        <Input
                          value={formData.colors.primary}
                          onChange={(e) => setFormData({
                            ...formData,
                            colors: { ...formData.colors, primary: e.target.value }
                          })}
                          className="bg-gray-800 border-gray-700 text-white text-sm"
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-gray-300 text-sm">Color Secundario</Label>
                      <div className="flex items-center space-x-2 mt-1">
                        <input
                          type="color"
                          value={formData.colors.secondary}
                          onChange={(e) => setFormData({
                            ...formData,
                            colors: { ...formData.colors, secondary: e.target.value }
                          })}
                          className="w-8 h-8 rounded border border-gray-600"
                        />
                        <Input
                          value={formData.colors.secondary}
                          onChange={(e) => setFormData({
                            ...formData,
                            colors: { ...formData.colors, secondary: e.target.value }
                          })}
                          className="bg-gray-800 border-gray-700 text-white text-sm"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Presets de colores */}
              <div>
                <Label className="text-gray-300 text-sm mb-2 block">Combinaciones Populares</Label>
                <div className="grid grid-cols-4 gap-2">
                  {colorPresets.map((preset) => (
                    <button
                      key={preset.name}
                      type="button"
                      onClick={() => setFormData({
                        ...formData,
                        colors: { primary: preset.primary, secondary: preset.secondary }
                      })}
                      className="flex items-center space-x-2 p-2 rounded border border-gray-600 hover:border-gray-500 transition-colors"
                    >
                      <div className="flex">
                        <div 
                          className="w-4 h-4 rounded-l"
                          style={{ backgroundColor: preset.primary }}
                        ></div>
                        <div 
                          className="w-4 h-4 rounded-r"
                          style={{ backgroundColor: preset.secondary }}
                        ></div>
                      </div>
                      <span className="text-gray-300 text-xs">{preset.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Configuración */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white">Configuración</h3>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-gray-300">Equipo Público</Label>
                  <p className="text-gray-500 text-sm">Otros usuarios pueden encontrar y solicitar unirse</p>
                </div>
                <Switch
                  checked={formData.isPublic}
                  onCheckedChange={(checked) => setFormData({ ...formData, isPublic: checked })}
                />
              </div>
            </div>

            {error && (
              <div className="text-red-400 text-sm text-center bg-red-900/20 p-3 rounded">
                {error}
              </div>
            )}

            <div className="flex gap-4 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-green-500 hover:bg-green-600"
                disabled={isLoading}
              >
                {isLoading ? 'Creando...' : 'Crear Equipo'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
