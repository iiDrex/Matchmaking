"use client"

import { useState } from "react"
import { Home, Calendar, Trophy, User, HelpCircle, LogOut, Menu, X, Settings, Bell, Video, Shield, Users } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "../contexts/AuthContext"
import { useRouter } from "next/navigation"
// Importar el hook al inicio del archivo
import NotificationCenter, { useNotificationCount } from "./NotificationCenter"

interface SidebarProps {
  currentPage?: string
}

export default function Sidebar({ currentPage = "partidos" }: SidebarProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)
  const { user, logout, isAuthenticated } = useAuth()
  const router = useRouter()

  // En el componente Sidebar, reemplazar la línea del mock con:
  const notificationsCount = useNotificationCount()

  const getMenuItems = () => {
    const baseItems = [
      { id: "inicio", label: "Inicio", icon: Home, href: "/" },
      { id: "partidos", label: "Partidos", icon: Calendar, href: "/partidos" },
      { id: "torneos", label: "Torneos", icon: Trophy, href: "/torneos" },
      { id: "equipos", label: "Equipos", icon: Users, href: "/equipos" },
      { id: "highlights", label: "Highlights", icon: Video, href: "/highlights" },
      { id: "perfil", label: "Mi Perfil", icon: User, href: "/perfil" },
    ]

    // Agregar elementos específicos para admin
    if (user?.role === 'admin') {
      baseItems.splice(5, 0, {
        id: "admin",
        label: "Panel Admin",
        icon: Shield,
        href: "/admin"
      })
    }

    baseItems.push({ id: "ayuda", label: "Ayuda", icon: HelpCircle, href: "/ayuda" })

    return baseItems
  }

  const handleLogout = async () => {
    try {
      await logout()
      setIsOpen(false)
      router.push('/')
    } catch (error) {
      console.error('Error al cerrar sesión:', error)
    }
  }

  const handleProfileClick = () => {
    setIsOpen(false)
    router.push('/perfil')
  }

  const handleNotificationsClick = () => {
    setShowNotifications(true)
    setIsOpen(false)
  }

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'admin': return 'Administrador'
      case 'organizer': return 'Organizador'
      case 'player': return 'Jugador'
      default: return 'Usuario'
    }
  }

  if (!isAuthenticated || !user) {
    return null
  }

  const menuItems = getMenuItems()

  return (
    <>
      {/* Mobile menu button */}
      <Button
        variant="ghost"
        size="sm"
        className="fixed top-4 left-4 z-50 md:hidden bg-gray-800 text-white"
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </Button>

      {/* Overlay for mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed top-0 left-0 h-full w-64 bg-gray-900 border-r border-gray-800 z-50 transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        md:translate-x-0 md:static md:z-auto
      `}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-6 border-b border-gray-800">
            <h2 className="text-2xl font-bold text-white">MATCHMAKING</h2>
            <p className="text-gray-400 text-sm mt-1">Jugá donde quieras</p>
          </div>

          {/* User Profile Section */}
          <div className="p-4 border-b border-gray-800">
            <div 
              className="flex items-center p-3 rounded-lg bg-gray-800 hover:bg-gray-700 cursor-pointer transition-colors"
              onClick={handleProfileClick}
            >
              <div className="relative">
                <img
                  src={user.avatar || "/placeholder.svg?height=40&width=40"}
                  alt={user.name}
                  className="w-10 h-10 rounded-full mr-3"
                />
                {user.isVerified && (
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-gray-900 flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-white font-medium text-sm truncate">
                    {user.name} {user.lastName}
                  </p>
                  {user.role === 'admin' && (
                    <Badge className="bg-red-500 text-white text-xs px-1 py-0">
                      <Shield className="w-3 h-3" />
                    </Badge>
                  )}
                </div>
                <p className="text-gray-400 text-xs">
                  {getRoleLabel(user.role)}
                </p>
                <div className="flex items-center mt-1">
                  <div className="flex items-center text-yellow-400">
                    <span className="text-xs">⭐ {user.rating.toFixed(1)}</span>
                  </div>
                  <span className="text-gray-500 text-xs ml-2">
                    {user.totalMatches} partidos
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Notifications */}
          {notificationsCount > 0 && (
            <div className="px-4 py-2">
              <div 
                className="flex items-center justify-between p-2 bg-blue-900/30 rounded-lg border border-blue-700/50 cursor-pointer hover:bg-blue-900/40 transition-colors"
                onClick={handleNotificationsClick}
              >
                <div className="flex items-center">
                  <Bell className="w-4 h-4 text-blue-400 mr-2" />
                  <span className="text-blue-300 text-sm">Notificaciones</span>
                </div>
                <Badge className="bg-red-500 text-white text-xs animate-pulse">
                  {notificationsCount}
                </Badge>
              </div>
            </div>
          )}

          {/* Navigation */}
          <nav className="flex-1 p-4">
            <ul className="space-y-2">
              {menuItems.map((item) => {
                const Icon = item.icon
                const isActive = currentPage === item.id
                
                return (
                  <li key={item.id}>
                    <a
                      href={item.href}
                      className={`
                        flex items-center px-4 py-3 rounded-lg transition-colors duration-200
                        ${isActive 
                          ? 'bg-green-500 text-white' 
                          : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                        }
                      `}
                      onClick={() => setIsOpen(false)}
                    >
                      <Icon className="w-5 h-5 mr-3" />
                      {item.label}
                      {item.id === 'admin' && (
                        <Badge className="ml-auto bg-red-500 text-white text-xs">
                          Admin
                        </Badge>
                      )}
                    </a>
                  </li>
                )
              })}
            </ul>
          </nav>

          {/* Quick Actions */}
          <div className="p-4 border-t border-gray-800">
            <div className="space-y-2">
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-gray-300 hover:text-white hover:bg-gray-800"
                onClick={() => {
                  setIsOpen(false)
                  router.push('/configuracion')
                }}
              >
                <Settings className="w-4 h-4 mr-2" />
                Configuración
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                className="w-full justify-start text-red-400 hover:text-red-300 hover:bg-red-900/20"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Cerrar sesión
              </Button>
            </div>
          </div>
        </div>
      </aside>

      {/* Notification Center */}
      <NotificationCenter
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
      />
    </>
  )
}
