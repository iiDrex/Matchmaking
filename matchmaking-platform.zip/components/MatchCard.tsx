"use client"

import { Calendar, Clock, MapPin, Users, Star, DollarSign } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Match } from "../models/types"
import { MatchController } from "../controllers/matchController"
import MatchDetailModal from './MatchDetailModal'
import { useState } from 'react'

interface MatchCardProps {
  match: Match
  onJoin?: (matchId: string) => void
}

export default function MatchCard({ match, onJoin }: MatchCardProps) {
  const [showDetailModal, setShowDetailModal] = useState(false)

  const handleJoinMatch = () => {
    if (onJoin) {
      onJoin(match.id)
    } else {
      // Lógica por defecto
      const success = MatchController.joinMatch(match.id, "current-user-id")
      if (success) {
        alert("¡Te uniste al partido exitosamente!")
      } else {
        alert("No se pudo unir al partido. Puede estar lleno.")
      }
    }
  }

  const handleShowDetails = () => {
    setShowDetailModal(true)
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "futbol5": return "bg-blue-600"
      case "futbol8": return "bg-purple-600"
      case "futbol11": return "bg-green-600"
      default: return "bg-gray-600"
    }
  }

  const getSkillLevelColor = (level: string) => {
    switch (level) {
      case "casual": return "bg-green-500"
      case "intermedio": return "bg-yellow-500"
      case "competitivo": return "bg-red-500"
      default: return "bg-gray-500"
    }
  }

  const spotsLeft = match.maxPlayers - match.currentPlayers.length
  const isAlmostFull = spotsLeft <= 2
  const isFull = spotsLeft === 0

  return (
    <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 hover:bg-gray-750 transition-all duration-300 hover:border-green-500/50">
      {/* Header */}
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-xl font-bold text-white mb-2">{match.title}</h3>
          <div className="flex gap-2 mb-3">
            <Badge className={`${getTypeColor(match.type)} text-white`}>
              {match.type.toUpperCase()}
            </Badge>
            <Badge className={`${getSkillLevelColor(match.skillLevel)} text-white`}>
              {match.skillLevel}
            </Badge>
            <Badge variant="outline" className="text-gray-300 border-gray-600">
              {match.gender}
            </Badge>
          </div>
        </div>
        <div className="text-right">
          <div className="flex items-center text-yellow-400 mb-1">
            <Star className="w-4 h-4 mr-1 fill-current" />
            <span className="text-sm">{match.organizer.rating}</span>
          </div>
          <p className="text-xs text-gray-400">{match.organizer.matchesPlayed} partidos</p>
        </div>
      </div>

      {/* Organizador */}
      <div className="flex items-center mb-4">
        <img
          src={match.organizer.avatar || "/placeholder.svg"}
          alt={match.organizer.name}
          className="w-10 h-10 rounded-full mr-3"
        />
        <div>
          <p className="text-white font-medium">{match.organizer.name}</p>
          <p className="text-gray-400 text-sm">Organizador</p>
        </div>
      </div>

      {/* Detalles del partido */}
      <div className="space-y-2 mb-4">
        <div className="flex items-center text-gray-300">
          <Calendar className="w-4 h-4 mr-2" />
          <span className="text-sm">{new Date(match.date).toLocaleDateString('es-AR')}</span>
        </div>
        <div className="flex items-center text-gray-300">
          <Clock className="w-4 h-4 mr-2" />
          <span className="text-sm">{match.time} - {match.endTime}</span>
        </div>
        <div className="flex items-center text-gray-300">
          <MapPin className="w-4 h-4 mr-2" />
          <span className="text-sm">{match.location.address}</span>
        </div>
        {match.price && (
          <div className="flex items-center text-gray-300">
            <DollarSign className="w-4 h-4 mr-2" />
            <span className="text-sm">${match.price}</span>
          </div>
        )}
      </div>

      {/* Descripción */}
      {match.description && (
        <p className="text-gray-400 text-sm mb-4 line-clamp-2">{match.description}</p>
      )}

      {/* Posiciones necesarias */}
      {match.needsPosition && match.needsPosition.length > 0 && (
        <div className="mb-4">
          <p className="text-gray-400 text-xs mb-2">Posiciones necesarias:</p>
          <div className="flex gap-1 flex-wrap">
            {match.needsPosition.map((position, index) => (
              <Badge key={index} variant="outline" className="text-xs text-gray-300 border-gray-600">
                {position}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="flex justify-between items-center pt-4 border-t border-gray-700">
        <div className="flex items-center">
          <Users className="w-4 h-4 mr-2 text-gray-400" />
          <span className={`text-sm font-medium ${isAlmostFull ? 'text-yellow-400' : 'text-gray-300'}`}>
            {match.currentPlayers.length}/{match.maxPlayers}
          </span>
          <span className="text-gray-400 text-sm ml-2">
            ({spotsLeft} {spotsLeft === 1 ? 'lugar' : 'lugares'})
          </span>
        </div>
        
        <div className="flex gap-2">
          <Button
            onClick={handleShowDetails}
            variant="outline"
            className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            Ver Detalles
          </Button>
          <Button
            onClick={handleJoinMatch}
            disabled={isFull}
            className={`flex-1 ${
              isFull 
                ? 'bg-gray-600 cursor-not-allowed' 
                : 'bg-green-500 hover:bg-green-600'
            } text-white`}
          >
            {isFull ? 'Completo' : 'Unirse'}
          </Button>
        </div>
      </div>

      {/* Modal */}
      <MatchDetailModal
        match={match}
        isOpen={showDetailModal}
        onClose={() => setShowDetailModal(false)}
        onJoin={onJoin}
        onChat={(userId) => {
          // Implementar chat
          console.log('Chat with user:', userId)
        }}
      />
    </div>
  )
}
