"use client"

import { useState } from 'react'
import { X, Calendar, Clock, MapPin, Users, DollarSign, FileText } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CreateMatchForm, MatchType, SkillLevel, Gender, Position } from '../models/types'
import { mockFields } from '../services/mockData'

interface CreateMatchModalProps {
  isOpen: boolean
  onClose: () => void
  onSubmit: (matchData: CreateMatchForm) => Promise<void>
}

export default function CreateMatchModal({ isOpen, onClose, onSubmit }: CreateMatchModalProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [selectedPositions, setSelectedPositions] = useState<Position[]>([])
  const [rules, setRules] = useState<string[]>([''])

  const [formData, setFormData] = useState<CreateMatchForm>({
    title: '',
    description: '',
    type: 'futbol5',
    date: '',
    startTime: '',
    endTime: '',
    location: {
      address: '',
      city: 'Buenos Aires',
      state: 'CABA',
      country: 'Argentina',
      coordinates: { lat: 0, lng: 0 }
    },
    maxPlayers: 10,
    skillLevel: 'intermedio',
    gender: 'masculino',
    ageRange: { min: 18, max: 40 },
    price: 0,
    needsPositions: [],
    rules: [],
    isPrivate: false
  })

  const matchTypes: { value: MatchType; label: string; players: number }[] = [
    { value: "futbol5", label: "Fútbol 5", players: 10 },
    { value: "futbol8", label: "Fútbol 8", players: 16 },
    { value: "futbol11", label: "Fútbol 11", players: 22 }
  ]

  const skillLevels: { value: SkillLevel; label: string }[] = [
    { value: "casual", label: "Casual" },
    { value: "intermedio", label: "Intermedio" },
    { value: "competitivo", label: "Competitivo" }
  ]

  const genders: { value: Gender; label: string }[] = [
    { value: "masculino", label: "Masculino" },
    { value: "femenino", label: "Femenino" },
    { value: "mixto", label: "Mixto" }
  ]

  const positions: { value: Position; label: string }[] = [
    { value: "arquero", label: "Arquero" },
    { value: "defensor", label: "Defensor" },
    { value: "mediocampista", label: "Mediocampista" },
    { value: "delantero", label: "Delantero" },
    { value: "cualquiera", label: "Cualquiera" }
  ]

  const handleTypeChange = (type: MatchType) => {
    const matchType = matchTypes.find(t => t.value === type)
    setFormData({
      ...formData,
      type,
      maxPlayers: matchType?.players || 10
    })
  }

  const handlePositionToggle = (position: Position) => {
    const newPositions = selectedPositions.includes(position)
      ? selectedPositions.filter(p => p !== position)
      : [...selectedPositions, position]
    
    setSelectedPositions(newPositions)
    setFormData({ ...formData, needsPositions: newPositions })
  }

  const handleRuleChange = (index: number, value: string) => {
    const newRules = [...rules]
    newRules[index] = value
    setRules(newRules)
    setFormData({ ...formData, rules: newRules.filter(rule => rule.trim() !== '') })
  }

  const addRule = () => {
    setRules([...rules, ''])
  }

  const removeRule = (index: number) => {
    const newRules = rules.filter((_, i) => i !== index)
    setRules(newRules)
    setFormData({ ...formData, rules: newRules.filter(rule => rule.trim() !== '') })
  }

  const handleFieldSelect = (fieldId: string) => {
    const field = mockFields.find(f => f.id === fieldId)
    if (field) {
      setFormData({
        ...formData,
        location: field.location
      })
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)

    try {
      // Validaciones
      if (!formData.title.trim()) throw new Error('El título es requerido')
      if (!formData.date) throw new Error('La fecha es requerida')
      if (!formData.startTime) throw new Error('La hora de inicio es requerida')
      if (!formData.endTime) throw new Error('La hora de fin es requerida')
      if (!formData.location.address.trim()) throw new Error('La ubicación es requerida')

      await onSubmit(formData)
      onClose()
      
      // Reset form
      setFormData({
        title: '',
        description: '',
        type: 'futbol5',
        date: '',
        startTime: '',
        endTime: '',
        location: {
          address: '',
          city: 'Buenos Aires',
          state: 'CABA',
          country: 'Argentina',
          coordinates: { lat: 0, lng: 0 }
        },
        maxPlayers: 10,
        skillLevel: 'intermedio',
        gender: 'masculino',
        ageRange: { min: 18, max: 40 },
        price: 0,
        needsPositions: [],
        rules: [],
        isPrivate: false
      })
      setSelectedPositions([])
      setRules([''])
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Error al crear el partido')
    } finally {
      setIsLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <Card className="w-full max-w-2xl bg-gray-900 border-gray-700 my-8">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl text-white">Crear Nuevo Partido</CardTitle>
              <CardDescription className="text-gray-400">
                Organiza un partido y encuentra jugadores
              </CardDescription>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-5 h-5 text-gray-400" />
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Información básica */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white">Información Básica</h3>
              
              <div className="space-y-2">
                <Label htmlFor="title" className="text-gray-300">Título del Partido</Label>
                <Input
                  id="title"
                  type="text"
                  placeholder="Ej: Fútbol 5 - Palermo"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="bg-gray-800 border-gray-700 text-white"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description" className="text-gray-300">Descripción</Label>
                <Textarea
                  id="description"
                  placeholder="Describe el partido, nivel requerido, etc."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="bg-gray-800 border-gray-700 text-white"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="type" className="text-gray-300">Tipo de Partido</Label>
                  <Select value={formData.type} onValueChange={handleTypeChange}>
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700">
                      {matchTypes.map(type => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label} ({type.players} jugadores)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="maxPlayers" className="text-gray-300">Máximo Jugadores</Label>
                  <Input
                    id="maxPlayers"
                    type="number"
                    value={formData.maxPlayers}
                    onChange={(e) => setFormData({ ...formData, maxPlayers: parseInt(e.target.value) })}
                    className="bg-gray-800 border-gray-700 text-white"
                    min="4"
                    max="22"
                  />
                </div>
              </div>
            </div>

            {/* Fecha y hora */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white">Fecha y Hora</h3>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="date" className="text-gray-300">Fecha</Label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="date"
                      type="date"
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      className="pl-10 bg-gray-800 border-gray-700 text-white"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="startTime" className="text-gray-300">Hora Inicio</Label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="startTime"
                      type="time"
                      value={formData.startTime}
                      onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                      className="pl-10 bg-gray-800 border-gray-700 text-white"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="endTime" className="text-gray-300">Hora Fin</Label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="endTime"
                      type="time"
                      value={formData.endTime}
                      onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                      className="pl-10 bg-gray-800 border-gray-700 text-white"
                      required
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Ubicación */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white">Ubicación</h3>
              
              <div className="space-y-2">
                <Label htmlFor="field" className="text-gray-300">Cancha (Opcional)</Label>
                <Select onValueChange={handleFieldSelect}>
                  <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                    <SelectValue placeholder="Seleccionar cancha registrada" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700">
                    {mockFields.map(field => (
                      <SelectItem key={field.id} value={field.id}>
                        {field.name} - ${field.pricePerHour}/hora
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address" className="text-gray-300">Dirección</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    id="address"
                    type="text"
                    placeholder="Ej: Av. Santa Fe 3500, Buenos Aires"
                    value={formData.location.address}
                    onChange={(e) => setFormData({
                      ...formData,
                      location: { ...formData.location, address: e.target.value }
                    })}
                    className="pl-10 bg-gray-800 border-gray-700 text-white"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Configuración del partido */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white">Configuración</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="skillLevel" className="text-gray-300">Nivel</Label>
                  <Select
                    value={formData.skillLevel}
                    onValueChange={(value: SkillLevel) => setFormData({ ...formData, skillLevel: value })}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700">
                      {skillLevels.map(level => (
                        <SelectItem key={level.value} value={level.value}>
                          {level.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="gender" className="text-gray-300">Género</Label>
                  <Select
                    value={formData.gender}
                    onValueChange={(value: Gender) => setFormData({ ...formData, gender: value })}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700">
                      {genders.map(gender => (
                        <SelectItem key={gender.value} value={gender.value}>
                          {gender.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="minAge" className="text-gray-300">Edad Mínima</Label>
                  <Input
                    id="minAge"
                    type="number"
                    value={formData.ageRange.min}
                    onChange={(e) => setFormData({
                      ...formData,
                      ageRange: { ...formData.ageRange, min: parseInt(e.target.value) }
                    })}
                    className="bg-gray-800 border-gray-700 text-white"
                    min="16"
                    max="60"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="maxAge" className="text-gray-300">Edad Máxima</Label>
                  <Input
                    id="maxAge"
                    type="number"
                    value={formData.ageRange.max}
                    onChange={(e) => setFormData({
                      ...formData,
                      ageRange: { ...formData.ageRange, max: parseInt(e.target.value) }
                    })}
                    className="bg-gray-800 border-gray-700 text-white"
                    min="16"
                    max="60"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="price" className="text-gray-300">Precio por Jugador</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="price"
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: parseInt(e.target.value) })}
                      className="pl-10 bg-gray-800 border-gray-700 text-white"
                      min="0"
                      placeholder="0"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Posiciones necesarias */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white">Posiciones Necesarias</h3>
              <div className="flex flex-wrap gap-2">
                {positions.map(position => (
                  <Badge
                    key={position.value}
                    variant={selectedPositions.includes(position.value) ? "default" : "outline"}
                    className={`cursor-pointer transition-colors ${
                      selectedPositions.includes(position.value)
                        ? 'bg-green-500 text-white'
                        : 'border-gray-600 text-gray-300 hover:bg-gray-800'
                    }`}
                    onClick={() => handlePositionToggle(position.value)}
                  >
                    {position.label}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Reglas */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-white">Reglas del Partido</h3>
                <Button type="button" variant="outline" size="sm" onClick={addRule}>
                  Agregar Regla
                </Button>
              </div>
              
              {rules.map((rule, index) => (
                <div key={index} className="flex gap-2">
                  <div className="relative flex-1">
                    <FileText className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      type="text"
                      placeholder="Ej: Traer botines de fútbol 5"
                      value={rule}
                      onChange={(e) => handleRuleChange(index, e.target.value)}
                      className="pl-10 bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                  {rules.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeRule(index)}
                      className="text-red-400 hover:text-red-300"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            {error && (
              <div className="text-red-400 text-sm text-center bg-red-900/20 p-3 rounded">
                {error}
              </div>
            )}

            <div className="flex gap-4 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-green-500 hover:bg-green-600"
                disabled={isLoading}
              >
                {isLoading ? 'Creando...' : 'Crear Partido'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
