"use client"

import { useState } from "react"
import { X, Calendar, Clock, MapPin, Users, DollarSign, Star, MessageCircle, Phone, Mail, Trophy, Target } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Match, User } from "../models/types"

interface MatchDetailModalProps {
  match: Match | null
  isOpen: boolean
  onClose: () => void
  onJoin?: (matchId: string) => void
  onChat?: (userId: string) => void
}

export default function MatchDetailModal({ match, isOpen, onClose, onJoin, onChat }: MatchDetailModalProps) {
  const [activeTab, setActiveTab] = useState("details")

  if (!isOpen || !match) return null

  const spotsLeft = match.maxPlayers - match.currentPlayers.length
  const isAlmostFull = spotsLeft <= 2
  const isFull = spotsLeft === 0

  const getTypeColor = (type: string) => {
    switch (type) {
      case "futbol5": return "bg-blue-600"
      case "futbol8": return "bg-purple-600"
      case "futbol11": return "bg-green-600"
      default: return "bg-gray-600"
    }
  }

  const getSkillLevelColor = (level: string) => {
    switch (level) {
      case "casual": return "bg-green-500"
      case "intermedio": return "bg-yellow-500"
      case "competitivo": return "bg-red-500"
      default: return "bg-gray-500"
    }
  }

  const handleJoinMatch = () => {
    if (onJoin) {
      onJoin(match.id)
      onClose()
    }
  }

  const handleChatWithOrganizer = () => {
    if (onChat) {
      onChat(match.organizer.id)
    }
  }

  const handleChatWithPlayer = (playerId: string) => {
    if (onChat) {
      onChat(playerId)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <Card className="w-full max-w-4xl bg-gray-900 border-gray-700 my-8 max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <div className="flex gap-2 mb-3">
                <Badge className={`${getTypeColor(match.type)} text-white`}>
                  {match.type.toUpperCase()}
                </Badge>
                <Badge className={`${getSkillLevelColor(match.skillLevel)} text-white`}>
                  {match.skillLevel}
                </Badge>
                <Badge variant="outline" className="text-gray-300 border-gray-600">
                  {match.gender}
                </Badge>
                {isAlmostFull && !isFull && (
                  <Badge className="bg-yellow-500 text-black animate-pulse">
                    ¡Últimos lugares!
                  </Badge>
                )}
                {isFull && (
                  <Badge className="bg-red-500 text-white">
                    Completo
                  </Badge>
                )}
              </div>
              <CardTitle className="text-2xl text-white mb-2">{match.title}</CardTitle>
              <CardDescription className="text-gray-400">
                {match.description}
              </CardDescription>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-5 h-5 text-gray-400" />
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800 mb-6">
              <TabsTrigger 
                value="details" 
                className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-green-500"
              >
                Detalles
              </TabsTrigger>
              <TabsTrigger 
                value="players" 
                className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-green-500"
              >
                Jugadores ({match.currentPlayers.length})
              </TabsTrigger>
              <TabsTrigger 
                value="location" 
                className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-green-500"
              >
                Ubicación
              </TabsTrigger>
              <TabsTrigger 
                value="organizer" 
                className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-green-500"
              >
                Organizador
              </TabsTrigger>
            </TabsList>

            {/* Detalles del partido */}
            <TabsContent value="details">
              <div className="space-y-6">
                {/* Información básica */}
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white text-lg">Información del Partido</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center text-gray-300">
                        <Calendar className="w-5 h-5 mr-3 text-blue-400" />
                        <div>
                          <p className="text-white font-medium">Fecha</p>
                          <p className="text-sm">{new Date(match.date).toLocaleDateString('es-AR', { 
                            weekday: 'long', 
                            year: 'numeric', 
                            month: 'long', 
                            day: 'numeric' 
                          })}</p>
                        </div>
                      </div>
                      <div className="flex items-center text-gray-300">
                        <Clock className="w-5 h-5 mr-3 text-green-400" />
                        <div>
                          <p className="text-white font-medium">Horario</p>
                          <p className="text-sm">{match.time} - {match.endTime}</p>
                        </div>
                      </div>
                      <div className="flex items-center text-gray-300">
                        <Users className="w-5 h-5 mr-3 text-purple-400" />
                        <div>
                          <p className="text-white font-medium">Jugadores</p>
                          <p className="text-sm">{match.currentPlayers.length}/{match.maxPlayers} confirmados</p>
                        </div>
                      </div>
                      {match.price && (
                        <div className="flex items-center text-gray-300">
                          <DollarSign className="w-5 h-5 mr-3 text-yellow-400" />
                          <div>
                            <p className="text-white font-medium">Precio</p>
                            <p className="text-sm">${match.price} por jugador</p>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Rango de edad */}
                    <div className="bg-gray-700 p-4 rounded-lg">
                      <h4 className="text-white font-medium mb-2">Requisitos</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-400">Edad:</span>
                          <span className="text-white ml-2">{match.ageRange.min} - {match.ageRange.max} años</span>
                        </div>
                        <div>
                          <span className="text-gray-400">Nivel:</span>
                          <span className="text-white ml-2 capitalize">{match.skillLevel}</span>
                        </div>
                      </div>
                    </div>

                    {/* Posiciones necesarias */}
                    {match.needsPositions && match.needsPositions.length > 0 && (
                      <div>
                        <h4 className="text-white font-medium mb-2">Posiciones Necesarias</h4>
                        <div className="flex flex-wrap gap-2">
                          {match.needsPositions.map((position, index) => (
                            <Badge key={index} variant="outline" className="text-gray-300 border-gray-600">
                              <Target className="w-3 h-3 mr-1" />
                              {position}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Reglas */}
                    {match.rules && match.rules.length > 0 && (
                      <div>
                        <h4 className="text-white font-medium mb-2">Reglas del Partido</h4>
                        <ul className="space-y-1">
                          {match.rules.map((rule, index) => (
                            <li key={index} className="text-gray-300 text-sm flex items-start">
                              <span className="text-green-400 mr-2">•</span>
                              {rule}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Progreso de inscripción */}
                <Card className="bg-gray-800 border-gray-700">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-400">Progreso de inscripción</span>
                      <span className="text-white font-medium">{match.currentPlayers.length}/{match.maxPlayers}</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-3">
                      <div 
                        className={`h-3 rounded-full transition-all duration-300 ${
                          isFull ? 'bg-red-500' : isAlmostFull ? 'bg-yellow-500' : 'bg-green-500'
                        }`}
                        style={{ width: `${(match.currentPlayers.length / match.maxPlayers) * 100}%` }}
                      ></div>
                    </div>
                    <p className="text-gray-400 text-sm mt-2">
                      {spotsLeft > 0 ? `${spotsLeft} ${spotsLeft === 1 ? 'lugar disponible' : 'lugares disponibles'}` : 'Partido completo'}
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Lista de jugadores */}
            <TabsContent value="players">
              <div className="space-y-4">
                {match.currentPlayers.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {match.currentPlayers.map((player) => (
                      <Card key={player.id} className="bg-gray-800 border-gray-700">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <Avatar className="w-12 h-12">
                                <AvatarImage src={player.avatar || "/placeholder.svg"} />
                                <AvatarFallback>{player.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="text-white font-medium">{player.name} {player.lastName}</p>
                                <div className="flex items-center text-sm text-gray-400">
                                  <Star className="w-3 h-3 mr-1 text-yellow-400" />
                                  <span>{player.rating?.toFixed(1) || 'N/A'}</span>
                                  <span className="mx-2">•</span>
                                  <span>{player.totalMatches || 0} partidos</span>
                                </div>
                                <p className="text-xs text-gray-500 capitalize">
                                  {player.position || 'Cualquier posición'}
                                </p>
                              </div>
                            </div>
                            <div className="flex flex-col gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {/* Ver perfil */}}
                                className="text-xs border-gray-600 text-gray-300 hover:bg-gray-700"
                              >
                                Ver Perfil
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleChatWithPlayer(player.id)}
                                className="text-xs text-blue-400 hover:text-blue-300"
                              >
                                <MessageCircle className="w-3 h-3 mr-1" />
                                Chat
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Users className="w-16 h-16 mx-auto mb-4 text-gray-500" />
                    <p className="text-gray-400">Aún no hay jugadores inscritos</p>
                    <p className="text-gray-500 text-sm">¡Sé el primero en unirte!</p>
                  </div>
                )}

                {/* Lista de espera */}
                {match.waitingList && match.waitingList.length > 0 && (
                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white text-lg">Lista de Espera</CardTitle>
                      <CardDescription className="text-gray-400">
                        Jugadores en espera de un lugar disponible
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {match.waitingList.map((player, index) => (
                          <div key={player.id} className="flex items-center justify-between p-2 bg-gray-700 rounded">
                            <div className="flex items-center space-x-3">
                              <span className="text-gray-400 text-sm">#{index + 1}</span>
                              <Avatar className="w-8 h-8">
                                <AvatarImage src={player.avatar || "/placeholder.svg"} />
                                <AvatarFallback>{player.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <span className="text-white">{player.name} {player.lastName}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>

            {/* Ubicación */}
            <TabsContent value="location">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Ubicación del Partido</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <MapPin className="w-5 h-5 text-red-400 mt-1" />
                    <div>
                      <p className="text-white font-medium">{match.location.address}</p>
                      <p className="text-gray-400 text-sm">
                        {match.location.city}, {match.location.state}, {match.location.country}
                      </p>
                    </div>
                  </div>

                  {/* Placeholder para Google Maps */}
                  <div className="bg-gray-700 rounded-lg p-8 text-center">
                    <MapPin className="w-12 h-12 mx-auto mb-3 text-gray-500" />
                    <p className="text-gray-400 mb-2">Mapa Interactivo</p>
                    <p className="text-gray-500 text-sm">Google Maps se integrará aquí</p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="mt-3 border-gray-600 text-gray-300"
                      onClick={() => {
                        const address = encodeURIComponent(match.location.address)
                        window.open(`https://maps.google.com/maps?q=${address}`, '_blank')
                      }}
                    >
                      Abrir en Google Maps
                    </Button>
                  </div>

                  {/* Información adicional de la cancha */}
                  <div className="bg-gray-700 p-4 rounded-lg">
                    <h4 className="text-white font-medium mb-2">Información de la Cancha</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Tipo de superficie:</span>
                        <span className="text-white">Césped sintético</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Vestuarios:</span>
                        <span className="text-white">Disponibles</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Estacionamiento:</span>
                        <span className="text-white">Gratuito</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Buffet:</span>
                        <span className="text-white">Disponible</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Organizador */}
            <TabsContent value="organizer">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Organizador del Partido</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <Avatar className="w-16 h-16">
                      <AvatarImage src={match.organizer.avatar || "/placeholder.svg"} />
                      <AvatarFallback>{match.organizer.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h3 className="text-white text-xl font-semibold">
                        {match.organizer.name} {match.organizer.lastName}
                      </h3>
                      <div className="flex items-center text-sm text-gray-400 mt-1">
                        <Star className="w-4 h-4 mr-1 text-yellow-400" />
                        <span>{match.organizer.rating?.toFixed(1) || 'N/A'}</span>
                        <span className="mx-2">•</span>
                        <span>{match.organizer.totalMatches || 0} partidos organizados</span>
                      </div>
                      <p className="text-gray-400 text-sm mt-1">
                        Miembro desde {new Date(match.organizer.createdAt || '2024-01-01').getFullYear()}
                      </p>
                    </div>
                  </div>

                  {/* Estadísticas del organizador */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-gray-700 p-3 rounded-lg text-center">
                      <div className="text-lg font-bold text-green-400">
                        {match.organizer.totalMatches || 0}
                      </div>
                      <div className="text-xs text-gray-400">Partidos</div>
                    </div>
                    <div className="bg-gray-700 p-3 rounded-lg text-center">
                      <div className="text-lg font-bold text-yellow-400">
                        {match.organizer.rating?.toFixed(1) || 'N/A'}
                      </div>
                      <div className="text-xs text-gray-400">Rating</div>
                    </div>
                    <div className="bg-gray-700 p-3 rounded-lg text-center">
                      <div className="text-lg font-bold text-blue-400">95%</div>
                      <div className="text-xs text-gray-400">Confiabilidad</div>
                    </div>
                    <div className="bg-gray-700 p-3 rounded-lg text-center">
                      <div className="text-lg font-bold text-purple-400">12</div>
                      <div className="text-xs text-gray-400">Este mes</div>
                    </div>
                  </div>

                  {/* Contacto */}
                  <div className="space-y-3">
                    <h4 className="text-white font-medium">Contactar Organizador</h4>
                    <div className="flex gap-2">
                      <Button
                        onClick={handleChatWithOrganizer}
                        className="flex-1 bg-blue-500 hover:bg-blue-600"
                      >
                        <MessageCircle className="w-4 h-4 mr-2" />
                        Enviar Mensaje
                      </Button>
                      <Button
                        variant="outline"
                        className="border-gray-600 text-gray-300 hover:bg-gray-700"
                      >
                        Ver Perfil Completo
                      </Button>
                    </div>
                  </div>

                  {/* Reseñas del organizador */}
                  <div>
                    <h4 className="text-white font-medium mb-3">Reseñas Recientes</h4>
                    <div className="space-y-3">
                      <div className="bg-gray-700 p-3 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center">
                            <Avatar className="w-6 h-6 mr-2">
                              <AvatarFallback className="text-xs">JD</AvatarFallback>
                            </Avatar>
                            <span className="text-white text-sm">Juan Díaz</span>
                          </div>
                          <div className="flex items-center">
                            {[1,2,3,4,5].map((star) => (
                              <Star key={star} className="w-3 h-3 text-yellow-400 fill-current" />
                            ))}
                          </div>
                        </div>
                        <p className="text-gray-300 text-sm">
                          "Excelente organizador, muy puntual y la cancha estaba en perfectas condiciones."
                        </p>
                      </div>
                      <div className="bg-gray-700 p-3 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center">
                            <Avatar className="w-6 h-6 mr-2">
                              <AvatarFallback className="text-xs">MR</AvatarFallback>
                            </Avatar>
                            <span className="text-white text-sm">María Rodríguez</span>
                          </div>
                          <div className="flex items-center">
                            {[1,2,3,4].map((star) => (
                              <Star key={star} className="w-3 h-3 text-yellow-400 fill-current" />
                            ))}
                            <Star className="w-3 h-3 text-gray-400" />
                          </div>
                        </div>
                        <p className="text-gray-300 text-sm">
                          "Buen partido, aunque hubo un pequeño retraso en el inicio."
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Botones de acción */}
          <div className="flex gap-4 pt-6 border-t border-gray-700 mt-6">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cerrar
            </Button>
            <Button
              onClick={handleJoinMatch}
              disabled={isFull}
              className={`flex-1 ${
                isFull 
                  ? 'bg-gray-600 cursor-not-allowed' 
                  : 'bg-green-500 hover:bg-green-600'
              } text-white`}
            >
              {isFull ? 'Partido Completo' : `Unirse al Partido (${spotsLeft} lugares)`}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
