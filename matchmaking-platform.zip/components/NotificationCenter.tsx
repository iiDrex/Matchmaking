"use client"

import { useState, useEffect } from "react"
import { Bell, X, Check, Trash2, Calendar, Users, Trophy, AlertTriangle, MessageCircle } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useAuth } from "../contexts/AuthContext"

interface Notification {
  id: string
  type: 'match_join' | 'match_leave' | 'tournament_update' | 'highlight_like' | 'system' | 'warning'
  title: string
  message: string
  timestamp: string
  isRead: boolean
  actionUrl?: string
  metadata?: {
    matchId?: string
    tournamentId?: string
    highlightId?: string
    userId?: string
  }
}

interface NotificationCenterProps {
  isOpen: boolean
  onClose: () => void
}

export default function NotificationCenter({ isOpen, onClose }: NotificationCenterProps) {
  const { user } = useAuth()
  const [notifications, setNotifications] = useState<Notification[]>([])

  // Mock notifications - en producción vendrían de la API
  const mockNotifications: Notification[] = [
    {
      id: "notif-001",
      type: "match_join",
      title: "Nuevo jugador se unió",
      message: "María González se unió a tu partido 'Fútbol 5 - Palermo'",
      timestamp: "2024-01-25T10:30:00Z",
      isRead: false,
      actionUrl: "/partidos/match-001",
      metadata: { matchId: "match-001", userId: "user-002" }
    },
    {
      id: "notif-002",
      type: "tournament_update",
      title: "Torneo confirmado",
      message: "Copa Primavera 2024 alcanzó el mínimo de equipos. ¡Comienza el 15 de febrero!",
      timestamp: "2024-01-24T15:45:00Z",
      isRead: false,
      actionUrl: "/torneos/tournament-001",
      metadata: { tournamentId: "tournament-001" }
    },
    {
      id: "notif-003",
      type: "highlight_like",
      title: "Tu highlight es popular",
      message: "Tu clip 'Golazo de media cancha' recibió 50 likes",
      timestamp: "2024-01-24T09:20:00Z",
      isRead: true,
      actionUrl: "/highlights/highlight-001",
      metadata: { highlightId: "highlight-001" }
    },
    {
      id: "notif-004",
      type: "match_leave",
      title: "Jugador se bajó",
      message: "Carlos Rodríguez se bajó del partido. Quedan 2 lugares disponibles.",
      timestamp: "2024-01-23T18:15:00Z",
      isRead: false,
      actionUrl: "/partidos/match-003",
      metadata: { matchId: "match-003", userId: "user-003" }
    },
    {
      id: "notif-005",
      type: "system",
      title: "Actualización disponible",
      message: "Nueva versión de la app con mejoras en el sistema de torneos",
      timestamp: "2024-01-23T12:00:00Z",
      isRead: true,
      actionUrl: "/configuracion"
    },
    {
      id: "notif-006",
      type: "warning",
      title: "Partido próximo a cancelarse",
      message: "Tu partido de mañana necesita más jugadores o será cancelado",
      timestamp: "2024-01-22T20:30:00Z",
      isRead: false,
      actionUrl: "/partidos/match-004",
      metadata: { matchId: "match-004" }
    }
  ]

  useEffect(() => {
    setNotifications(mockNotifications)
  }, [])

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'match_join':
      case 'match_leave':
        return <Users className="w-4 h-4" />
      case 'tournament_update':
        return <Trophy className="w-4 h-4" />
      case 'highlight_like':
        return <MessageCircle className="w-4 h-4" />
      case 'warning':
        return <AlertTriangle className="w-4 h-4" />
      default:
        return <Bell className="w-4 h-4" />
    }
  }

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'match_join':
        return 'text-green-400'
      case 'match_leave':
        return 'text-red-400'
      case 'tournament_update':
        return 'text-yellow-400'
      case 'highlight_like':
        return 'text-pink-400'
      case 'warning':
        return 'text-orange-400'
      default:
        return 'text-blue-400'
    }
  }

  const markAsRead = (notificationId: string) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === notificationId ? { ...notif, isRead: true } : notif
      )
    )
  }

  const deleteNotification = (notificationId: string) => {
    setNotifications(prev => prev.filter(notif => notif.id !== notificationId))
  }

  const markAllAsRead = () => {
    setNotifications(prev =>
      prev.map(notif => ({ ...notif, isRead: true }))
    )
  }

  const clearAllNotifications = () => {
    setNotifications([])
  }

  const unreadCount = notifications.filter(n => !n.isRead).length

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))
    
    if (diffInHours < 1) return 'Hace unos minutos'
    if (diffInHours < 24) return `Hace ${diffInHours}h`
    if (diffInHours < 48) return 'Ayer'
    return date.toLocaleDateString('es-AR')
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-start justify-center z-50 pt-20">
      <Card className="w-full max-w-md bg-gray-900 border-gray-700 mx-4">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <CardTitle className="text-white">Notificaciones</CardTitle>
              {unreadCount > 0 && (
                <Badge className="ml-2 bg-red-500 text-white">
                  {unreadCount}
                </Badge>
              )}
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4 text-gray-400" />
            </Button>
          </div>
          
          {notifications.length > 0 && (
            <div className="flex gap-2 mt-3">
              <Button
                variant="outline"
                size="sm"
                onClick={markAllAsRead}
                disabled={unreadCount === 0}
                className="text-xs border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                <Check className="w-3 h-3 mr-1" />
                Marcar leídas
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={clearAllNotifications}
                className="text-xs border-gray-600 text-red-400 hover:bg-red-900/20"
              >
                <Trash2 className="w-3 h-3 mr-1" />
                Limpiar todo
              </Button>
            </div>
          )}
        </CardHeader>

        <CardContent className="p-0">
          {notifications.length === 0 ? (
            <div className="text-center py-8">
              <Bell className="w-12 h-12 mx-auto mb-3 text-gray-500" />
              <p className="text-gray-400">No tienes notificaciones</p>
            </div>
          ) : (
            <ScrollArea className="h-96">
              <div className="space-y-1 p-4">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-3 rounded-lg border transition-all hover:bg-gray-800 ${
                      notification.isRead 
                        ? 'bg-gray-800/50 border-gray-700' 
                        : 'bg-gray-800 border-gray-600'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3 flex-1">
                        <div className={`mt-1 ${getNotificationColor(notification.type)}`}>
                          {getNotificationIcon(notification.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <p className={`text-sm font-medium ${
                              notification.isRead ? 'text-gray-300' : 'text-white'
                            }`}>
                              {notification.title}
                            </p>
                            {!notification.isRead && (
                              <div className="w-2 h-2 bg-blue-500 rounded-full ml-2"></div>
                            )}
                          </div>
                          <p className={`text-xs mt-1 ${
                            notification.isRead ? 'text-gray-500' : 'text-gray-400'
                          }`}>
                            {notification.message}
                          </p>
                          <p className="text-xs text-gray-500 mt-2">
                            {formatTimestamp(notification.timestamp)}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-1 ml-2">
                        {!notification.isRead && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => markAsRead(notification.id)}
                            className="p-1 h-6 w-6 text-gray-400 hover:text-green-400"
                          >
                            <Check className="w-3 h-3" />
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteNotification(notification.id)}
                          className="p-1 h-6 w-6 text-gray-400 hover:text-red-400"
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    
                    {notification.actionUrl && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="mt-2 text-xs text-blue-400 hover:text-blue-300 p-0 h-auto"
                        onClick={() => {
                          // Navegar a la URL
                          window.location.href = notification.actionUrl!
                          onClose()
                        }}
                      >
                        Ver detalles →
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export const useNotificationCount = () => {
  const [count, setCount] = useState(0)
  
  useEffect(() => {
    // Simular obtener notificaciones de la API
    const fetchNotifications = () => {
      // En producción, esto sería una llamada a la API
      const mockNotifications = [
        { id: "1", isRead: false },
        { id: "2", isRead: false },
        { id: "3", isRead: true },
        { id: "4", isRead: false }
      ]
      
      const unreadCount = mockNotifications.filter(n => !n.isRead).length
      setCount(unreadCount)
    }
    
    fetchNotifications()
    
    // Actualizar cada 30 segundos
    const interval = setInterval(fetchNotifications, 30000)
    
    return () => clearInterval(interval)
  }, [])
  
  return count
}
