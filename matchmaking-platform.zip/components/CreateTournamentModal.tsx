"use client"

import { useState } from 'react'
import { X, Calendar, Clock, MapPin, Users, DollarSign, Trophy, FileText, Plus, Trash2 } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CreateTournamentForm, MatchType, SkillLevel, Gender, Prize, TournamentFormat } from '../models/types'

interface CreateTournamentModalProps {
  isOpen: boolean
  onClose: () => void
  onSubmit: (tournamentData: CreateTournamentForm) => Promise<void>
}

export default function CreateTournamentModal({ isOpen, onClose, onSubmit }: CreateTournamentModalProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [prizes, setPrizes] = useState<Prize[]>([{ position: 1, description: '', value: 0, currency: 'ARS' }])
  const [rules, setRules] = useState<string[]>([''])

  const [formData, setFormData] = useState<CreateTournamentForm>({
    name: '',
    description: '',
    type: 'futbol5',
    startDate: '',
    endDate: '',
    location: {
      address: '',
      city: 'Buenos Aires',
      state: 'CABA',
      country: 'Argentina',
      coordinates: { lat: 0, lng: 0 }
    },
    maxTeams: 16,
    registrationDeadline: '',
    skillLevel: 'intermedio',
    gender: 'masculino',
    ageRange: { min: 18, max: 40 },
    entryFee: 0,
    prizes: [],
    rules: [],
    format: {
      type: 'league',
      groupSize: 4,
      playoffsTeams: 8
    }
  })

  const tournamentTypes: { value: MatchType; label: string; teams: number }[] = [
    { value: "futbol5", label: "Fútbol 5", teams: 16 },
    { value: "futbol8", label: "Fútbol 8", teams: 12 },
    { value: "futbol11", label: "Fútbol 11", teams: 8 }
  ]

  const skillLevels: { value: SkillLevel; label: string }[] = [
    { value: "casual", label: "Casual" },
    { value: "intermedio", label: "Intermedio" },
    { value: "competitivo", label: "Competitivo" }
  ]

  const genders: { value: Gender; label: string }[] = [
    { value: "masculino", label: "Masculino" },
    { value: "femenino", label: "Femenino" },
    { value: "mixto", label: "Mixto" }
  ]

  const formatTypes: { value: TournamentFormat['type']; label: string; description: string }[] = [
    { value: "league", label: "Liga", description: "Todos contra todos + playoffs" },
    { value: "knockout", label: "Eliminación Directa", description: "Eliminación desde el inicio" },
    { value: "group_stage", label: "Grupos + Eliminación", description: "Fase de grupos + eliminación" }
  ]

  const handleTypeChange = (type: MatchType) => {
    const tournamentType = tournamentTypes.find(t => t.value === type)
    setFormData({
      ...formData,
      type,
      maxTeams: tournamentType?.teams || 16
    })
  }

  const handlePrizeChange = (index: number, field: keyof Prize, value: any) => {
    const newPrizes = [...prizes]
    newPrizes[index] = { ...newPrizes[index], [field]: value }
    setPrizes(newPrizes)
    setFormData({ ...formData, prizes: newPrizes })
  }

  const addPrize = () => {
    const newPrize: Prize = {
      position: prizes.length + 1,
      description: '',
      value: 0,
      currency: 'ARS'
    }
    setPrizes([...prizes, newPrize])
  }

  const removePrize = (index: number) => {
    const newPrizes = prizes.filter((_, i) => i !== index)
    setPrizes(newPrizes)
    setFormData({ ...formData, prizes: newPrizes })
  }

  const handleRuleChange = (index: number, value: string) => {
    const newRules = [...rules]
    newRules[index] = value
    setRules(newRules)
    setFormData({ ...formData, rules: newRules.filter(rule => rule.trim() !== '') })
  }

  const addRule = () => {
    setRules([...rules, ''])
  }

  const removeRule = (index: number) => {
    const newRules = rules.filter((_, i) => i !== index)
    setRules(newRules)
    setFormData({ ...formData, rules: newRules.filter(rule => rule.trim() !== '') })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)

    try {
      // Validaciones
      if (!formData.name.trim()) throw new Error('El nombre del torneo es requerido')
      if (!formData.startDate) throw new Error('La fecha de inicio es requerida')
      if (!formData.endDate) throw new Error('La fecha de fin es requerida')
      if (!formData.registrationDeadline) throw new Error('La fecha límite de inscripción es requerida')
      if (!formData.location.address.trim()) throw new Error('La ubicación es requerida')

      // Validar fechas
      const startDate = new Date(formData.startDate)
      const endDate = new Date(formData.endDate)
      const registrationDeadline = new Date(formData.registrationDeadline)

      if (registrationDeadline >= startDate) {
        throw new Error('La fecha límite de inscripción debe ser anterior al inicio del torneo')
      }

      if (startDate >= endDate) {
        throw new Error('La fecha de inicio debe ser anterior a la fecha de fin')
      }

      await onSubmit(formData)
      onClose()
      
      // Reset form
      setFormData({
        name: '',
        description: '',
        type: 'futbol5',
        startDate: '',
        endDate: '',
        location: {
          address: '',
          city: 'Buenos Aires',
          state: 'CABA',
          country: 'Argentina',
          coordinates: { lat: 0, lng: 0 }
        },
        maxTeams: 16,
        registrationDeadline: '',
        skillLevel: 'intermedio',
        gender: 'masculino',
        ageRange: { min: 18, max: 40 },
        entryFee: 0,
        prizes: [],
        rules: [],
        format: {
          type: 'league',
          groupSize: 4,
          playoffsTeams: 8
        }
      })
      setPrizes([{ position: 1, description: '', value: 0, currency: 'ARS' }])
      setRules([''])
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Error al crear el torneo')
    } finally {
      setIsLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <Card className="w-full max-w-4xl bg-gray-900 border-gray-700 my-8">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl text-white">Crear Nuevo Torneo</CardTitle>
              <CardDescription className="text-gray-400">
                Organiza una competencia y reúne a los mejores equipos
              </CardDescription>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-5 h-5 text-gray-400" />
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Información básica */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-white">Información Básica</h3>
                
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-gray-300">Nombre del Torneo</Label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="Ej: Copa Primavera 2024"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description" className="text-gray-300">Descripción</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe el torneo, formato, premios, etc."
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white"
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="type" className="text-gray-300">Tipo de Torneo</Label>
                    <Select value={formData.type} onValueChange={handleTypeChange}>
                      <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-700">
                        {tournamentTypes.map(type => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label} ({type.teams} equipos)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxTeams" className="text-gray-300">Máximo Equipos</Label>
                    <Input
                      id="maxTeams"
                      type="number"
                      value={formData.maxTeams}
                      onChange={(e) => setFormData({ ...formData, maxTeams: parseInt(e.target.value) })}
                      className="bg-gray-800 border-gray-700 text-white"
                      min="4"
                      max="32"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-white">Fechas</h3>
                
                <div className="space-y-2">
                  <Label htmlFor="registrationDeadline" className="text-gray-300">Fecha Límite Inscripción</Label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="registrationDeadline"
                      type="date"
                      value={formData.registrationDeadline}
                      onChange={(e) => setFormData({ ...formData, registrationDeadline: e.target.value })}
                      className="pl-10 bg-gray-800 border-gray-700 text-white"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="startDate" className="text-gray-300">Fecha Inicio</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        id="startDate"
                        type="date"
                        value={formData.startDate}
                        onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                        className="pl-10 bg-gray-800 border-gray-700 text-white"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="endDate" className="text-gray-300">Fecha Fin</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        id="endDate"
                        type="date"
                        value={formData.endDate}
                        onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                        className="pl-10 bg-gray-800 border-gray-700 text-white"
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="entryFee" className="text-gray-300">Costo de Inscripción (ARS)</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="entryFee"
                      type="number"
                      value={formData.entryFee}
                      onChange={(e) => setFormData({ ...formData, entryFee: parseInt(e.target.value) })}
                      className="pl-10 bg-gray-800 border-gray-700 text-white"
                      min="0"
                      placeholder="0"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Configuración del torneo */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-white">Configuración</h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="skillLevel" className="text-gray-300">Nivel</Label>
                    <Select
                      value={formData.skillLevel}
                      onValueChange={(value: SkillLevel) => setFormData({ ...formData, skillLevel: value })}
                    >
                      <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-700">
                        {skillLevels.map(level => (
                          <SelectItem key={level.value} value={level.value}>
                            {level.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="gender" className="text-gray-300">Género</Label>
                    <Select
                      value={formData.gender}
                      onValueChange={(value: Gender) => setFormData({ ...formData, gender: value })}
                    >
                      <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-700">
                        {genders.map(gender => (
                          <SelectItem key={gender.value} value={gender.value}>
                            {gender.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="minAge" className="text-gray-300">Edad Mínima</Label>
                    <Input
                      id="minAge"
                      type="number"
                      value={formData.ageRange.min}
                      onChange={(e) => setFormData({
                        ...formData,
                        ageRange: { ...formData.ageRange, min: parseInt(e.target.value) }
                      })}
                      className="bg-gray-800 border-gray-700 text-white"
                      min="16"
                      max="60"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxAge" className="text-gray-300">Edad Máxima</Label>
                    <Input
                      id="maxAge"
                      type="number"
                      value={formData.ageRange.max}
                      onChange={(e) => setFormData({
                        ...formData,
                        ageRange: { ...formData.ageRange, max: parseInt(e.target.value) }
                      })}
                      className="bg-gray-800 border-gray-700 text-white"
                      min="16"
                      max="60"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="format" className="text-gray-300">Formato del Torneo</Label>
                  <Select
                    value={formData.format.type}
                    onValueChange={(value: TournamentFormat['type']) => 
                      setFormData({ 
                        ...formData, 
                        format: { ...formData.format, type: value } 
                      })
                    }
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700">
                      {formatTypes.map(format => (
                        <SelectItem key={format.value} value={format.value}>
                          <div>
                            <div className="font-medium">{format.label}</div>
                            <div className="text-xs text-gray-400">{format.description}</div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-white">Ubicación</h3>
                
                <div className="space-y-2">
                  <Label htmlFor="address" className="text-gray-300">Dirección</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="address"
                      type="text"
                      placeholder="Ej: Complejo Deportivo Norte, Av. Corrientes 4500"
                      value={formData.location.address}
                      onChange={(e) => setFormData({
                        ...formData,
                        location: { ...formData.location, address: e.target.value }
                      })}
                      className="pl-10 bg-gray-800 border-gray-700 text-white"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="city" className="text-gray-300">Ciudad</Label>
                    <Input
                      id="city"
                      type="text"
                      value={formData.location.city}
                      onChange={(e) => setFormData({
                        ...formData,
                        location: { ...formData.location, city: e.target.value }
                      })}
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="state" className="text-gray-300">Provincia/Estado</Label>
                    <Input
                      id="state"
                      type="text"
                      value={formData.location.state}
                      onChange={(e) => setFormData({
                        ...formData,
                        location: { ...formData.location, state: e.target.value }
                      })}
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Premios */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-white">Premios</h3>
                <Button type="button" variant="outline" size="sm" onClick={addPrize}>
                  <Plus className="w-4 h-4 mr-2" />
                  Agregar Premio
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {prizes.map((prize, index) => (
                  <Card key={index} className="bg-gray-800 border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center mb-3">
                        <Badge className="bg-yellow-500 text-black">
                          <Trophy className="w-3 h-3 mr-1" />
                          {prize.position}° Lugar
                        </Badge>
                        {prizes.length > 1 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removePrize(index)}
                            className="text-red-400 hover:text-red-300"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <Label className="text-gray-300 text-sm">Descripción</Label>
                          <Input
                            placeholder="Ej: Trofeo + $50.000"
                            value={prize.description}
                            onChange={(e) => handlePrizeChange(index, 'description', e.target.value)}
                            className="bg-gray-700 border-gray-600 text-white"
                          />
                        </div>
                        
                        <div>
                          <Label className="text-gray-300 text-sm">Valor (ARS)</Label>
                          <Input
                            type="number"
                            placeholder="0"
                            value={prize.value}
                            onChange={(e) => handlePrizeChange(index, 'value', parseInt(e.target.value) || 0)}
                            className="bg-gray-700 border-gray-600 text-white"
                            min="0"
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Reglas */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-white">Reglas del Torneo</h3>
                <Button type="button" variant="outline" size="sm" onClick={addRule}>
                  <Plus className="w-4 h-4 mr-2" />
                  Agregar Regla
                </Button>
              </div>
              
              {rules.map((rule, index) => (
                <div key={index} className="flex gap-2">
                  <div className="relative flex-1">
                    <FileText className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      type="text"
                      placeholder="Ej: Equipos de 5 jugadores + 2 suplentes"
                      value={rule}
                      onChange={(e) => handleRuleChange(index, e.target.value)}
                      className="pl-10 bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                  {rules.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeRule(index)}
                      className="text-red-400 hover:text-red-300"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            {error && (
              <div className="text-red-400 text-sm text-center bg-red-900/20 p-3 rounded">
                {error}
              </div>
            )}

            <div className="flex gap-4 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-green-500 hover:bg-green-600"
                disabled={isLoading}
              >
                {isLoading ? 'Creando...' : 'Crear Torneo'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
