"use client"

import { useState } from 'react'
import { MapPin, Navigation } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface GoogleMapProps {
  center: {
    lat: number
    lng: number
  }
  markers?: Array<{
    id: string
    position: { lat: number; lng: number }
    title: string
    description?: string
  }>
  zoom?: number
  height?: string
  onMarkerClick?: (markerId: string) => void
}

export default function GoogleMap({ 
  center, 
  markers = [], 
  zoom = 13, 
  height = "400px",
  onMarkerClick 
}: GoogleMapProps) {
  const [selectedMarker, setSelectedMarker] = useState<string | null>(null)

  const handleMarkerClick = (markerId: string) => {
    setSelectedMarker(markerId)
    onMarkerClick?.(markerId)
  }

  // Mock Google Maps - En producción aquí iría la integración real
  return (
    <div className="relative">
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-0">
          <div 
            className="relative bg-gradient-to-br from-green-900 to-gray-800 rounded-lg overflow-hidden"
            style={{ height }}
          >
            {/* Mock map background */}
            <div className="absolute inset-0 opacity-20">
              <div className="w-full h-full bg-[url('/placeholder.svg?height=400&width=600&text=Mapa+de+Buenos+Aires')] bg-cover bg-center"></div>
            </div>

            {/* Center marker */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <div className="w-6 h-6 bg-red-500 rounded-full border-2 border-white shadow-lg flex items-center justify-center">
                <MapPin className="w-3 h-3 text-white" />
              </div>
            </div>

            {/* Mock markers */}
            {markers.map((marker, index) => (
              <div
                key={marker.id}
                className={`absolute cursor-pointer transform -translate-x-1/2 -translate-y-1/2 ${
                  selectedMarker === marker.id ? 'z-10' : 'z-0'
                }`}
                style={{
                  top: `${40 + (index * 15)}%`,
                  left: `${30 + (index * 20)}%`
                }}
                onClick={() => handleMarkerClick(marker.id)}
              >
                <div className={`w-8 h-8 rounded-full border-2 border-white shadow-lg flex items-center justify-center transition-all ${
                  selectedMarker === marker.id 
                    ? 'bg-green-500 scale-110' 
                    : 'bg-blue-500 hover:scale-105'
                }`}>
                  <MapPin className="w-4 h-4 text-white" />
                </div>
                
                {selectedMarker === marker.id && (
                  <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 bg-white rounded-lg shadow-lg p-2 min-w-32">
                    <p className="text-sm font-medium text-gray-900">{marker.title}</p>
                    {marker.description && (
                      <p className="text-xs text-gray-600">{marker.description}</p>
                    )}
                  </div>
                )}
              </div>
            ))}

            {/* Controls */}
            <div className="absolute top-4 right-4 space-y-2">
              <Button
                size="sm"
                variant="secondary"
                className="bg-white/90 hover:bg-white text-gray-900"
              >
                <Navigation className="w-4 h-4" />
              </Button>
            </div>

            {/* Mock location info */}
            <div className="absolute bottom-4 left-4 bg-black/70 text-white px-3 py-2 rounded-lg">
              <p className="text-sm">📍 Buenos Aires, Argentina</p>
              <p className="text-xs text-gray-300">Zoom: {zoom}x</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Integration note */}
      <div className="mt-2 text-center">
        <p className="text-xs text-gray-500">
          🗺️ Integración con Google Maps en desarrollo
        </p>
      </div>
    </div>
  )
}
