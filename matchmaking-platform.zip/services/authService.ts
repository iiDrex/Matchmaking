import { apiService } from './api'
import { User, LoginForm, RegisterForm, AuthResponse, ApiResponse } from '../models/types'
import { mockAdmin, mockUsers } from './mockData'

class AuthService {
  // Mock login para desarrollo
  async login(credentials: LoginForm): Promise<AuthResponse> {
    // Simular delay de red
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    // Verificar credenciales mock
    if (credentials.email === 'admin@mail.com' && credentials.password === 'admin') {
      const mockResponse: AuthResponse = {
        user: mockAdmin,
        token: 'mock-admin-token-' + Date.now(),
        refreshToken: 'mock-refresh-token-' + Date.now()
      }
      
      apiService.setToken(mockResponse.token)
      this.setCurrentUser(mockResponse.user)
      return mockResponse
    }
    
    // Verificar otros usuarios mock
    const mockUser = mockUsers.find(user => user.email === credentials.email)
    if (mockUser && credentials.password === 'password') {
      const mockResponse: AuthResponse = {
        user: mockUser,
        token: 'mock-user-token-' + Date.now(),
        refreshToken: 'mock-refresh-token-' + Date.now()
      }
      
      apiService.setToken(mockResponse.token)
      this.setCurrentUser(mockResponse.user)
      return mockResponse
    }
    
    throw new Error('Credenciales inválidas')
  }

  async register(userData: RegisterForm): Promise<AuthResponse> {
    // Simular delay de red
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // Verificar si el email ya existe
    if (userData.email === 'admin@mail.com' || mockUsers.some(user => user.email === userData.email)) {
      throw new Error('El email ya está registrado')
    }
    
    // Crear nuevo usuario mock
    const newUser: User = {
      id: 'user-' + Date.now(),
      email: userData.email,
      name: userData.name,
      lastName: userData.lastName,
      phone: userData.phone,
      avatar: `/placeholder.svg?height=100&width=100&text=${userData.name.charAt(0)}${userData.lastName.charAt(0)}`,
      dateOfBirth: userData.dateOfBirth,
      gender: userData.gender,
      location: userData.location,
      position: userData.position,
      skillLevel: userData.skillLevel,
      role: "player",
      isVerified: false,
      rating: 0,
      totalMatches: 0,
      totalTournaments: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      preferences: {
        notifications: { email: true, push: true, sms: false },
        privacy: { showPhone: false, showEmail: false, showLocation: true },
        matchmaking: { maxDistance: 15, preferredTimes: ["19:00"], preferredDays: ["monday"] }
      },
      stats: {
        matchesWon: 0,
        matchesLost: 0,
        matchesDrawn: 0,
        goalsScored: 0,
        assists: 0,
        cleanSheets: 0,
        averageRating: 0,
        reliability: 100
      }
    }
    
    const mockResponse: AuthResponse = {
      user: newUser,
      token: 'mock-new-user-token-' + Date.now(),
      refreshToken: 'mock-refresh-token-' + Date.now()
    }
    
    apiService.setToken(mockResponse.token)
    this.setCurrentUser(mockResponse.user)
    return mockResponse
  }

  async logout(): Promise<void> {
    try {
      // En producción aquí iría la llamada real a la API
      await new Promise(resolve => setTimeout(resolve, 500))
    } catch (error) {
      console.error('Logout error:', error)
    } finally {
      apiService.removeToken()
      this.removeCurrentUser()
    }
  }

  async getCurrentUser(): Promise<User | null> {
    try {
      // En desarrollo, retornar el usuario del localStorage
      return this.getCurrentUserFromStorage()
    } catch (error) {
      console.error('Get current user error:', error)
      return null
    }
  }

  async refreshToken(): Promise<string | null> {
    try {
      // Mock refresh token
      await new Promise(resolve => setTimeout(resolve, 500))
      const newToken = 'mock-refreshed-token-' + Date.now()
      apiService.setToken(newToken)
      return newToken
    } catch (error) {
      console.error('Token refresh error:', error)
    }
    return null
  }

  async forgotPassword(email: string): Promise<void> {
    await new Promise(resolve => setTimeout(resolve, 1000))
    // Mock: siempre exitoso
    console.log('Password reset email sent to:', email)
  }

  async resetPassword(token: string, newPassword: string): Promise<void> {
    await new Promise(resolve => setTimeout(resolve, 1000))
    // Mock: siempre exitoso
    console.log('Password reset successful')
  }

  // Métodos de almacenamiento local
  private setCurrentUser(user: User): void {
    if (typeof window !== 'undefined') {
      localStorage.setItem('current_user', JSON.stringify(user))
    }
  }

  private removeCurrentUser(): void {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('current_user')
    }
  }

  getCurrentUserFromStorage(): User | null {
    if (typeof window !== 'undefined') {
      const userStr = localStorage.getItem('current_user')
      return userStr ? JSON.parse(userStr) : null
    }
    return null
  }

  isAuthenticated(): boolean {
    if (typeof window !== 'undefined') {
      return !!localStorage.getItem('auth_token')
    }
    return false
  }
}

export const authService = new AuthService()
