import { User, Match, Tournament, Field, Team } from '../models/types'

// Usuario Admin Mock
export const mockAdmin: User = {
  id: "admin-001",
  email: "admin@mail.com",
  name: "Admin",
  lastName: "Sistema",
  phone: "+54 11 1234-5678",
  avatar: "/placeholder.svg?height=100&width=100&text=Admin",
  dateOfBirth: "1990-01-01",
  gender: "masculino",
  location: {
    address: "Av. Corrientes 1234, Buenos Aires",
    city: "Buenos Aires",
    state: "CABA",
    country: "Argentina",
    coordinates: { lat: -34.6037, lng: -58.3816 }
  },
  position: "cualquiera",
  skillLevel: "competitivo",
  role: "admin",
  isVerified: true,
  rating: 5.0,
  totalMatches: 150,
  totalTournaments: 25,
  createdAt: "2023-01-01T00:00:00Z",
  updatedAt: "2024-01-01T00:00:00Z",
  preferences: {
    notifications: {
      email: true,
      push: true,
      sms: false
    },
    privacy: {
      showPhone: true,
      showEmail: false,
      showLocation: true
    },
    matchmaking: {
      maxDistance: 20,
      preferredTimes: ["18:00", "19:00", "20:00"],
      preferredDays: ["monday", "wednesday", "friday"]
    }
  },
  stats: {
    matchesWon: 95,
    matchesLost: 35,
    matchesDrawn: 20,
    goalsScored: 87,
    assists: 45,
    cleanSheets: 12,
    averageRating: 4.8,
    reliability: 98
  }
}

// Usuarios Mock adicionales
export const mockUsers: User[] = [
  {
    id: "user-001",
    email: "juan.perez@mail.com",
    name: "Juan",
    lastName: "Pérez",
    phone: "+54 11 2345-6789",
    avatar: "/placeholder.svg?height=100&width=100&text=JP",
    dateOfBirth: "1995-03-15",
    gender: "masculino",
    location: {
      address: "Av. Santa Fe 2500, Buenos Aires",
      city: "Buenos Aires",
      state: "CABA",
      country: "Argentina",
      coordinates: { lat: -34.5875, lng: -58.4050 }
    },
    position: "mediocampista",
    skillLevel: "intermedio",
    role: "player",
    isVerified: true,
    rating: 4.2,
    totalMatches: 45,
    totalTournaments: 8,
    createdAt: "2023-06-01T00:00:00Z",
    updatedAt: "2024-01-01T00:00:00Z",
    preferences: {
      notifications: { email: true, push: true, sms: false },
      privacy: { showPhone: false, showEmail: false, showLocation: true },
      matchmaking: { maxDistance: 15, preferredTimes: ["19:00", "20:00"], preferredDays: ["tuesday", "thursday"] }
    },
    stats: {
      matchesWon: 28,
      matchesLost: 12,
      matchesDrawn: 5,
      goalsScored: 23,
      assists: 18,
      cleanSheets: 0,
      averageRating: 4.2,
      reliability: 92
    }
  },
  {
    id: "user-002",
    email: "maria.gonzalez@mail.com",
    name: "María",
    lastName: "González",
    phone: "+54 11 3456-7890",
    avatar: "/placeholder.svg?height=100&width=100&text=MG",
    dateOfBirth: "1992-07-22",
    gender: "femenino",
    location: {
      address: "Av. Cabildo 1800, Buenos Aires",
      city: "Buenos Aires",
      state: "CABA",
      country: "Argentina",
      coordinates: { lat: -34.5601, lng: -58.4566 }
    },
    position: "delantero",
    skillLevel: "competitivo",
    role: "organizer",
    isVerified: true,
    rating: 4.7,
    totalMatches: 78,
    totalTournaments: 15,
    createdAt: "2023-03-01T00:00:00Z",
    updatedAt: "2024-01-01T00:00:00Z",
    preferences: {
      notifications: { email: true, push: true, sms: true },
      privacy: { showPhone: true, showEmail: false, showLocation: true },
      matchmaking: { maxDistance: 25, preferredTimes: ["18:00", "19:00"], preferredDays: ["monday", "wednesday", "friday"] }
    },
    stats: {
      matchesWon: 52,
      matchesLost: 18,
      matchesDrawn: 8,
      goalsScored: 65,
      assists: 22,
      cleanSheets: 0,
      averageRating: 4.7,
      reliability: 96
    }
  }
]

// Canchas Mock
export const mockFields: Field[] = [
  {
    id: "field-001",
    name: "Cancha Los Amigos",
    address: "Av. Santa Fe 3500, Buenos Aires",
    location: {
      address: "Av. Santa Fe 3500, Buenos Aires",
      city: "Buenos Aires",
      state: "CABA",
      country: "Argentina",
      coordinates: { lat: -34.5875, lng: -58.4050 }
    },
    type: ["futbol5", "futbol8"],
    amenities: ["Vestuarios", "Estacionamiento", "Buffet", "Iluminación"],
    pricePerHour: 8000,
    currency: "ARS",
    images: [
      "/placeholder.svg?height=300&width=400&text=Cancha+1",
      "/placeholder.svg?height=300&width=400&text=Cancha+2"
    ],
    rating: 4.5,
    reviews: [],
    availability: [
      { dayOfWeek: 1, startTime: "08:00", endTime: "23:00", isAvailable: true, price: 8000 },
      { dayOfWeek: 2, startTime: "08:00", endTime: "23:00", isAvailable: true, price: 8000 },
      { dayOfWeek: 3, startTime: "08:00", endTime: "23:00", isAvailable: true, price: 8000 },
      { dayOfWeek: 4, startTime: "08:00", endTime: "23:00", isAvailable: true, price: 8000 },
      { dayOfWeek: 5, startTime: "08:00", endTime: "23:00", isAvailable: true, price: 8000 },
      { dayOfWeek: 6, startTime: "08:00", endTime: "23:00", isAvailable: true, price: 10000 },
      { dayOfWeek: 0, startTime: "08:00", endTime: "23:00", isAvailable: true, price: 10000 }
    ],
    contact: {
      phone: "+54 11 4567-8901",
      email: "info@canchalosAmigos.com",
      website: "www.canchalosAmigos.com"
    }
  },
  {
    id: "field-002",
    name: "Complejo Deportivo Norte",
    address: "Av. Corrientes 4500, Buenos Aires",
    location: {
      address: "Av. Corrientes 4500, Buenos Aires",
      city: "Buenos Aires",
      state: "CABA",
      country: "Argentina",
      coordinates: { lat: -34.5983, lng: -58.4267 }
    },
    type: ["futbol8", "futbol11"],
    amenities: ["Vestuarios", "Estacionamiento", "Buffet", "Iluminación", "Duchas"],
    pricePerHour: 12000,
    currency: "ARS",
    images: [
      "/placeholder.svg?height=300&width=400&text=Complejo+1",
      "/placeholder.svg?height=300&width=400&text=Complejo+2"
    ],
    rating: 4.8,
    reviews: [],
    availability: [
      { dayOfWeek: 1, startTime: "07:00", endTime: "24:00", isAvailable: true, price: 12000 },
      { dayOfWeek: 2, startTime: "07:00", endTime: "24:00", isAvailable: true, price: 12000 },
      { dayOfWeek: 3, startTime: "07:00", endTime: "24:00", isAvailable: true, price: 12000 },
      { dayOfWeek: 4, startTime: "07:00", endTime: "24:00", isAvailable: true, price: 12000 },
      { dayOfWeek: 5, startTime: "07:00", endTime: "24:00", isAvailable: true, price: 12000 },
      { dayOfWeek: 6, startTime: "07:00", endTime: "24:00", isAvailable: true, price: 15000 },
      { dayOfWeek: 0, startTime: "07:00", endTime: "24:00", isAvailable: true, price: 15000 }
    ],
    contact: {
      phone: "+54 11 5678-9012",
      email: "info@complejonorte.com",
      website: "www.complejonorte.com"
    }
  }
]

// Torneos Mock
export const mockTournaments: Tournament[] = [
  {
    id: "tournament-001",
    name: "Copa Primavera 2024",
    description: "Torneo de fútbol 5 para jugadores intermedios y competitivos. Formato liga con playoffs.",
    type: "futbol5",
    startDate: "2024-02-15",
    endDate: "2024-03-30",
    location: {
      address: "Complejo Deportivo Norte, Av. Corrientes 4500",
      city: "Buenos Aires",
      state: "CABA",
      country: "Argentina",
      coordinates: { lat: -34.5983, lng: -58.4267 }
    },
    organizer: mockUsers[1], // María González
    maxTeams: 16,
    currentTeams: [],
    registrationDeadline: "2024-02-10",
    skillLevel: "intermedio",
    gender: "mixto",
    ageRange: { min: 18, max: 40 },
    entryFee: 25000,
    currency: "ARS",
    prizes: [
      { position: 1, description: "Trofeo + $100.000", value: 100000, currency: "ARS" },
      { position: 2, description: "Medallas + $50.000", value: 50000, currency: "ARS" },
      { position: 3, description: "Medallas + $25.000", value: 25000, currency: "ARS" }
    ],
    rules: [
      "Equipos de 5 jugadores + 2 suplentes",
      "Partidos de 25 minutos cada tiempo",
      "Tarjeta amarilla = 2 minutos fuera",
      "Tarjeta roja = expulsión del partido",
      "Máximo 2 jugadores por equipo pueden ser nivel competitivo"
    ],
    status: "registration",
    format: {
      type: "league",
      groupSize: 4,
      playoffsTeams: 8
    },
    createdAt: "2024-01-01T00:00:00Z",
    updatedAt: "2024-01-15T00:00:00Z",
    field: mockFields[1]
  },
  {
    id: "tournament-002",
    name: "Torneo Relámpago Fútbol 8",
    description: "Torneo express de eliminación directa. Un día de pura adrenalina.",
    type: "futbol8",
    startDate: "2024-02-03",
    endDate: "2024-02-03",
    location: {
      address: "Cancha Los Amigos, Av. Santa Fe 3500",
      city: "Buenos Aires",
      state: "CABA",
      country: "Argentina",
      coordinates: { lat: -34.5875, lng: -58.4050 }
    },
    organizer: mockAdmin,
    maxTeams: 8,
    currentTeams: [],
    registrationDeadline: "2024-01-30",
    skillLevel: "casual",
    gender: "masculino",
    ageRange: { min: 20, max: 35 },
    entryFee: 15000,
    currency: "ARS",
    prizes: [
      { position: 1, description: "Trofeo + Cena para el equipo", value: 40000, currency: "ARS" },
      { position: 2, description: "Medallas", value: 0 }
    ],
    rules: [
      "Equipos de 8 jugadores + 3 suplentes",
      "Partidos de 20 minutos cada tiempo",
      "Eliminación directa",
      "En caso de empate: penales directos"
    ],
    status: "registration",
    format: {
      type: "knockout"
    },
    createdAt: "2024-01-10T00:00:00Z",
    updatedAt: "2024-01-20T00:00:00Z",
    field: mockFields[0]
  }
]

// Partidos Mock actualizados
export const mockMatches: Match[] = [
  {
    id: "match-001",
    title: "Fútbol 5 - Palermo",
    description: "Partido amistoso de buen nivel. Buscamos jugadores comprometidos para completar el equipo.",
    type: "futbol5",
    date: "2024-01-25",
    startTime: "19:00",
    endTime: "20:00",
    location: {
      address: "Cancha Los Amigos, Av. Santa Fe 3500",
      city: "Buenos Aires",
      state: "CABA",
      country: "Argentina",
      coordinates: { lat: -34.5875, lng: -58.4050 }
    },
    organizer: mockUsers[0], // Juan Pérez
    maxPlayers: 10,
    currentPlayers: [mockUsers[0], mockUsers[1]], // Array of User objects
    waitingList: [],
    skillLevel: "intermedio",
    gender: "masculino",
    ageRange: { min: 20, max: 35 },
    price: 1500,
    currency: "ARS",
    needsPositions: ["defensor", "mediocampista"],
    rules: [
      "Traer botines de fútbol 5",
      "Llegar 10 minutos antes",
      "Respetar las decisiones del árbitro",
      "Juego limpio y fair play"
    ],
    status: "open",
    isPrivate: false,
    createdAt: "2024-01-20T00:00:00Z",
    updatedAt: "2024-01-22T00:00:00Z",
    field: mockFields[0]
  },
  {
    id: "match-002",
    title: "Fútbol 11 - Belgrano",
    description: "Partido competitivo en cancha de césped natural. Nivel alto, buen ambiente.",
    type: "futbol11",
    date: "2024-01-26",
    startTime: "18:30",
    endTime: "20:00",
    location: {
      address: "Complejo Deportivo Norte, Av. Corrientes 4500",
      city: "Buenos Aires",
      state: "CABA",
      country: "Argentina",
      coordinates: { lat: -34.5983, lng: -58.4267 }
    },
    organizer: mockUsers[1], // María González
    maxPlayers: 22,
    currentPlayers: [mockUsers[1], mockAdmin], // Array of User objects
    waitingList: [],
    skillLevel: "competitivo",
    gender: "mixto",
    ageRange: { min: 18, max: 40 },
    price: 2000,
    currency: "ARS",
    needsPositions: ["arquero", "delantero"],
    rules: [
      "Botines de fútbol 11 obligatorios",
      "Canilleras obligatorias",
      "Nivel competitivo requerido",
      "Puntualidad estricta"
    ],
    status: "open",
    isPrivate: false,
    createdAt: "2024-01-18T00:00:00Z",
    updatedAt: "2024-01-23T00:00:00Z",
    field: mockFields[1]
  }
]
