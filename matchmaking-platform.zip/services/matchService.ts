import { apiService } from './api'
import { Match, MatchFilters, CreateMatchForm, ApiResponse } from '../models/types'

class MatchService {
  async getAllMatches(filters?: MatchFilters): Promise<Match[]> {
    const queryParams = new URLSearchParams()
    
    if (filters) {
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          if (typeof value === 'object') {
            queryParams.append(key, JSON.stringify(value))
          } else {
            queryParams.append(key, value.toString())
          }
        }
      })
    }

    const endpoint = `/matches${queryParams.toString() ? `?${queryParams.toString()}` : ''}`
    const response = await apiService.get<ApiResponse<Match[]>>(endpoint)
    
    return response.success && response.data ? response.data : []
  }

  async getMatchById(id: string): Promise<Match | null> {
    try {
      const response = await apiService.get<ApiResponse<Match>>(`/matches/${id}`)
      return response.success && response.data ? response.data : null
    } catch (error) {
      console.error('Get match error:', error)
      return null
    }
  }

  async createMatch(matchData: CreateMatchForm): Promise<Match> {
    const response = await apiService.post<ApiResponse<Match>>('/matches', matchData)
    
    if (response.success && response.data) {
      return response.data
    }
    
    throw new Error(response.message || 'Failed to create match')
  }

  async updateMatch(id: string, matchData: Partial<CreateMatchForm>): Promise<Match> {
    const response = await apiService.put<ApiResponse<Match>>(`/matches/${id}`, matchData)
    
    if (response.success && response.data) {
      return response.data
    }
    
    throw new Error(response.message || 'Failed to update match')
  }

  async deleteMatch(id: string): Promise<void> {
    const response = await apiService.delete<ApiResponse<void>>(`/matches/${id}`)
    
    if (!response.success) {
      throw new Error(response.message || 'Failed to delete match')
    }
  }

  async joinMatch(matchId: string): Promise<void> {
    const response = await apiService.post<ApiResponse<void>>(`/matches/${matchId}/join`)
    
    if (!response.success) {
      throw new Error(response.message || 'Failed to join match')
    }
  }

  async leaveMatch(matchId: string): Promise<void> {
    const response = await apiService.post<ApiResponse<void>>(`/matches/${matchId}/leave`)
    
    if (!response.success) {
      throw new Error(response.message || 'Failed to leave match')
    }
  }

  async getMyMatches(): Promise<Match[]> {
    const response = await apiService.get<ApiResponse<Match[]>>('/matches/my-matches')
    return response.success && response.data ? response.data : []
  }

  async getNearbyMatches(lat: number, lng: number, radius: number = 10): Promise<Match[]> {
    const response = await apiService.get<ApiResponse<Match[]>>(
      `/matches/nearby?lat=${lat}&lng=${lng}&radius=${radius}`
    )
    return response.success && response.data ? response.data : []
  }

  async rateMatch(matchId: string, rating: number, comment?: string): Promise<void> {
    const response = await apiService.post<ApiResponse<void>>(`/matches/${matchId}/rate`, {
      rating,
      comment
    })
    
    if (!response.success) {
      throw new Error(response.message || 'Failed to rate match')
    }
  }
}

export const matchService = new MatchService()
